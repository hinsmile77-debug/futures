"""
demo_creon.py — 대신 CYBOS Plus / CREON Plus 환경 시나리오 데모.

  python demo_creon.py          # 사고 시나리오 (게이트 CLOSED)
  python demo_creon.py clean    # 정상

시연 포인트:
  09:47~09:49 3분간 재접속으로 이벤트 유실이 발생했는데
  → RECON.VOLUME_BIAS(거래량 대사)는 **PASS** 한다.
  → CREON.CVD_ANCHOR 만 FAIL 한다.
  누적거래량 차분 방식의 구조적 사각지대를 그대로 재현한 것이다.
"""
from __future__ import annotations

import sys

import numpy as np
import pandas as pd

from qdq import DQRunner, Cadence, Status, render_dashboard
from qdq.dashboard import build_timeline, problem_timestamps

RNG = np.random.default_rng(20260809)
TZ = "Asia/Seoul"
SYM = "101W09"                      # KOSPI200 선물 근월물
SESSION = ("09:00", "15:45")
LOSS_WINDOW = ("09:47", "09:50")    # 재접속 구간


def session_grid():
    d = pd.Timestamp("2026-08-07", tz=TZ)
    return pd.date_range(d + pd.Timedelta("09:00:00"), d + pd.Timedelta("15:45:00"),
                         freq="1min", inclusive="left").tz_convert("UTC")


def make_ticks(grid) -> pd.DataFrame:
    """FutureCurOnly 수신 이벤트를 모사.

    실제 필드: 현재가(1), 누적거래량(13), 시각(15), 누적체결매도(22),
              누적체결매수(23), 체결구분(24) — 체결가/체결수량은 제공되지 않는다.
    """
    rows, cum_v, cum_b, cum_s, px = [], 0.0, 0.0, 0.0, 350.0
    for t in grid:
        for k in range(RNG.integers(6, 18)):          # 분당 6~18 이벤트
            px = round((px + RNG.normal(0, 0.03)) / 0.05) * 0.05
            q = float(RNG.integers(1, 40))
            side = 1 if RNG.random() > 0.5 else -1     # 체결구분(24): 매수/매도
            cum_v += q
            if side > 0:
                cum_b += q
            else:
                cum_s += q
            rows.append({"ts": t + pd.Timedelta(seconds=k * 3), "symbol": SYM,
                         "price": px, "cum_volume": cum_v, "side": side,
                         "cum_buy": cum_b, "cum_sell": cum_s})
    return pd.DataFrame(rows)


def assemble_bars(ticks: pd.DataFrame) -> pd.DataFrame:
    """누적거래량 차분으로 틱 볼륨을 만들어 1분봉과 CVD를 조립한다 (실제 운영 로직과 동일)."""
    t = ticks.sort_values("ts").copy()
    t["qty"] = t["cum_volume"].diff().fillna(t["cum_volume"].iloc[0])
    t["signed"] = t["qty"] * t["side"]
    t["bar"] = t["ts"].dt.floor("1min")
    g = t.groupby("bar", observed=True)
    bars = pd.DataFrame({
        "ts": g["ts"].first().index,
        "symbol": SYM,
        "open": g["price"].first().values,
        "high": g["price"].max().values,
        "low": g["price"].min().values,
        "close": g["price"].last().values,
        "volume": g["qty"].sum().values,
        "buy_volume": g.apply(lambda x: x.loc[x.side > 0, "qty"].sum(),
                              include_groups=False).values,
        "sell_volume": g.apply(lambda x: x.loc[x.side < 0, "qty"].sum(),
                               include_groups=False).values,
        "cvd_1m": g["signed"].sum().values,
        "cum_volume": g["cum_volume"].last().values,
        "cum_buy": g["cum_buy"].last().values,
        "cum_sell": g["cum_sell"].last().values,
    }).reset_index(drop=True)
    bars["cvd_cum"] = bars["cvd_1m"].cumsum()
    return bars


def official_bars(full_ticks: pd.DataFrame) -> pd.DataFrame:
    """FutOptChart(차트구분 'm', 주기 1)로 받은 공식 1분봉 — 유실 없는 원본 기준."""
    t = full_ticks.sort_values("ts").copy()
    t["qty"] = t["cum_volume"].diff().fillna(t["cum_volume"].iloc[0])
    t["bar"] = t["ts"].dt.floor("1min")
    g = t.groupby("bar", observed=True)
    return pd.DataFrame({
        "ts": g["ts"].first().index, "symbol": SYM,
        "open": g["price"].first().values, "high": g["price"].max().values,
        "low": g["price"].min().values, "close": g["price"].last().values,
        "volume": g["qty"].sum().values,
    }).reset_index(drop=True)


def make_features(bars: pd.DataFrame, corrupt: bool) -> pd.DataFrame:
    f = bars.copy()
    c = f["close"].astype("float64")
    f["ret_1"] = np.log(c).diff()
    f["vol_20"] = f["ret_1"].rolling(20).std()
    # Hurst 근사 (R/S) — 평탄 구간에서 분모가 0이 되는 구조를 그대로 둔다
    w = 64
    def _hurst(x):
        x = np.asarray(x, dtype="float64")
        y = x - x.mean()
        r = np.ptp(np.cumsum(y))
        s = x.std(ddof=0)
        return np.log(r / s) / np.log(len(x)) if s > 0 and r > 0 else np.nan
    f["hurst"] = c.rolling(w).apply(_hurst, raw=True)
    mu, sd = f["ret_1"].expanding().mean(), f["ret_1"].expanding().std()
    # 주의: z-score를 그대로 ±1로 클리핑하면 1σ 밖(정규분포 기준 약 32%)이 전부
    # 경계에 눌린다. MATH.NORM_BOUND 가 이 설계를 포화율 24.8%로 잡아냈다.
    # → 3σ로 나눈 뒤 클리핑해야 [-1,1] 범위를 실제로 쓰게 된다.
    f["ret_z"] = ((f["ret_1"] - mu) / (3 * sd)).clip(-1, 1)
    f["cvd_z"] = (f["cvd_1m"] / f["volume"].replace(0, np.nan)).clip(-1, 1)
    if corrupt:
        # 극단장 클리핑 포화: 오후 구간을 경계에 눌러붙게
        f.loc[f.index[-90:], "ret_z"] = np.where(RNG.random(90) > .5, 1.0, -1.0)
    return f


def build(corrupt: bool = True) -> dict:
    grid = session_grid()
    full = make_ticks(grid)

    if corrupt:
        d = pd.Timestamp("2026-08-07", tz=TZ)
        lo = (d + pd.Timedelta(f"{LOSS_WINDOW[0]}:00")).tz_convert("UTC")
        hi = (d + pd.Timedelta(f"{LOSS_WINDOW[1]}:00")).tz_convert("UTC")
        # 큐 적체로 09:47~09:50 구간 이벤트의 70%를 드롭.
        # 봉 자체는 살아남고(분당 최소 1건은 수신), 누적거래량 차분이
        # 놓친 물량을 다음 이벤트로 흡수하므로 **거래량 총량은 그대로 맞는다.**
        # 오직 매수/매도 배분(CVD)과 봉 내부 고가/저가만 틀어진다.
        win = full["ts"].between(lo, hi, inclusive="left")
        keep = ~win
        for _, g in full[win].groupby(full.loc[win, "ts"].dt.floor("1min"),
                                      observed=True):
            idx = g.index.to_numpy()
            survivors = np.concatenate([idx[:1], idx[-1:],
                                        RNG.choice(idx, size=max(len(idx)//5, 1),
                                                   replace=False)])
            keep.loc[np.unique(survivors)] = True
        received = full[keep].copy()
    else:
        received = full.copy()

    bars = assemble_bars(received)
    official = official_bars(full)
    feat = make_features(bars, corrupt)

    n = 400
    hb_ts = pd.date_range(grid[0], grid[-1], freq="1min", tz="UTC")
    if corrupt:
        hb_ts = hb_ts[~hb_ts.isin(pd.date_range(
            pd.Timestamp("2026-08-07 00:47", tz="UTC"), periods=3, freq="1min"))]
    mem_hist = (np.linspace(820, 1490, 240) if corrupt else
                np.full(240, 640.0) + RNG.normal(0, 4, 240))

    return {
        "ticks": received, "bars": bars, "official": official, "feat": feat,
        "heartbeat": pd.DataFrame({"ts": hb_ts}),
        "is_connect": 1,
        "server_type": 1,
        "disconnect_events": 1 if corrupt else 0,
        "rss_mb": float(mem_hist[-1]),
        "mem_history": mem_hist,
        "queue_depth": 1830.0 if corrupt else 14.0,
        "queue_history": ([200, 620, 980, 1400, 1830] if corrupt else [12, 9, 14, 11, 14]),
        "subscribe_used": 392 if corrupt else 168,
        "requested_symbols": [SYM] + [f"OPT{i}" for i in range(1, 40)],
        "active_symbols": ([SYM] + [f"OPT{i}" for i in range(1, 36)]) if corrupt
                          else [SYM] + [f"OPT{i}" for i in range(1, 40)],
        "remain_nontrade": 12 if corrupt else 48,
        "remain_trade": 17,
        "remain_time_ms": 8200,
        "scaler_now": {"ret_1_mean": 1.2e-06, "ret_1_std": 0.00041},
        "scaler_trained": {"ret_1_mean": 1.2e-06,
                           "ret_1_std": 0.00052 if corrupt else 0.00041},
    }


def main(mode="dirty"):
    corrupt = mode != "clean"
    data = build(corrupt)
    runner = DQRunner("config/creon_suite.yaml")
    d = runner.cfg.setdefault("defaults", {})
    d.setdefault("CREON.HEARTBEAT", {})["now"] = data["heartbeat"]["ts"].max() + pd.Timedelta("20s")

    results = []
    for cad in (Cadence.REALTIME, Cadence.INTRADAY, Cadence.EOD, Cadence.WEEKLY):
        rep = runner.run(cad, data, run_id=f"creon-{mode}-{cad}")
        rep.print_summary()
        results.extend(rep.results)

    merged = runner.run(Cadence.EOD, data, run_id=f"creon-{mode}")
    merged.results, merged.cadence = results, "장중+EOD 통합"

    # 타임라인의 경고 구간은 손으로 찍지 않는다.
    # 점검 결과의 샘플에서 실제 사고 시각을 그대로 뽑아 쓴다.
    tl = build_timeline(data["bars"], data["official"],
                        warn_ts=problem_timestamps(results), tz=TZ)

    by = {r.check_id: r for r in results}

    def kpi(label, cid, fmt, thr):
        r = by.get(cid)
        v = "-" if r is None or r.metric is None else fmt(r.metric)
        return {"label": label, "value": v, "threshold": thr,
                "status": r.status if r else Status.SKIP}

    kpis = [
        kpi("봉 유실률", "RECON.BAR_COVERAGE", lambda x: f"{x:.2%}", "기준 < 0.20%"),
        kpi("거래량 대사 오차", "RECON.VOLUME_BIAS", lambda x: f"{x:.3%}", "기준 < 0.20%"),
        kpi("CVD 앵커 괴리", "CREON.CVD_ANCHOR", lambda x: f"{x:.2%}", "기준 < 2.0%"),
        {"label": "구독 슬롯", "value": f"{data['subscribe_used']}/400",
         "threshold": "경고 > 340", "status": by.get("CREON.SUBSCRIBE_SLOTS", None).status
         if "CREON.SUBSCRIBE_SLOTS" in by else Status.SKIP},
        {"label": "메모리 (32bit)", "value": f"{data['rss_mb']:.0f}MB",
         "threshold": "한계 2048MB · 경고 1331MB",
         "status": by["CREON.MEMORY"].status if "CREON.MEMORY" in by else Status.SKIP},
        {"label": "이벤트 큐", "value": f"{data['queue_depth']:.0f}",
         "threshold": "경고 > 500 · 실패 > 5000",
         "status": by["CREON.QUEUE_DEPTH"].status if "CREON.QUEUE_DEPTH" in by else Status.SKIP},
    ]

    out = f"out/dashboard_creon_{mode}.html"
    render_dashboard(merged, out, timeline=tl, kpis=kpis,
                     title="KOSPI200 파생 자동매매 콘솔")
    merged.save_json(f"out/dq_creon_{mode}.json")
    print(f"\n→ {out} 저장 완료 (게이트 {'OPEN' if merged.gate_open else 'CLOSED'})")

    if corrupt:
        vb, ca = by.get("RECON.VOLUME_BIAS"), by.get("CREON.CVD_ANCHOR")
        print("\n[시연] 누적거래량 차분의 사각지대")
        print(f"  RECON.VOLUME_BIAS  → {vb.status}: {vb.message}")
        print(f"  CREON.CVD_ANCHOR   → {ca.status}: {ca.message}")
    return merged


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "dirty")
