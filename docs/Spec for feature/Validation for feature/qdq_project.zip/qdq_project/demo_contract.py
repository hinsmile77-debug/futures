"""
demo_contract.py — 피처 계약 기반 범용 무결성 점검 데모.

  python demo_contract.py         # 오류 주입
  python demo_contract.py clean   # 정상

포인트: 여기서 CVD와 Hurst는 15개 피처 중 둘일 뿐이다.
점검 코드는 피처 이름을 하나도 모른다. 계약서(YAML)만 읽는다.
새 피처를 추가하려면 코드가 아니라 계약서에 8줄을 쓰면 된다.
"""
from __future__ import annotations

import sys

import numpy as np
import pandas as pd

from qdq import DQRunner, Cadence, Status, render_dashboard
from qdq.contract import load_contracts, contract_suite, coverage_report
from qdq.checks.contract_checks import register_contracts
from qdq.dashboard import build_timeline, problem_timestamps
from demo_creon import build as build_market, TZ

RNG = np.random.default_rng(11)


def build_features(bars: pd.DataFrame, corrupt: bool) -> pd.DataFrame:
    """계약서에 선언된 15개 피처를 실제로 계산한다."""
    f = bars.copy()
    c = f["close"].astype("float64")

    f["ret_1"] = np.log(c).diff()
    f["vol_20"] = f["ret_1"].rolling(20).std()

    d = c.diff()
    f["gain_ma_14"] = d.clip(lower=0).rolling(14).mean()
    f["loss_ma_14"] = (-d).clip(lower=0).rolling(14).mean()
    f["rsi_14"] = 100 - 100 / (1 + f["gain_ma_14"] / f["loss_ma_14"])

    pv = (c * f["volume"]).rolling(20).sum()
    f["vwap_20"] = pv / f["volume"].rolling(20).sum()
    f["vwap_dev"] = c / f["vwap_20"] - 1

    # 호가 (합성)
    f["bid1"] = c - 0.05
    f["ask1"] = c + 0.05
    f["bid1_qty"] = RNG.integers(1, 300, len(f)).astype("float64")
    f["ask1_qty"] = RNG.integers(1, 300, len(f)).astype("float64")
    f["obi"] = ((f.bid1_qty - f.ask1_qty) / (f.bid1_qty + f.ask1_qty))
    f["spread_bp"] = (f.ask1 - f.bid1) / ((f.ask1 + f.bid1) / 2) * 1e4

    # Hurst (R/S) — 분모가 0이 되는 구조를 그대로 둔다
    w = 64
    f["rolling_std_64"] = c.rolling(w).std(ddof=0)

    def _rs(x):
        x = np.asarray(x, dtype="float64")
        s = x.std(ddof=0)
        r = np.ptp(np.cumsum(x - x.mean()))
        return np.log(r / s) / np.log(len(x)) if s > 0 and r > 0 else np.nan

    f["hurst_64"] = c.rolling(w).apply(_rs, raw=True)

    # 파생 고유
    f["tau_years"] = 35 / 365
    f["basis_ann"] = RNG.normal(0.012, 0.003, len(f))
    f["iv_atm"] = 0.17 + 3 * f["vol_20"].fillna(0.001)
    f["open_interest"] = 120000 + np.cumsum(RNG.normal(0, 60, len(f)))
    f["oi_chg"] = f["open_interest"].pct_change()

    # 모델 입력
    mu, sd = f["ret_1"].expanding().mean(), f["ret_1"].expanding().std()
    f["ret_1_expanding_std"] = sd
    f["ret_z"] = ((f["ret_1"] - mu) / (3 * sd)).clip(-1, 1)
    f["cvd_z"] = (f["cvd_1m"] / f["volume"].replace(0, np.nan)).clip(-1, 1)

    f["fwd_ret"] = np.log(c).shift(-5) - np.log(c)

    if corrupt:
        # ① RSI 분모 0 (강한 상승 구간에서 loss_ma = 0)
        f.loc[120:132, "loss_ma_14"] = 0.0
        f.loc[120:132, "rsi_14"] = np.inf
        # ② 체결 분류 버그: 매수/매도 합이 총량과 안 맞음 (부등식은 통과한다)
        f.loc[200:206, "sell_volume"] = f.loc[200:206, "sell_volume"] * 0.7
        f.loc[200:206, "cvd_1m"] = (f.loc[200:206, "buy_volume"]
                                    - f.loc[200:206, "sell_volume"])
        # ③ 호가 불균형 스케일 오류 (0~1 정규화를 빠뜨림)
        f.loc[300:309, "obi"] = f.loc[300:309, "obi"] * 3.5
        # ④ IV 음수 (모형 수렴 실패)
        f.loc[50, "iv_atm"] = -0.02
        # ⑤ 계약서에 없는 피처가 슬쩍 추가됨 (가장 위험한 유형)
        f["new_alpha_v2"] = f["fwd_ret"].shift(-1) * 0.8      # 미래 참조까지 포함
    return f


def main(mode="dirty"):
    corrupt = mode != "clean"
    market = build_market(corrupt)
    feat = build_features(market["bars"], corrupt)

    contracts = load_contracts("config/feature_contracts.yaml")
    register_contracts(contracts)

    cfg = {
        "defaults": {},
        "suite": (contract_suite(contracts, data_key="feat")
                  + [{"check": "CONTRACT.COVERAGE", "dataset": "피처테이블",
                      "data": "feat",
                      "params": {"exclude": ["gain_ma_14", "loss_ma_14", "vwap_20",
                                             "rolling_std_64", "bid1", "ask1",
                                             "bid1_qty", "ask1_qty", "tau_years",
                                             "open_interest", "buy_volume",
                                             "sell_volume", "cum_volume", "cum_buy",
                                             "cum_sell", "ret_1_expanding_std",
                                             "gain_ma_14"]}}]),
    }
    runner = DQRunner(cfg)
    data = {"feat": feat}

    results = []
    for cad in (Cadence.INTRADAY, Cadence.EOD):
        rep = runner.run(cad, data, run_id=f"contract-{mode}-{cad}")
        rep.print_summary()
        results.extend(rep.results)

    merged = runner.run(Cadence.EOD, data, run_id=f"contract-{mode}")
    merged.results, merged.cadence = results, "피처 계약 점검"

    cov = coverage_report(contracts, feat.columns)
    print(f"\n[계약 커버리지] 선언 {cov['declared']}개 · "
          f"미선언 {len(cov['undeclared'])}개 {cov['undeclared'][:6]}")
    print("[축이 빈약한 계약]", cov["weakest"][:3])

    tl = build_timeline(market["bars"], market["official"],
                        warn_ts=problem_timestamps(results, checks=tuple(
                            r.check_id for r in results)), tz=TZ)
    kpis = []
    for cid, label in [("CONTRACT.INVARIANT", "불변식 위반"),
                       ("CONTRACT.RANGE", "치역 이탈"),
                       ("CONTRACT.SUPPORT", "정의구간 붕괴"),
                       ("CONTRACT.ANCHOR", "앵커 괴리"),
                       ("CONTRACT.HYGIENE", "위생 이상"),
                       ("CONTRACT.COVERAGE", "미선언 피처")]:
        hits = [r for r in results if r.check_id == cid]
        bad = [r for r in hits if r.status in (Status.WARN, Status.FAIL, Status.ERROR)]
        st = (Status.SKIP if not hits else
              max((r.status for r in hits), key=lambda s:
                  {"PASS": 0, "SKIP": 0, "WARN": 1, "FAIL": 2, "ERROR": 2}[s]))
        val = (f"{int(hits[0].metric)}개" if cid == "CONTRACT.COVERAGE" and hits
               else f"{len(bad)}/{len(hits)}")
        kpis.append({"label": label, "value": val,
                     "threshold": ("계약 미선언 0개" if cid == "CONTRACT.COVERAGE"
                                   else f"점검 피처 {len(hits)}개 중"),
                     "status": st})

    out = f"out/dashboard_contract_{mode}.html"
    render_dashboard(merged, out, timeline=tl, kpis=kpis,
                     title="피처 무결성 계약 점검")
    print(f"\n→ {out} (게이트 {'OPEN' if merged.gate_open else 'CLOSED'})")
    return merged


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "dirty")
