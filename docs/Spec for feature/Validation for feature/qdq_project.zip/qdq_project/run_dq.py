"""
run_dq.py — 크론/스케줄러가 호출하는 엔트리포인트.

  python run_dq.py --cadence realtime
  python run_dq.py --cadence eod --out out/eod

종료코드 규약 (스케줄러가 이걸 보고 후속 잡을 태울지 결정한다):
  0 = 정상 (게이트 OPEN)
  1 = 경고 있음 (게이트 OPEN, 알림만)
  2 = 게이트 CLOSED — 시그널 생성/주문 실행 잡을 태우면 안 됨
  3 = 점검기 자체 오류

crontab 예시 (KST 기준, 파생 정규장 + 야간장):
  # 실시간: 장중 1분마다
  */1 9-15,18-23 * * 1-5  cd /opt/quant && python run_dq.py --cadence realtime
  */1 0-5       * * 2-6   cd /opt/quant && python run_dq.py --cadence realtime
  # 장중 배치: 5분마다
  */5 9-15,18-23 * * 1-5  cd /opt/quant && python run_dq.py --cadence intraday
  # EOD: 정산 데이터가 확정되는 16:10, 야간장 마감 후 05:30
  10 16 * * 1-5           cd /opt/quant && python run_dq.py --cadence eod
  30 5  * * 2-6           cd /opt/quant && python run_dq.py --cadence eod
  # 주간: 일요일 09:00 (드리프트·개정·누수 감사)
  0 9 * * 0               cd /opt/quant && python run_dq.py --cadence weekly
  # 월간: 1일 09:00 (골든 데이터셋 재현성)
  0 9 1 * *               cd /opt/quant && python run_dq.py --cadence monthly
"""
from __future__ import annotations

import argparse
import sys
import traceback

from qdq import DQRunner, Status, render_html


def load_data(cadence: str) -> dict:
    """점검 대상 데이터를 적재해 dict로 반환.

    실제 운영에서는 여기서 DB/파케이/피처스토어를 읽는다.
    본 예제는 demo.build() 의 합성 데이터를 사용한다.
    """
    from demo import build
    return build(corrupt=False)


def configure(runner, data) -> None:
    """런타임에만 알 수 있는 파라미터를 주입한다 (기대 행 수, 기준 시각 등).

    합성 데이터는 과거 시점이므로 '현재 시각'을 데이터 끝에 맞춘다.
    실제 운영에서는 이 블록을 지우고 실제 wall-clock 을 그대로 쓰면 된다.
    """
    import pandas as pd
    from demo import SYMS, TRADING_DAYS
    d = runner.cfg.setdefault("defaults", {})
    d["FEAT.ROWCOUNT"] = {"expected": 1065 * TRADING_DAYS * len(SYMS)}
    d.setdefault("FEED.HEARTBEAT", {})["now"] = \
        data["ticks"]["recv_ts"].max() + pd.Timedelta(seconds=2)
    d.setdefault("FEAT.FRESHNESS", {})["now"] = \
        pd.to_datetime(data["feat_online"]["ts"], utc=True).max() + pd.Timedelta(seconds=30)
    d.setdefault("MACRO.STALENESS", {})["now"] = pd.Timestamp("2026-08-09", tz="UTC")


def notify(report, webhook: str | None) -> None:
    """FAIL/게이트차단은 즉시 알림. (Slack/PagerDuty 훅 자리)"""
    if report.gate_open and report.status in (Status.PASS, Status.SKIP):
        return
    head = "⛔ 데이터 게이트 CLOSED" if not report.gate_open else "⚠️ 데이터 품질 경고"
    lines = [f"{head} — {report.cadence} / {report.run_id}"]
    for r in report.results:
        if r.status in (Status.WARN, Status.FAIL, Status.ERROR):
            lines.append(f"  [{r.status}] {r.check_id} ({r.dataset}) {r.message}")
    msg = "\n".join(lines)
    print(msg, file=sys.stderr)
    if webhook:
        try:
            import json
            import urllib.request
            req = urllib.request.Request(
                webhook, data=json.dumps({"text": msg}).encode(),
                headers={"Content-Type": "application/json"})
            urllib.request.urlopen(req, timeout=5)
        except Exception as e:  # noqa: BLE001
            print(f"알림 전송 실패: {e}", file=sys.stderr)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--cadence", required=True,
                    choices=["realtime", "intraday", "eod", "weekly", "monthly"])
    ap.add_argument("--config", default="config/dq_suite.yaml")
    ap.add_argument("--out", default="out")
    ap.add_argument("--webhook", default=None)
    a = ap.parse_args()

    try:
        runner = DQRunner(a.config)
        data = load_data(a.cadence)
        configure(runner, data)
        rep = runner.run(a.cadence, data)
    except Exception:                       # 점검기 자체가 죽으면 fail-closed
        traceback.print_exc()
        print("점검기 실행 실패 → 안전을 위해 게이트를 닫습니다.", file=sys.stderr)
        return 3

    rep.print_summary()
    rep.save_json(f"{a.out}/dq_{a.cadence}_{rep.run_id}.json")
    render_html(rep, f"{a.out}/dq_{a.cadence}_latest.html",
                title=f"무결성 점검 · {a.cadence}")
    notify(rep, a.webhook)

    if not rep.gate_open:
        return 2
    if rep.status in (Status.WARN,):
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
