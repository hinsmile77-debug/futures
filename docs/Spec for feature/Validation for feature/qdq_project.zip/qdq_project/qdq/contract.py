"""
qdq.contract — 피처 계약(Feature Contract).

핵심 발상:
  피처마다 점검 코드를 따로 짜면 피처가 100개일 때 점검 코드도 100개가 된다.
  그러면 새 피처가 추가될 때 점검이 빠지고, 빠진 줄도 모른다.

  대신 **피처가 스스로 자기 성질을 선언**하게 한다.
  "나는 [0,100] 안에 있어야 하고, 분모에 rolling_std가 들어가고,
   과거 64봉만 보고, 서버에 정답지가 있다" 라고 써두면
  점검 코드는 그 선언에서 자동으로 생성된다.

비유: 식품 영양성분표.
  제품마다 검사 방법을 새로 발명하지 않는다.
  성분표 양식이 정해져 있고, 검사는 그 양식의 항목을 하나씩 확인할 뿐이다.
  새 제품이 나와도 검사 체계는 그대로다.

────────────────────────────────────────────────────────────────
피처 무결성의 7개 축 — 어떤 피처든 이 7가지로 환원된다
────────────────────────────────────────────────────────────────
  ① 치역 (range)      값이 있을 수 있는 구간. 이론 경계와 추정량 경계를 구분한다.
  ② 불변식 (invariant) 항상 참이어야 하는 등식/부등식. 가장 강력한 검증.
  ③ 정의구간 (support) 계산이 성립하지 않는 조건 (분모 0, log 음수, 표본 부족).
  ④ 인과성 (causality) 계산에 미래 데이터가 들어갔는가.
  ⑤ 앵커 (anchor)     외부에 정답지가 있는가. 있으면 '말이 되는지' 대신 '맞는지'를 본다.
  ⑥ 위생 (hygiene)    결측·inf·상수화·워밍업.
  ⑦ 안정성 (stability) 분포 드리프트, 스케일러 파라미터 고정, 재현성.

CVD와 Hurst는 이 틀의 두 사례일 뿐이다.
  · CVD  → ② 불변식(Buy+Sell=Volume) + ⑤ 앵커(누적체결매수−매도)가 강한 축
  · Hurst→ ① 치역(이론 (0,1) vs 추정량) + ③ 정의구간(분모 0)이 강한 축
같은 틀로 RSI·IV·베이시스·롤링 상관·임베딩 무엇이든 채울 수 있다.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np
import pandas as pd
import yaml

# 계약식에서 쓸 수 있는 안전한 이름들 (계약서는 팀이 작성하는 신뢰된 입력)
SAFE_FUNCS: dict[str, Any] = {
    "abs": abs, "min": min, "max": max, "np": np,
    "sqrt": np.sqrt, "log": np.log, "exp": np.exp, "sign": np.sign,
    "isfinite": np.isfinite, "where": np.where,
}


@dataclass
class FeatureContract:
    """한 피처가 지켜야 할 성질의 선언."""
    name: str
    desc: str = ""
    unit: str = ""

    # ① 치역 — hard 는 절대 넘을 수 없는 값, soft 는 이론 경계(추정량은 넘을 수 있음)
    lo: float | None = None
    hi: float | None = None
    soft_lo: float | None = None
    soft_hi: float | None = None
    range_fail_ratio: float = 0.0        # hard 이탈 허용 비율
    soft_warn_ratio: float = 0.01        # soft 이탈 경고 비율

    # ② 불변식 — 항상 참이어야 하는 식 (문자열, 컬럼명을 변수로 사용)
    invariants: list[str] = field(default_factory=list)

    # ③ 정의구간 — 이 식이 0에 가까우면 계산이 성립하지 않는다
    denominator: str | None = None
    denom_eps: float = 1e-12

    # ④ 인과성 — 뒤를 보는 창(과거 N봉)과 미래 참조 허용 여부
    lookback: int = 0
    allow_forward: bool = False          # 타깃(fwd_ret)만 True

    # ⑤ 앵커 — 외부 정답지 식. diff=True면 증분끼리 비교(누적 희석 방지)
    anchor: str | None = None
    anchor_scale: str | None = None
    anchor_diff: bool = True
    anchor_warn: float = 0.005
    anchor_fail: float = 0.02

    # ⑥ 위생
    null_warn: float = 0.01
    null_fail: float = 0.05
    warmup: int = 0                      # 롤링 워밍업 행 수 (선두 NaN 허용)
    min_unique: int = 3

    # ⑦ 안정성
    psi_warn: float = 0.10
    psi_fail: float = 0.25
    stationary: bool = True              # False면 PSI 대상에서 제외(가격 레벨 등)

    gating: bool = True

    @property
    def effective_warmup(self) -> int:
        return self.warmup or max(self.lookback - 1, 0)


def load_contracts(src: str | dict) -> dict[str, FeatureContract]:
    """YAML 파일 경로 또는 dict 에서 계약서를 읽는다."""
    if isinstance(src, str):
        with open(src, encoding="utf-8") as f:
            src = yaml.safe_load(f)
    raw = src.get("features", src) if isinstance(src, dict) else {}
    out: dict[str, FeatureContract] = {}
    for name, spec in (raw or {}).items():
        spec = dict(spec or {})
        spec.pop("name", None)
        out[name] = FeatureContract(name=name, **spec)
    return out


# ------------------------------------------------------------ 식 평가

def eval_expr(expr: str, df: pd.DataFrame) -> pd.Series:
    """계약식을 DataFrame 컬럼 위에서 평가한다.

    계약서는 팀이 작성하는 신뢰된 파일이므로 제한 네임스페이스 eval 로 충분하다.
    (외부 입력을 계약식으로 받는 구조라면 여기서 파서를 써야 한다)
    """
    ns = {c: df[c] for c in df.columns}
    ns.update(SAFE_FUNCS)
    res = eval(expr, {"__builtins__": {}}, ns)  # noqa: S307 - 신뢰된 계약식
    if np.isscalar(res):
        res = pd.Series(np.full(len(df), res), index=df.index)
    return pd.Series(res, index=df.index) if not isinstance(res, pd.Series) else res


def active_mask(df: pd.DataFrame, c: FeatureContract) -> np.ndarray:
    """워밍업 구간을 제외한 '평가 대상' 마스크.

    롤링 워밍업의 NaN을 사고로 세면 모든 롤링 피처가 매일 FAIL 한다.
    그런 알림은 일주일이면 아무도 안 본다.
    """
    m = np.ones(len(df), dtype=bool)
    w = c.effective_warmup
    if w:
        m[:min(w, len(m))] = False
    return m


# ------------------------------------------------------------ 스위트 생성

#: 계약의 각 축 → 실행할 체크 ID
CONTRACT_AXES = [
    ("range", "CONTRACT.RANGE"),
    ("invariant", "CONTRACT.INVARIANT"),
    ("support", "CONTRACT.SUPPORT"),
    ("anchor", "CONTRACT.ANCHOR"),
    ("hygiene", "CONTRACT.HYGIENE"),
]


def contract_suite(contracts: dict[str, FeatureContract], *, data_key: str,
                   cadence: str | None = None) -> list[dict]:
    """계약서 → 러너 스위트 항목. 피처가 늘어나도 스위트는 자동으로 늘어난다.

    dataset 에 피처 이름을 넣어서 리포트/대시보드에서 피처 단위로 보이게 한다.
    """
    items = []
    for name, c in contracts.items():
        for axis, cid in CONTRACT_AXES:
            if axis == "invariant" and not c.invariants:
                continue
            if axis == "support" and not c.denominator:
                continue
            if axis == "anchor" and not c.anchor:
                continue
            if axis == "range" and c.lo is None and c.hi is None \
                    and c.soft_lo is None and c.soft_hi is None:
                continue
            item = {"check": cid, "dataset": name, "data": data_key,
                    "params": {"contract": name}}
            if cadence:
                item["cadence"] = cadence
            items.append(item)
    return items


def coverage_report(contracts: dict[str, FeatureContract],
                    df_columns) -> dict:
    """계약 커버리지 — '점검되지 않는 피처'를 찾아낸다.

    가장 위험한 피처는 임계치를 넘은 피처가 아니라
    **아무도 계약을 안 써둔 피처**다. 그건 영원히 통과한다.
    """
    cols = {c for c in df_columns}
    declared = set(contracts)
    axes_filled = {}
    for n, c in contracts.items():
        filled = sum([
            c.lo is not None or c.hi is not None or c.soft_lo is not None,
            bool(c.invariants), bool(c.denominator),
            c.lookback > 0 or c.allow_forward, bool(c.anchor),
            True,                                     # 위생은 항상 적용
            c.stationary is not None,
        ])
        axes_filled[n] = filled
    undeclared = sorted(c for c in cols - declared
                        if not c.startswith("_") and c not in
                        ("ts", "symbol", "open", "high", "low", "close", "volume"))
    return {"declared": len(declared), "undeclared": undeclared,
            "axes_filled": axes_filled,
            "weakest": sorted(axes_filled.items(), key=lambda x: x[1])[:5]}
