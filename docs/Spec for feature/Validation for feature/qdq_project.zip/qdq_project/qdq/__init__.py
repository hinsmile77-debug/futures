"""qdq — Quant Data Quality: 시장 데이터/피처 무결성 점검 프레임워크."""
from .core import (CheckResult, Cadence, Layer, Status, REGISTRY, check,
                   judge, worst)
from .runner import DQRunner, DQReport, RECOVERY_PLAYBOOK
from .report import render_html
from .dashboard import render_dashboard, build_timeline
from .contract import FeatureContract, load_contracts, contract_suite, coverage_report

__all__ = ["CheckResult", "Cadence", "Layer", "Status", "REGISTRY", "check",
           "judge", "worst", "DQRunner", "DQReport", "RECOVERY_PLAYBOOK",
           "render_html", "render_dashboard", "build_timeline",
           "FeatureContract", "load_contracts", "contract_suite",
           "coverage_report"]
__version__ = "0.1.0"
