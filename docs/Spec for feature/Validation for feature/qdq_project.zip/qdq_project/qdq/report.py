"""qdq.report — 점검 결과 HTML 리포트 생성 (자체 완결형, 라이트/다크 모두 지원)."""
from __future__ import annotations

import html
import json
import os

from .core import Status
from .runner import RECOVERY_PLAYBOOK

_ICON = {Status.PASS: "●", Status.WARN: "▲", Status.FAIL: "■",
         Status.ERROR: "✖", Status.SKIP: "○"}
_LABEL = {Status.PASS: "정상", Status.WARN: "경고", Status.FAIL: "실패",
          Status.ERROR: "오류", Status.SKIP: "생략"}

_CSS = """
:root{color-scheme:light;--surface-0:#f6f5f2;--surface-1:#fcfcfb;--border:#e3e2dd;
--text-primary:#0b0b0b;--text-secondary:#52514e;--text-muted:#78766f;
--good:#0ca30c;--warning:#fab219;--serious:#ec835a;--critical:#d03b3b;--neutral:#9a988f;}
@media(prefers-color-scheme:dark){:root{color-scheme:dark;--surface-0:#111110;
--surface-1:#1a1a19;--border:#2f2f2c;--text-primary:#fff;--text-secondary:#c3c2b7;
--text-muted:#8f8e85;}}
*{box-sizing:border-box}
body{margin:0;padding:32px 20px;background:var(--surface-0);color:var(--text-primary);
font:14px/1.55 -apple-system,BlinkMacSystemFont,"Segoe UI","Noto Sans KR",sans-serif;}
.wrap{max-width:1120px;margin:0 auto}
h1{font-size:20px;margin:0 0 4px}
.sub{color:var(--text-secondary);font-size:13px;margin-bottom:20px}
.gate{display:flex;align-items:baseline;flex-wrap:wrap;gap:4px 10px;padding:14px 18px;
border-radius:10px;border:1px solid var(--border);background:var(--surface-1);
margin-bottom:18px;font-weight:600}
.gate .lbl{white-space:nowrap}
.gate .why{font-weight:400;color:var(--text-secondary);flex:1 1 100%;font-size:12px;
line-height:1.5;word-break:break-word}
.gate .dot{font-size:16px}
.tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:10px;margin-bottom:22px}
.tile{background:var(--surface-1);border:1px solid var(--border);border-radius:10px;padding:12px 14px}
.tile .n{font-size:24px;font-weight:650;letter-spacing:-.02em}
.tile .k{font-size:12px;color:var(--text-secondary);display:flex;align-items:center;gap:6px;margin-top:2px}
table{width:100%;border-collapse:collapse;background:var(--surface-1);
border:1px solid var(--border);border-radius:10px;overflow:hidden}
th,td{text-align:left;padding:9px 12px;border-bottom:1px solid var(--border);vertical-align:top}
th{font-size:12px;color:var(--text-secondary);font-weight:600;background:var(--surface-0)}
td.mono{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:12px;white-space:nowrap}
tr:last-child td{border-bottom:none}
.badge{display:inline-flex;align-items:center;gap:5px;font-size:12px;font-weight:600;white-space:nowrap}
details{margin-top:6px}
summary{cursor:pointer;color:var(--text-muted);font-size:12px}
pre{margin:6px 0 0;padding:8px 10px;background:var(--surface-0);border:1px solid var(--border);
border-radius:6px;font-size:11px;overflow-x:auto;color:var(--text-secondary)}
.fix{margin-top:6px;font-size:12px;color:var(--text-secondary);
border-left:3px solid var(--serious);padding-left:8px}
.sec{font-size:13px;font-weight:650;margin:26px 0 8px;color:var(--text-secondary)}
"""

_COLOR = {Status.PASS: "var(--good)", Status.WARN: "var(--warning)",
          Status.FAIL: "var(--critical)", Status.ERROR: "var(--critical)",
          Status.SKIP: "var(--neutral)"}


def _badge(st: str) -> str:
    return (f'<span class="badge" style="color:{_COLOR[st]}">'
            f'{_ICON[st]} {_LABEL[st]}</span>')


def render_html(report, path: str, title: str = "시장데이터 무결성 점검 리포트") -> str:
    c = report.counts()
    order = {Status.ERROR: 0, Status.FAIL: 1, Status.WARN: 2,
             Status.SKIP: 3, Status.PASS: 4}
    rows = []
    for r in sorted(report.results, key=lambda x: (order[x.status], x.layer, x.check_id)):
        metric = "-" if r.metric is None else f"{r.metric:.6g}"
        extra = ""
        if r.sample:
            extra += ("<details><summary>위반 샘플</summary><pre>"
                      + html.escape(json.dumps(r.sample, ensure_ascii=False, indent=1,
                                               default=str)[:1200])
                      + "</pre></details>")
        if r.status in (Status.FAIL, Status.ERROR) and r.check_id in RECOVERY_PLAYBOOK:
            extra += f'<div class="fix">대응: {html.escape(RECOVERY_PLAYBOOK[r.check_id])}</div>'
        rows.append(
            f"<tr><td>{_badge(r.status)}{' 🔒' if r.gating else ''}</td>"
            f'<td class="mono">{html.escape(r.check_id)}</td>'
            f'<td class="mono">{html.escape(r.layer)}</td>'
            f'<td class="mono">{html.escape(r.dataset)}</td>'
            f'<td class="mono">{metric}</td>'
            f"<td>{html.escape(r.message)}"
            f'<div style="color:var(--text-muted);font-size:11px;margin-top:2px">'
            f"기준: {html.escape(r.threshold or '-')}</div>{extra}</td></tr>")

    tiles = "".join(
        f'<div class="tile"><div class="n" style="color:{_COLOR[s]}">{c[s]}</div>'
        f'<div class="k"><span style="color:{_COLOR[s]}">{_ICON[s]}</span>{_LABEL[s]}</div></div>'
        for s in (Status.PASS, Status.WARN, Status.FAIL, Status.ERROR, Status.SKIP))

    gate_ok = report.gate_open
    gate_html = (
        f'<div class="gate"><span class="dot" style="color:'
        f'{"var(--good)" if gate_ok else "var(--critical)"}">'
        f'{"●" if gate_ok else "■"}</span>'
        f'<span class="lbl">모델 입력 게이트: '
        f'{"OPEN — 시그널 생성 허용" if gate_ok else "CLOSED — 시그널 생성/주문 차단"}</span>'
        + ("" if gate_ok else
           f'<span class="why">차단 사유: '
           f'{html.escape(", ".join(b.check_id for b in report.blockers))}</span>')
        + "</div>")

    doc = f"""<!doctype html><html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{html.escape(title)}</title><style>{_CSS}</style></head><body><div class="wrap">
<h1>{html.escape(title)}</h1>
<div class="sub">run_id <b>{html.escape(report.run_id)}</b> · 주기 <b>{html.escape(report.cadence)}</b>
 · 실행 {html.escape(report.started_at)} · 종합 판정 {_badge(report.status)}</div>
{gate_html}
<div class="tiles">{tiles}</div>
<div class="sec">점검 상세 (심각도 순 · 🔒 = 게이팅 항목)</div>
<table><thead><tr><th>상태</th><th>체크 ID</th><th>레이어</th><th>데이터셋</th>
<th>지표</th><th>내용</th></tr></thead><tbody>{''.join(rows)}</tbody></table>
<div class="sec">참고</div>
<div style="color:var(--text-secondary);font-size:12px">
게이팅(🔒) 항목이 하나라도 실패하면 fail-closed 원칙에 따라 해당 배치의 시그널 생성과 주문 실행을 차단합니다.
경고(▲)는 차단하지 않지만 24시간 내 원인 규명이 필요합니다.</div>
</div></body></html>"""
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(doc)
    return path
