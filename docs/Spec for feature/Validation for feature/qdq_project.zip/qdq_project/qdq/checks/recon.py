"""
L2 RECON — 자체 조립 분봉 vs 크레온 공식 분봉(FutOptChart) 교차 검증.

  조회: CpSysDib.FutOptChart
        SetInputValue(0, 종목코드) / (1, '2'=개수 or '1'=기간)
        (6, 'm')  차트구분 = 분
        (7, 1)    주기 = 1분
        (5, [필드배열])  → 시간·시가·고가·저가·종가·거래량·미결제약정
  주의: 시세 요청은 15초당 60건. 옵션 체인 전체를 대사하려면
        요청 페이싱을 넣어야 하고, EOD 배치에 그만큼 시간을 잡아둬야 한다.

비유: 손으로 적은 가계부와 은행 거래내역서 대조.
  총액만 맞춰보면 "얼추 맞네" 하고 넘어가지만,
  제대로 하려면 세 가지를 봐야 한다.
    ① 방향   — 내 장부가 *덜* 적혔나 *더* 적혔나 (유실 vs 중복은 원인이 정반대)
    ② 분포   — 오차가 고르게 퍼졌나, 특정 시각에 뭉쳤나 (뭉쳤으면 그 시각에 끊긴 것)
    ③ 항목별 — 고가·저가는 틱 하나만 놓쳐도 틀리고, 종가는 마지막 틱만 맞으면 맞는다

  그래서 "오차 0.1% 이하" 단일 조건으로는 부족하다.
  0.05%가 하루에 고르게 퍼진 것과 3개 봉에 몰린 것은 완전히 다른 사고다.

⚠ 크레온 한정 사각지대 — 이 모듈만으로는 못 잡는 것:
  파생 실시간(FutureCurOnly)은 체결수량을 주지 않아 누적거래량 차분으로 틱을 만든다.
  이벤트를 놓쳐도 **다음 차분이 놓친 물량을 통째로 흡수**하므로 총 거래량은 그대로 맞는다.
  즉 RECON.VOLUME_BIAS 가 PASS 여도 CVD는 틀려 있을 수 있다.
  이 구멍은 CREON.CVD_ANCHOR(누적체결매수−매도 대조)로만 막힌다.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from ..core import CheckResult, Cadence, Layer, Status, check, judge


def _align(mine: pd.DataFrame, official: pd.DataFrame, keys: list[str]) -> pd.DataFrame:
    return mine.merge(official, on=keys, how="outer",
                      suffixes=("_mine", "_off"), indicator=True)


@check("RECON.BAR_COVERAGE", layer=Layer.CURATED, cadence=Cadence.EOD, gating=True,
       desc="공식 분봉에는 있는데 자체 DB에는 없는 봉(=수신 공백). 유실의 가장 직접적인 증거.")
def bar_coverage(mine, dataset="-", official=None, keys=("ts", "symbol"),
                 warn_ratio=0.0, fail_ratio=0.002) -> CheckResult:
    if official is None:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP, message="공식 분봉(TR) 미제공 → 대사 생략")
    keys = list(keys)
    m = _align(mine[keys], official[keys], keys)
    only_off = m["_merge"] == "right_only"     # 공식엔 있고 내겐 없음 = 유실
    only_mine = m["_merge"] == "left_only"     # 내겐 있고 공식엔 없음 = 유령 봉
    total = max(len(official), 1)
    ratio = int(only_off.sum()) / total
    st = judge(ratio, warn_ratio, fail_ratio)
    if only_mine.any():
        st = Status.FAIL                        # 공식에 없는 봉을 만들어냈다면 조립 로직 버그

    # 유실이 연속 구간인지 흩어져 있는지 — 연속이면 '끊김', 흩어지면 '샘플 누락'
    miss_ts = pd.to_datetime(m.loc[only_off, keys[0]], utc=True).sort_values()
    runs, longest = [], 0
    if len(miss_ts):
        grp = (miss_ts.diff() != pd.Timedelta(minutes=1)).cumsum()
        runs = miss_ts.groupby(grp).agg(["min", "count"]).values.tolist()
        longest = int(max(r[1] for r in runs))

    return CheckResult(
        check_id="", layer="", cadence="", dataset=dataset, status=st,
        metric=ratio, threshold=f"유실률 warn>{warn_ratio:.2%}, fail>{fail_ratio:.2%} / 유령봉 0건",
        n_bad=int(only_off.sum()) + int(only_mine.sum()), n_total=total,
        sample=[{"연속유실구간": [[str(r[0]), int(r[1])] for r in runs[:5]],
                 "유령봉": int(only_mine.sum())}],
        message=(f"미수신 {int(only_off.sum())}봉 / 공식 {total}봉 ({ratio:.3%}), "
                 f"최장 연속 {longest}분"
                 + (f", 유령봉 {int(only_mine.sum())}개(조립 로직 버그)" if only_mine.any() else "")),
    )


@check("RECON.VOLUME_BIAS", layer=Layer.CURATED, cadence=Cadence.EOD, gating=True,
       desc="거래량 오차의 크기 + 부호 편향. 틱 유실은 '항상 부족한' 쪽으로 치우치므로 부호가 원인을 알려준다.")
def volume_bias(mine, dataset="-", official=None, keys=("ts", "symbol"), vol="volume",
                warn_ratio=0.0005, fail_ratio=0.002, bias_warn=0.7,
                bar_warn_ratio=0.01, bar_fail_ratio=0.05) -> CheckResult:
    """세 가지를 동시에 본다.

      ① 총 거래량 상대오차   |Σmine − Σoff| / Σoff
      ② 부호 편향            오차가 난 봉 중 '내 쪽이 적은' 비율 (틱 유실이면 1.0에 근접)
      ③ 봉 단위 불일치율     오차가 몇 %의 봉에서 발생했나 (집중도)
    """
    if official is None:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP, message="공식 분봉(TR) 미제공 → 대사 생략")
    keys = list(keys)
    m = _align(mine[keys + [vol]], official[keys + [vol]], keys)
    both = m[m["_merge"] == "both"].copy()
    if both.empty:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.FAIL, message="공통 봉이 하나도 없음 — 키/타임존 정렬 확인")

    a = both[f"{vol}_mine"].astype("float64")
    b = both[f"{vol}_off"].astype("float64")
    diff = a - b
    tot_ratio = float(abs(diff.sum()) / max(abs(b.sum()), 1.0))

    mismatch = diff != 0
    n_mis = int(mismatch.sum())
    bar_ratio = n_mis / len(both)
    under = int((diff < 0).sum())
    bias = under / max(n_mis, 1)               # 1.0 = 전부 '내 쪽이 적음' = 전형적 틱 유실

    st = judge(tot_ratio, warn_ratio, fail_ratio)
    st_bar = judge(bar_ratio, bar_warn_ratio, bar_fail_ratio)
    if st_bar == Status.FAIL:
        st = Status.FAIL
    elif st_bar == Status.WARN and st == Status.PASS:
        st = Status.WARN

    if n_mis and bias >= bias_warn and st == Status.PASS:
        st = Status.WARN                        # 총량은 작아도 한 방향으로 쏠리면 구조적 유실

    diag = "정상"
    if n_mis:
        if bias >= bias_warn:
            diag = f"체계적 틱 유실 의심 (불일치 봉의 {bias:.0%}가 자체<공식)"
        elif bias <= 1 - bias_warn:
            diag = f"중복 집계 의심 (불일치 봉의 {1-bias:.0%}가 자체>공식)"
        else:
            diag = "양방향 혼재 — 체결 분류/집계 경계(봉 끝단) 로직 점검"

    worst = both.assign(_d=diff.abs()).nlargest(5, "_d")
    return CheckResult(
        check_id="", layer="", cadence="", dataset=dataset, status=st,
        metric=tot_ratio,
        threshold=(f"총오차 warn>{warn_ratio:.2%}, fail>{fail_ratio:.2%} / "
                   f"불일치봉 warn>{bar_warn_ratio:.0%}, fail>{bar_fail_ratio:.0%} / "
                   f"부호편향 {bias_warn:.0%} 초과 시 경고"),
        n_bad=n_mis, n_total=len(both),
        sample=worst[keys + [f"{vol}_mine", f"{vol}_off"]].astype(str).to_dict("records"),
        message=(f"총 거래량 오차 {tot_ratio:.4%} (자체 {a.sum():,.0f} vs 공식 {b.sum():,.0f}), "
                 f"불일치 {n_mis}/{len(both)}봉 ({bar_ratio:.2%}) · {diag}"),
    )


@check("RECON.OHLC_DIFF", layer=Layer.CURATED, cadence=Cadence.EOD, gating=True,
       desc="OHLC 항목별 불일치율. 고가/저가는 틱 하나만 놓쳐도 틀리므로 유실의 조기 지표다.")
def ohlc_diff(mine, dataset="-", official=None, keys=("ts", "symbol"),
              cols=("open", "high", "low", "close"), tick=0.05,
              warn_ratio=0.001, fail_ratio=0.005) -> CheckResult:
    if official is None:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP, message="공식 분봉(TR) 미제공 → 대사 생략")
    keys = list(keys)
    cols = [c for c in cols if c in mine.columns and c in official.columns]
    m = _align(mine[keys + cols], official[keys + cols], keys)
    both = m[m["_merge"] == "both"]
    if both.empty:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.FAIL, message="공통 봉 없음")

    per_col, worst_ratio, samples = {}, 0.0, []
    for c in cols:
        d = (both[f"{c}_mine"].astype("float64") - both[f"{c}_off"].astype("float64")).abs()
        bad = d > tick / 2                      # 호가단위 절반 이상 차이 = 실제 불일치
        r = float(bad.mean())
        per_col[c] = round(r, 6)
        worst_ratio = max(worst_ratio, r)
        if bad.any() and len(samples) < 5:
            row = both.loc[bad, keys + [f"{c}_mine", f"{c}_off"]].head(2)
            samples += row.astype(str).to_dict("records")

    st = judge(worst_ratio, warn_ratio, fail_ratio)
    # 고가/저가만 틀리고 종가는 맞으면 → 봉 내부 틱을 놓친 것 (마지막 틱만 받은 상태)
    hint = ""
    if per_col.get("close", 1) == 0 and max(per_col.get("high", 0), per_col.get("low", 0)) > 0:
        hint = " · 종가는 일치하나 고/저가 불일치 → 봉 내부 틱 유실 패턴"
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=worst_ratio,
                       threshold=f"항목별 불일치율 warn>{warn_ratio:.2%}, fail>{fail_ratio:.2%}",
                       n_bad=int(worst_ratio * len(both)), n_total=len(both),
                       sample=[per_col] + samples,
                       message=f"항목별 불일치율 {per_col}{hint}")


# ------------------------------------------------------------ 확정(Commit) 판정

def commit_decision(results: list, *, overwrite_on_fail: bool = True) -> dict:
    """대사 결과를 보고 '자체 DB를 그대로 확정할지 / 공식 데이터로 덮어쓸지' 결정한다.

    덮어쓰기 정책에 대한 한 가지 단서:
      공식 데이터로 덮어쓰되, **자체 조립본을 지우지 말고 별도 테이블에 보존**한다.
      두 버전을 모두 갖고 있어야 나중에 "그날 왜 유실됐나"를 추적할 수 있고,
      실시간 피처(CVD 등)는 애초에 틱에서만 나오므로 공식 분봉으로 복원되지 않는다.
      (FutOptChart 는 OHLCV·미결제약정까지만 준다. 체결구분별 물량은 안 준다.)
      즉 덮어쓰기는 OHLCV 복구이지 피처 복구가 아니다 — 유실 구간의 피처는 마스킹해야 한다.
    """
    by_id = {r.check_id: r for r in results}
    recon_ids = ["RECON.BAR_COVERAGE", "RECON.VOLUME_BIAS", "RECON.OHLC_DIFF"]
    hits = [by_id[i] for i in recon_ids if i in by_id]
    if not hits:
        return {"action": "SKIP", "reason": "대사 결과 없음", "mask_feature_ts": []}

    worst = max((r.status for r in hits),
                key=lambda s: {"PASS": 0, "SKIP": 0, "WARN": 1, "FAIL": 2, "ERROR": 2}[s])
    masked: list[str] = []
    cov = by_id.get("RECON.BAR_COVERAGE")
    if cov is not None and cov.sample:
        for run in cov.sample[0].get("연속유실구간", []):
            masked.append(run[0])

    if worst in ("PASS", "SKIP"):
        return {"action": "COMMIT", "reason": "대사 통과 — 자체 조립본을 확정",
                "mask_feature_ts": []}
    if worst == "WARN":
        return {"action": "COMMIT_WITH_MASK",
                "reason": "경미한 불일치 — 확정하되 해당 구간 피처를 마스킹",
                "mask_feature_ts": masked}
    return {"action": "OVERWRITE" if overwrite_on_fail else "HOLD",
            "reason": ("공식 TR 데이터로 OHLCV 덮어쓰기(자체본은 _raw 테이블에 보존), "
                       "틱 기반 피처는 복원 불가이므로 해당 구간 마스킹"),
            "mask_feature_ts": masked}
