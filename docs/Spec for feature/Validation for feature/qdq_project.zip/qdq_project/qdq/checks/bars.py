"""
L1/L2 — 분봉(OHLCV) 무결성 점검.

비유: 병원 심전도 그래프 판독.
  선이 끊겼는지(결측 바), 물리적으로 불가능한 파형인지(고가<저가),
  심장이 멈춘 듯 평평한지(스테일 가격), 갑자기 튀는지(점프) 를 본다.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from ..core import CheckResult, Cadence, Layer, Status, check, judge

REQUIRED = ["ts", "symbol", "open", "high", "low", "close", "volume"]


@check("BAR.SCHEMA", layer=Layer.RAW, cadence=Cadence.INTRADAY, gating=True,
       desc="필수 컬럼 존재 및 dtype 계약(data contract) 준수.")
def schema_contract(df, dataset="-", required=None, numeric=None) -> CheckResult:
    required = required or REQUIRED
    numeric = numeric or ["open", "high", "low", "close", "volume"]
    missing = [c for c in required if c not in df.columns]
    bad_type = [c for c in numeric
                if c in df.columns and not pd.api.types.is_numeric_dtype(df[c])]
    st = Status.FAIL if (missing or bad_type) else Status.PASS
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       n_bad=len(missing) + len(bad_type), n_total=len(required),
                       threshold="누락/타입오류 0건",
                       sample=[{"missing": missing, "bad_dtype": bad_type}],
                       message=f"누락 컬럼 {missing or '없음'}, 타입 불일치 {bad_type or '없음'}")


@check("BAR.TS_MONOTONIC", layer=Layer.RAW, cadence=Cadence.INTRADAY, gating=True,
       desc="심볼별 타임스탬프 단조 증가 + 중복 없음 + tz-aware 여부.")
def timestamp_integrity(df, dataset="-", ts_col="ts", key="symbol") -> CheckResult:
    ts = pd.to_datetime(df[ts_col])
    tz_naive = ts.dt.tz is None
    g = df.assign(_ts=ts).groupby(key, observed=True)["_ts"]
    non_mono = int(sum(0 if s.is_monotonic_increasing else 1 for _, s in g))
    dup = int(df.assign(_ts=ts).duplicated(subset=[key, "_ts"]).sum())
    st = Status.PASS
    if dup or non_mono:
        st = Status.FAIL
    elif tz_naive:
        st = Status.WARN
    return CheckResult(
        check_id="", layer="", cadence="", dataset=dataset, status=st,
        n_bad=dup + non_mono, n_total=len(df), threshold="역행 0, 중복 0, tz-aware",
        message=(f"역행 심볼 {non_mono}개, (심볼,시각) 중복 {dup}건"
                 + (", 타임존 정보 없음(naive) → UTC 저장 권장" if tz_naive else "")),
    )


@check("BAR.GRID_COMPLETE", layer=Layer.CURATED, cadence=Cadence.INTRADAY, gating=True,
       desc="거래 세션 캘린더 기준 기대 분봉 개수 대비 실제 개수(결측 바 비율).")
def bar_grid_completeness(df, dataset="-", ts_col="ts", key="symbol",
                          sessions=None, freq="1min", tz="Asia/Seoul",
                          trading_days=None, warn_ratio=0.001, fail_ratio=0.01) -> CheckResult:
    """sessions: [("09:00","15:45"), ("18:00","05:00")] 형태. 야간장은 자정 넘김 허용.

    trading_days 를 주면 그 값을 영업일 수로 쓰고, 없으면 데이터의 고유 날짜 수를 쓴다.
    (야간장이 자정을 넘으면 고유 날짜 수가 부풀 수 있으므로 명시 지정 권장)
    """
    if not sessions:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP, message="세션 캘린더 미지정 → 점검 생략")
    ts = pd.to_datetime(df[ts_col], utc=True).dt.tz_convert(tz)
    n_days = int(trading_days) if trading_days else int(ts.dt.normalize().nunique())
    per_day = 0
    d0 = pd.Timestamp("2026-01-05", tz=tz)
    for s, e in sessions:
        start = d0 + pd.Timedelta(f"{s}:00")
        end = d0 + pd.Timedelta(f"{e}:00")
        if end <= start:                      # 야간장(자정 넘김)
            end += pd.Timedelta(days=1)
        per_day += len(pd.date_range(start, end, freq=freq, inclusive="left"))
    n_symbols = df[key].nunique() if key in df.columns else 1
    expected = per_day * n_days * n_symbols
    actual = len(df)
    miss = max(expected - actual, 0)
    ratio = miss / max(expected, 1)
    st = judge(ratio, warn_ratio, fail_ratio)
    return CheckResult(
        check_id="", layer="", cadence="", dataset=dataset, status=st,
        metric=ratio, threshold=f"결측률 warn>{warn_ratio:.2%}, fail>{fail_ratio:.2%}",
        n_bad=miss, n_total=expected,
        message=f"기대 {expected}봉 중 {actual}봉 수신, 결측 {miss}봉 ({ratio:.3%})",
    )


@check("BAR.OHLC_SANITY", layer=Layer.CURATED, cadence=Cadence.INTRADAY, gating=True,
       desc="high>=max(o,c), low<=min(o,c), high>=low, 가격>0, 거래량>=0 물리 제약.")
def ohlc_sanity(df, dataset="-", warn_ratio=0.0, fail_ratio=0.0) -> CheckResult:
    o, h, l, c, v = (df[x] for x in ("open", "high", "low", "close", "volume"))
    bad = (
        (h < l) | (h < o) | (h < c) | (l > o) | (l > c)
        | (o <= 0) | (h <= 0) | (l <= 0) | (c <= 0)
        | (v < 0) | o.isna() | h.isna() | l.isna() | c.isna()
    )
    ratio = float(bad.mean()) if len(df) else 0.0
    st = judge(ratio, warn_ratio, fail_ratio)
    cols = [x for x in ("ts", "symbol", "open", "high", "low", "close", "volume")
            if x in df.columns]
    return CheckResult(
        check_id="", layer="", cadence="", dataset=dataset, status=st,
        metric=ratio, threshold="위반 0건 (물리적 불가능)",
        n_bad=int(bad.sum()), n_total=len(df),
        sample=df.loc[bad, cols].head(5).astype(str).to_dict("records"),
        message=f"OHLCV 제약 위반 {int(bad.sum())}/{len(df)}건",
    )


@check("BAR.TICK_SIZE", layer=Layer.CURATED, cadence=Cadence.EOD, gating=False,
       desc="가격이 호가단위(tick size)의 배수인지. 잘못된 스케일/환산 오류 탐지.")
def tick_size_multiple(df, dataset="-", tick=0.05, cols=("open", "high", "low", "close"),
                       tol=1e-9, warn_ratio=0.0, fail_ratio=0.001) -> CheckResult:
    bad = pd.Series(False, index=df.index)
    for c in cols:
        if c in df.columns:
            r = np.abs(np.remainder(df[c].to_numpy(dtype="float64") / tick + 0.5, 1.0) - 0.5)
            bad |= pd.Series(r > (tol / tick) + 1e-6, index=df.index).fillna(False)
    ratio = float(bad.mean()) if len(df) else 0.0
    st = judge(ratio, warn_ratio, fail_ratio)
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=ratio, threshold=f"tick={tick} 배수 위반 허용 {fail_ratio:.2%}",
                       n_bad=int(bad.sum()), n_total=len(df),
                       message=f"호가단위({tick}) 미준수 가격 {int(bad.sum())}건")


@check("BAR.STALE_PRICE", layer=Layer.CURATED, cadence=Cadence.INTRADAY, gating=False,
       desc="종가가 N봉 연속 완전 동일 + 거래량 0. 피드가 마지막 값을 반복 송출하는 좀비 상태.")
def stale_price_streak(df, dataset="-", key="symbol", price="close",
                       warn_len=10, fail_len=30) -> CheckResult:
    worst_len, worst_sym = 0, None
    for sym, g in df.groupby(key, observed=True):
        p = g[price].to_numpy()
        vol = g["volume"].to_numpy() if "volume" in g else np.ones(len(p))
        run = best = 0
        for i in range(1, len(p)):
            if p[i] == p[i - 1] and vol[i] == 0:
                run += 1
                best = max(best, run + 1)
            else:
                run = 0
        if best > worst_len:
            worst_len, worst_sym = best, sym
    st = judge(float(worst_len), float(warn_len), float(fail_len))
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=float(worst_len),
                       threshold=f"연속 warn>{warn_len}봉, fail>{fail_len}봉",
                       message=f"최장 스테일 구간 {worst_len}봉 (symbol={worst_sym})")


@check("BAR.PRICE_JUMP", layer=Layer.CURATED, cadence=Cadence.INTRADAY, gating=False,
       desc="봉간 수익률의 robust-Z 이상치. 팻핑거/오분봉/조정 미반영 탐지.")
def price_jump_outlier(df, dataset="-", key="symbol", price="close",
                       z_warn=8.0, z_fail=15.0, min_obs=60) -> CheckResult:
    hits, mx = [], 0.0
    for sym, g in df.groupby(key, observed=True):
        p = g[price].astype("float64")
        if len(p) < min_obs:
            continue
        r = np.log(p).diff().dropna()
        mad = float((r - r.median()).abs().median())
        if mad <= 0:
            continue
        z = (r - r.median()).abs() / (1.4826 * mad)
        mx = max(mx, float(z.max()))
        for i in z[z >= z_warn].index:
            hits.append({"symbol": str(sym), "idx": str(i), "z": round(float(z[i]), 2),
                         "ret": round(float(r[i]), 5)})
    st = judge(mx, z_warn, z_fail)
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=mx, threshold=f"robust-Z warn>{z_warn}, fail>{z_fail}",
                       n_bad=len(hits), n_total=len(df), sample=hits[:5],
                       message=f"이상 점프 {len(hits)}건, 최대 Z={mx:.1f}")


@check("BAR.VENDOR_RECON", layer=Layer.CURATED, cadence=Cadence.EOD, gating=True,
       desc="2차 벤더/거래소 공식 시세와 종가·거래량 대사(reconciliation). 최종 방어선.")
def vendor_reconciliation(df, dataset="-", ref=None, keys=("ts", "symbol"),
                          cols=("close", "volume"), rtol=1e-6,
                          warn_ratio=0.0, fail_ratio=0.0005) -> CheckResult:
    if ref is None:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP, message="대조용 2차 소스 미제공 → 생략")
    keys = list(keys)
    m = df.merge(ref, on=keys, how="outer", suffixes=("", "_ref"), indicator=True)
    only_one = int((m["_merge"] != "both").sum())
    mism = 0
    samples = []
    both = m[m["_merge"] == "both"]
    for c in cols:
        if c in df.columns and f"{c}_ref" in m.columns:
            a, b = both[c].astype("float64"), both[f"{c}_ref"].astype("float64")
            diff = ~np.isclose(a, b, rtol=rtol, equal_nan=True)
            mism += int(diff.sum())
            for _, row in both.loc[diff, keys + [c, f"{c}_ref"]].head(3).iterrows():
                samples.append({k: str(row[k]) for k in row.index})
    total = max(len(m), 1)
    ratio = (mism + only_one) / total
    st = judge(ratio, warn_ratio, fail_ratio)
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=ratio, threshold=f"불일치율 fail>{fail_ratio:.3%}",
                       n_bad=mism + only_one, n_total=total, sample=samples[:5],
                       message=f"한쪽에만 존재 {only_one}건, 값 불일치 {mism}건")
