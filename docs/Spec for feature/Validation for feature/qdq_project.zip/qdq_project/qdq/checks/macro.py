"""
L2/L3 — 매크로 지표의 시점(Point-in-Time) 무결성 점검.

비유: 신문 기사에 발행일자 도장 찍기.
  "2026년 3월 CPI"라는 값은 3월에 존재한 게 아니라 4월에 발표된다.
  발표일(release_ts)을 무시하고 기간(period_end)으로 조인하면
  백테스트는 "내일 신문을 오늘 읽는" 상태가 되고, 성과는 환상이 된다.
  게다가 매크로 지표는 나중에 조용히 수정(revision)된다 —
  어제 본 신문과 오늘 본 같은 날짜 신문의 숫자가 다르다.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from ..core import CheckResult, Cadence, Layer, Status, check, judge, utc


@check("MACRO.PIT_FIELDS", layer=Layer.RAW, cadence=Cadence.EOD, gating=True,
       desc="release_ts(발표시각)·period_end(대상기간)·vintage 컬럼 존재 및 release_ts >= period_end.")
def pit_fields(df, dataset="-", release="release_ts", period="period_end",
               vintage="vintage") -> CheckResult:
    missing = [c for c in (release, period) if c not in df.columns]
    if missing:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.FAIL, threshold="PIT 필드 필수",
                           message=f"PIT 필드 누락: {missing} → 매크로 피처는 PIT 없이 쓰면 안 됨")
    r = pd.to_datetime(df[release], utc=True)
    p = pd.to_datetime(df[period], utc=True)
    bad = (r < p) | r.isna() | p.isna()
    no_vintage = vintage not in df.columns
    st = Status.FAIL if bad.any() else (Status.WARN if no_vintage else Status.PASS)
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=float(bad.mean()), threshold="release_ts >= period_end, 위반 0건",
                       n_bad=int(bad.sum()), n_total=len(df),
                       message=(f"발표시각 역전 {int(bad.sum())}건"
                                + ("; vintage 컬럼 없음 → 개정 추적 불가" if no_vintage else "")))


@check("MACRO.REVISION", layer=Layer.RAW, cadence=Cadence.WEEKLY, gating=False,
       desc="동일 (지표, 기간)의 값이 이전 vintage 대비 변경됐는지. 개정은 정상이지만 '조용한' 개정은 위험.")
def revision_detect(current, dataset="-", previous=None, keys=("series", "period_end"),
                    value="value", rtol=1e-9, warn_ratio=0.02, fail_ratio=0.20) -> CheckResult:
    if previous is None or len(previous) == 0:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP, message="이전 vintage 스냅샷 없음 → 최초 실행")
    keys = list(keys)
    m = current.merge(previous, on=keys, how="inner", suffixes=("", "_prev"))
    a = m[value].astype("float64")
    b = m[f"{value}_prev"].astype("float64")
    changed = ~np.isclose(a, b, rtol=rtol, equal_nan=True)
    ratio = float(changed.mean()) if len(m) else 0.0
    st = judge(ratio, warn_ratio, fail_ratio)
    samples = m.loc[changed, keys + [value, f"{value}_prev"]].head(5).astype(str).to_dict("records")
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=ratio, threshold=f"개정 비율 warn>{warn_ratio:.0%}, fail>{fail_ratio:.0%}",
                       n_bad=int(changed.sum()), n_total=len(m), sample=samples,
                       message=(f"과거 값 개정 {int(changed.sum())}/{len(m)}건 "
                                f"→ 개정분은 새 vintage로 append(덮어쓰기 금지)"))


@check("MACRO.STALENESS", layer=Layer.CURATED, cadence=Cadence.EOD, gating=True,
       desc="지표별 기대 발표 주기 대비 마지막 갱신 경과일. 조용히 끊긴 시리즈 탐지.")
def series_staleness(df, dataset="-", key="series", release="release_ts",
                     expected_days=None, now=None, slack=1.5, hard=3.0) -> CheckResult:
    now = utc(now, default_now=True)
    expected_days = expected_days or {}
    rows, worst_ratio, worst = [], 0.0, None
    for s, g in df.groupby(key, observed=True):
        last = pd.to_datetime(g[release], utc=True).max()
        age = (now - last).days
        exp = float(expected_days.get(s, 31))
        ratio = age / exp
        if ratio > worst_ratio:
            worst_ratio, worst = ratio, (s, age, exp)
        if ratio >= slack:
            rows.append({"series": str(s), "age_days": int(age), "expected_days": exp})
    st = judge(worst_ratio, slack, hard)
    msg = "모든 시리즈 최신" if worst is None else \
        f"최장 지연: {worst[0]} — {worst[1]}일 경과 (기대 주기 {worst[2]:.0f}일, 비율 {worst_ratio:.2f}x)"
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=worst_ratio, threshold=f"경과/기대주기 warn>{slack}, fail>{hard}",
                       n_bad=len(rows), n_total=int(df[key].nunique()), sample=rows[:5],
                       message=msg)


@check("MACRO.ASOF_JOIN", layer=Layer.FEATURE, cadence=Cadence.EOD, gating=True,
       desc="피처 테이블에 붙은 매크로 값이 그 시점에 '이미 발표된' 값인지. 룩어헤드 최종 감사.")
def asof_join_validity(feat, dataset="-", feat_ts="ts", used_release="macro_release_ts",
                       lag_min_sec=0) -> CheckResult:
    if used_release not in feat.columns:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.FAIL, threshold="발표시각 계보(lineage) 컬럼 필수",
                           message=f"'{used_release}' 컬럼 없음 → 어떤 vintage를 썼는지 추적 불가")
    ft = pd.to_datetime(feat[feat_ts], utc=True)
    rt = pd.to_datetime(feat[used_release], utc=True)
    bad = (rt > ft - pd.Timedelta(seconds=lag_min_sec)) | rt.isna()
    st = Status.FAIL if bad.any() else Status.PASS
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=float(bad.mean()), threshold="release_ts <= feature_ts, 위반 0건",
                       n_bad=int(bad.sum()), n_total=len(feat),
                       sample=feat.loc[bad, [feat_ts, used_release]].head(5).astype(str).to_dict("records"),
                       message=f"미래 발표값 사용(룩어헤드) {int(bad.sum())}건")


@check("MACRO.SCALE_SHIFT", layer=Layer.CURATED, cadence=Cadence.WEEKLY, gating=True,
       desc="시리즈 레벨이 10/100/1000배로 통째 이동했는지. 벤더의 조용한 단위·기준연도 변경 탐지.")
def scale_shift(df, dataset="-", key="series", value="value", ts="period_end",
                lookback=24, warn_ratio=3.0, fail_ratio=8.0) -> CheckResult:
    worst, worst_s = 1.0, None
    for s, g in df.sort_values(ts).groupby(key, observed=True):
        v = g[value].astype("float64").dropna()
        if len(v) < lookback + 1:
            continue
        base = float(v.iloc[-lookback - 1:-1].abs().median())
        cur = float(abs(v.iloc[-1]))
        if base <= 0:
            continue
        ratio = max(cur / base, base / max(cur, 1e-12))
        if ratio > worst:
            worst, worst_s = ratio, s
    st = judge(worst, warn_ratio, fail_ratio)
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=worst, threshold=f"레벨 배율 warn>{warn_ratio}x, fail>{fail_ratio}x",
                       message=f"최대 레벨 이동 {worst:.2f}x (series={worst_s})")
