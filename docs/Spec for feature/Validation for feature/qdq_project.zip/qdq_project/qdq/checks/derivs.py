"""
L2 — 선물/옵션 도메인 무결성 점검.

비유: 회계 장부의 복식부기 검산.
  파생상품 가격에는 "이론적으로 반드시 성립해야 하는 등식"이 있다.
  풋콜 패리티, 행사가 단조성, 나비 볼록성 —
  이 등식이 깨지면 시장이 이상한 게 아니라 대개 데이터가 이상한 것이다.
  (진짜 차익거래 기회는 몇 초 안에 사라지지만, 데이터 오류는 하루 종일 남아있다)
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from ..core import CheckResult, Cadence, Layer, Status, check, judge


# ----------------------------------------------------------------- 선물

@check("FUT.EXPIRY_VALID", layer=Layer.CURATED, cadence=Cadence.EOD, gating=True,
       desc="만기 경과 계약의 시세가 계속 들어오는지 / 잔존만기 음수 여부.")
def expiry_validity(df, dataset="-", ts="ts", exp="expiry",
                    warn_ratio=0.0, fail_ratio=0.0) -> CheckResult:
    t = pd.to_datetime(df[ts], utc=True)
    e = pd.to_datetime(df[exp], utc=True)
    bad = (t.dt.normalize() > e.dt.normalize()) | e.isna()
    ratio = float(bad.mean()) if len(df) else 0.0
    st = judge(ratio, warn_ratio, fail_ratio)
    cols = [c for c in (ts, "symbol", exp) if c in df.columns]
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=ratio, threshold="만기 경과 시세 0건",
                       n_bad=int(bad.sum()), n_total=len(df),
                       sample=df.loc[bad, cols].head(5).astype(str).to_dict("records"),
                       message=f"만기 경과/만기 결측 행 {int(bad.sum())}건")


@check("FUT.ROLL_CONTINUITY", layer=Layer.CURATED, cadence=Cadence.EOD, gating=True,
       desc="연속물(continuous) 접합 시 롤 조정이 실제로 적용됐는지. 미적용 시 가짜 갭이 알파로 둔갑.")
def roll_continuity(series, dataset="-", roll_dates=None, ts="ts", price="close",
                    warn_z=4.0, fail_z=8.0) -> CheckResult:
    if roll_dates is None or len(roll_dates) == 0:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP, message="롤 일정 미제공 → 생략")
    s = series.sort_values(ts)
    r = np.log(s[price].astype("float64")).diff()
    mad = float((r - r.median()).abs().median()) or 1e-12
    z = (r - r.median()).abs() / (1.4826 * mad)
    d = pd.to_datetime(s[ts], utc=True).dt.normalize()
    rolls = pd.to_datetime(pd.Series(list(roll_dates)), utc=True).dt.normalize()
    mask = d.isin(set(rolls))
    mx = float(z[mask].max()) if mask.any() else 0.0
    st = judge(mx, warn_z, fail_z)
    hits = [{"date": str(dd.date()), "z": round(float(zz), 2)}
            for dd, zz in zip(d[mask & (z >= warn_z)], z[mask & (z >= warn_z)])]
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=mx, threshold=f"롤일 수익률 Z warn>{warn_z}, fail>{fail_z}",
                       n_bad=len(hits), n_total=int(mask.sum()), sample=hits[:5],
                       message=f"롤 시점 이상 점프 {len(hits)}건 (최대 Z={mx:.1f})")


@check("FUT.BASIS_SANITY", layer=Layer.CURATED, cadence=Cadence.EOD, gating=False,
       desc="연율화 베이시스(선물/현물-1)/T 가 상식 범위인지. 잘못된 현물 매칭·환산 탐지.")
def basis_sanity(df, dataset="-", fut="fut_close", spot="spot_close", tau="tau_years",
                 lo=-0.30, hi=0.30, warn_ratio=0.01, fail_ratio=0.05) -> CheckResult:
    f, s, t = (df[fut].astype("float64"), df[spot].astype("float64"),
               df[tau].astype("float64").clip(lower=1 / 365))
    ann = (f / s - 1.0) / t
    bad = (~ann.between(lo, hi)) | ann.isna()
    ratio = float(bad.mean()) if len(df) else 0.0
    st = judge(ratio, warn_ratio, fail_ratio)
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=ratio, threshold=f"연율 베이시스 [{lo:.0%},{hi:.0%}] 이탈률",
                       n_bad=int(bad.sum()), n_total=len(df),
                       message=(f"베이시스 이탈 {int(bad.sum())}건, "
                                f"중앙값 {float(ann.median()):.2%}"))


@check("FUT.OPEN_INTEREST", layer=Layer.CURATED, cadence=Cadence.EOD, gating=False,
       desc="미결제약정 음수/결측/일간 급변. 정산 데이터 지연 또는 계약 승수 변경 탐지.")
def open_interest_sanity(df, dataset="-", key="symbol", oi="open_interest",
                         max_daily_change=0.5, warn_ratio=0.01, fail_ratio=0.05) -> CheckResult:
    bad_abs = (df[oi] < 0) | df[oi].isna()
    chg = df.groupby(key, observed=True)[oi].pct_change().abs()
    bad = bad_abs | (chg > max_daily_change).fillna(False)
    ratio = float(bad.mean()) if len(df) else 0.0
    st = judge(ratio, warn_ratio, fail_ratio)
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=ratio, threshold=f"음수/결측 또는 일간 {max_daily_change:.0%} 초과 변동",
                       n_bad=int(bad.sum()), n_total=len(df),
                       message=f"OI 이상 {int(bad.sum())}건 (음수·결측 {int(bad_abs.sum())}건)")


# ----------------------------------------------------------------- 옵션

def _chain_iter(df, ts, exp, cp, k, px):
    for (t, e), g in df.groupby([ts, exp], observed=True):
        c = g[g[cp].astype(str).str.upper().str[0] == "C"].sort_values(k)
        p = g[g[cp].astype(str).str.upper().str[0] == "P"].sort_values(k)
        yield t, e, c, p


@check("OPT.CHAIN_COMPLETE", layer=Layer.CURATED, cadence=Cadence.EOD, gating=True,
       desc="ATM 주변 행사가 그리드에 구멍이 있는지 + 콜/풋 짝 결측. 체인 수집 누락 탐지.")
def chain_completeness(df, dataset="-", ts="ts", exp="expiry", cp="cp", k="strike",
                       spot="spot", n_around=5, warn_ratio=0.01, fail_ratio=0.05) -> CheckResult:
    miss, total = 0, 0
    samples = []
    for t, e, c, p in _chain_iter(df, ts, exp, cp, k, "price"):
        ks = np.union1d(c[k].to_numpy(), p[k].to_numpy())
        if len(ks) < 3:
            continue
        s0 = float(df.loc[(df[ts] == t), spot].iloc[0]) if spot in df.columns else float(np.median(ks))
        atm_i = int(np.argmin(np.abs(ks - s0)))
        window = ks[max(0, atm_i - n_around): atm_i + n_around + 1]
        for kk in window:
            total += 2
            has_c = (c[k] == kk).any()
            has_p = (p[k] == kk).any()
            miss += (not has_c) + (not has_p)
            if not (has_c and has_p) and len(samples) < 5:
                samples.append({"ts": str(t), "expiry": str(e), "strike": float(kk),
                                "call": bool(has_c), "put": bool(has_p)})
    ratio = miss / max(total, 1)
    st = judge(ratio, warn_ratio, fail_ratio)
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=ratio, threshold=f"ATM±{n_around} 결측률 fail>{fail_ratio:.1%}",
                       n_bad=miss, n_total=total, sample=samples,
                       message=f"ATM 주변 콜/풋 결측 {miss}/{total}건")


@check("OPT.NOARB_MONOTONIC", layer=Layer.CURATED, cadence=Cadence.EOD, gating=True,
       desc="행사가 단조성: 콜가는 K 증가 시 비증가, 풋가는 비감소. 위반은 대부분 데이터 오류.")
def noarb_monotonic(df, dataset="-", ts="ts", exp="expiry", cp="cp", k="strike",
                    px="price", tol=1e-8, warn_ratio=0.0, fail_ratio=0.002) -> CheckResult:
    bad, total, samples = 0, 0, []
    for t, e, c, p in _chain_iter(df, ts, exp, cp, k, px):
        for leg, sign in ((c, +1), (p, -1)):
            v = leg[px].astype("float64").to_numpy()
            if len(v) < 2:
                continue
            d = np.diff(v) * sign            # 콜: 증가하면 위반 / 풋: 감소하면 위반
            total += len(d)
            viol = d > tol
            bad += int(viol.sum())
            if viol.any() and len(samples) < 5:
                i = int(np.argmax(viol))
                samples.append({"ts": str(t), "expiry": str(e),
                                "type": "C" if sign > 0 else "P",
                                "K1": float(leg[k].iloc[i]), "K2": float(leg[k].iloc[i + 1]),
                                "px1": float(v[i]), "px2": float(v[i + 1])})
    ratio = bad / max(total, 1)
    st = judge(ratio, warn_ratio, fail_ratio)
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=ratio, threshold=f"단조성 위반율 fail>{fail_ratio:.2%}",
                       n_bad=bad, n_total=total, sample=samples,
                       message=f"행사가 단조성 위반 {bad}/{total}쌍")


@check("OPT.NOARB_BUTTERFLY", layer=Layer.CURATED, cadence=Cadence.EOD, gating=False,
       desc="나비 볼록성: 2*C(K2) <= C(K1)+C(K3). 위반 시 IV 서피스가 음의 밀도를 갖는다.")
def noarb_butterfly(df, dataset="-", ts="ts", exp="expiry", cp="cp", k="strike",
                    px="price", tol=1e-6, warn_ratio=0.002, fail_ratio=0.01) -> CheckResult:
    bad, total, samples = 0, 0, []
    for t, e, c, p in _chain_iter(df, ts, exp, cp, k, px):
        for leg in (c, p):
            ks = leg[k].astype("float64").to_numpy()
            v = leg[px].astype("float64").to_numpy()
            if len(v) < 3:
                continue
            for i in range(len(v) - 2):
                k1, k2, k3 = ks[i], ks[i + 1], ks[i + 2]
                if k3 == k1:
                    continue
                w = (k3 - k2) / (k3 - k1)
                lhs = v[i + 1]
                rhs = w * v[i] + (1 - w) * v[i + 2]
                total += 1
                if lhs > rhs + tol:
                    bad += 1
                    if len(samples) < 5:
                        samples.append({"ts": str(t), "expiry": str(e),
                                        "K": [float(k1), float(k2), float(k3)],
                                        "mid": float(lhs), "convex_bound": float(rhs)})
    ratio = bad / max(total, 1)
    st = judge(ratio, warn_ratio, fail_ratio)
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=ratio, threshold=f"볼록성 위반율 warn>{warn_ratio:.2%}",
                       n_bad=bad, n_total=total, sample=samples,
                       message=f"나비 볼록성 위반 {bad}/{total}조합")


@check("OPT.PUT_CALL_PARITY", layer=Layer.CURATED, cadence=Cadence.EOD, gating=True,
       desc="C - P = S*e^(-qT) - K*e^(-rT) 괴리(포워드 기준 bp). 현물·금리·배당 매칭 오류의 리트머스.")
def put_call_parity(df, dataset="-", ts="ts", exp="expiry", cp="cp", k="strike",
                    px="price", spot="spot", r="r", q="q", tau="tau_years",
                    warn_bp=30.0, fail_bp=100.0,
                    outlier_warn=0.0, outlier_fail=0.01) -> CheckResult:
    devs, samples = [], []
    for t, e, c, p in _chain_iter(df, ts, exp, cp, k, px):
        m = c.merge(p, on=k, suffixes=("_c", "_p"))
        if m.empty:
            continue
        S = m[f"{spot}_c"].astype("float64")
        rr = m[f"{r}_c"].astype("float64") if f"{r}_c" in m else 0.0
        qq = m[f"{q}_c"].astype("float64") if f"{q}_c" in m else 0.0
        T = m[f"{tau}_c"].astype("float64")
        lhs = m[f"{px}_c"].astype("float64") - m[f"{px}_p"].astype("float64")
        rhs = S * np.exp(-qq * T) - m[k].astype("float64") * np.exp(-rr * T)
        dev_bp = ((lhs - rhs).abs() / S * 1e4)
        devs.append(dev_bp)
        for i in dev_bp[dev_bp > warn_bp].head(3).index:
            samples.append({"ts": str(t), "expiry": str(e), "K": float(m[k].iloc[i]),
                            "dev_bp": round(float(dev_bp.iloc[i]), 1)})
    if not devs:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP, message="콜/풋 매칭 쌍 없음")
    all_dev = pd.concat(devs)
    med = float(all_dev.median())
    # 주지표는 '이상치 비율'. 중앙값만 보면 소수의 오염 호가를 놓친다(중앙값은 너무 둔감).
    out_ratio = float((all_dev > warn_bp).mean())
    st = judge(out_ratio, outlier_warn, outlier_fail)
    if med > fail_bp:                     # 체인 전체가 어긋난 경우(현물·금리 매칭 오류)
        st = Status.FAIL
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=out_ratio,
                       threshold=(f"괴리>{warn_bp}bp 비율 warn>{outlier_warn:.1%}, "
                                  f"fail>{outlier_fail:.1%} / 중앙값 fail>{fail_bp}bp"),
                       n_bad=int((all_dev > warn_bp).sum()), n_total=len(all_dev),
                       sample=samples[:5],
                       message=(f"패리티 이탈 {int((all_dev > warn_bp).sum())}/{len(all_dev)}쌍, "
                                f"중앙값 {med:.1f}bp, p95={float(all_dev.quantile(.95)):.1f}bp"))


@check("OPT.IV_SANITY", layer=Layer.CURATED, cadence=Cadence.EOD, gating=False,
       desc="IV 범위(0<IV<300%) + 인접 행사가 IV 점프. 스마일이 톱니처럼 튀면 가격/모형 오류.")
def iv_sanity(df, dataset="-", ts="ts", exp="expiry", cp="cp", k="strike", iv="iv",
              lo=0.01, hi=3.0, max_jump=0.25, warn_ratio=0.01, fail_ratio=0.05) -> CheckResult:
    v = df[iv].astype("float64")
    out_range = (~v.between(lo, hi)) | v.isna()
    jumps = 0
    for t, e, c, p in _chain_iter(df, ts, exp, cp, k, iv):
        for leg in (c, p):
            x = leg[iv].astype("float64").to_numpy()
            if len(x) > 1:
                jumps += int((np.abs(np.diff(x)) > max_jump).sum())
    bad = int(out_range.sum()) + jumps
    ratio = bad / max(len(df), 1)
    st = judge(ratio, warn_ratio, fail_ratio)
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=ratio, threshold=f"IV∉[{lo},{hi}] 또는 인접 점프>{max_jump:.0%}",
                       n_bad=bad, n_total=len(df),
                       message=f"IV 범위 이탈 {int(out_range.sum())}건, 스마일 점프 {jumps}건")


@check("OPT.CALENDAR_ARB", layer=Layer.CURATED, cadence=Cadence.EOD, gating=False,
       desc="동일 행사가에서 만기가 길수록 옵션가가 싸면 이상(달력 차익). 만기 라벨링 오류 탐지.")
def calendar_arbitrage(df, dataset="-", ts="ts", exp="expiry", cp="cp", k="strike",
                       px="price", tol=1e-6, warn_ratio=0.002, fail_ratio=0.01) -> CheckResult:
    bad, total, samples = 0, 0, []
    for (t, typ, kk), g in df.groupby([ts, cp, k], observed=True):
        g = g.sort_values(exp)
        v = g[px].astype("float64").to_numpy()
        if len(v) < 2:
            continue
        d = np.diff(v)
        total += len(d)
        viol = d < -tol
        bad += int(viol.sum())
        if viol.any() and len(samples) < 5:
            samples.append({"ts": str(t), "cp": str(typ), "K": float(kk),
                            "px_by_expiry": [round(float(x), 4) for x in v]})
    ratio = bad / max(total, 1)
    st = judge(ratio, warn_ratio, fail_ratio)
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=ratio, threshold=f"달력 차익 위반율 warn>{warn_ratio:.2%}",
                       n_bad=bad, n_total=total, sample=samples,
                       message=f"만기 단조성 위반 {bad}/{total}쌍")
