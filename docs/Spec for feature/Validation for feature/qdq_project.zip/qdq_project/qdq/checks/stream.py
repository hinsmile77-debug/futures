"""
L0 FEED — 실시간 수집 계층 점검.

비유: 수도관 점검.
  물이 나오는지(하트비트), 중간에 새는지(시퀀스 갭),
  수압이 약한지(수신 지연), 관이 자주 터지는지(재접속) 를 본다.
  여기서 막지 못하면 아래층 저수조(DB)에 오염수가 그대로 들어간다.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from ..core import CheckResult, Cadence, Layer, Status, check, judge, utc


@check("FEED.HEARTBEAT", layer=Layer.FEED, cadence=Cadence.REALTIME, gating=True,
       desc="마지막 메시지 수신 후 경과 시간(초). 세션 중 피드가 살아있는지.")
def heartbeat_staleness(last_msg_ts, dataset="-", now=None,
                        warn_sec=5.0, fail_sec=30.0) -> CheckResult:
    now = utc(now, default_now=True)
    last = utc(last_msg_ts)
    gap = (now - last).total_seconds()
    st = judge(gap, warn_sec, fail_sec)
    return CheckResult(
        check_id="", layer="", cadence="", dataset=dataset, status=st,
        metric=gap, threshold=f"warn>{warn_sec}s, fail>{fail_sec}s",
        message=f"마지막 수신 이후 {gap:.1f}초 경과 (last={last})",
    )


@check("FEED.SEQ_GAP", layer=Layer.FEED, cadence=Cadence.REALTIME, gating=True,
       desc="거래소 시퀀스 번호의 결번/역행 탐지. 스냅샷 재동기화 필요 여부 판단.")
def sequence_gap(seq, dataset="-", warn_ratio=0.0, fail_ratio=0.0005) -> CheckResult:
    s = pd.Series(seq).dropna().astype("int64")
    if len(s) < 2:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP, message="시퀀스 표본 부족")
    d = s.diff().iloc[1:]
    gaps = d[d != 1]
    missing = int(d[d > 1].sub(1).sum()) if (d > 1).any() else 0
    backward = int((d <= 0).sum())
    total = int(s.max() - s.min() + 1)
    ratio = missing / max(total, 1)
    st = judge(ratio, warn_ratio, fail_ratio)
    if backward:
        st = Status.FAIL
    return CheckResult(
        check_id="", layer="", cadence="", dataset=dataset, status=st,
        metric=ratio, threshold=f"warn>{warn_ratio}, fail>{fail_ratio}",
        n_bad=missing + backward, n_total=total,
        sample=[{"idx": int(i), "delta": int(v)} for i, v in gaps.head(5).items()],
        message=f"결번 {missing}건, 역행 {backward}건 / 기대 {total}건",
    )


@check("FEED.INGEST_LATENCY", layer=Layer.FEED, cadence=Cadence.REALTIME, gating=True,
       desc="거래소 타임스탬프 대비 수신 시각 지연(ms)의 p99. 지연 데이터는 사실상 미래 정보 손실.")
def ingest_latency(df, dataset="-", exch_col="exch_ts", recv_col="recv_ts",
                   warn_ms=200.0, fail_ms=1000.0, quantile=0.99) -> CheckResult:
    lat = (pd.to_datetime(df[recv_col]) - pd.to_datetime(df[exch_col])).dt.total_seconds() * 1000
    lat = lat.dropna()
    if lat.empty:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP, message="지연 계산 가능한 행 없음")
    q = float(lat.quantile(quantile))
    neg = int((lat < -1).sum())          # 수신이 거래소 시각보다 빠름 = 시계 동기화 문제
    st = judge(q, warn_ms, fail_ms)
    if neg > 0:
        st = Status.FAIL
    return CheckResult(
        check_id="", layer="", cadence="", dataset=dataset, status=st,
        metric=q, threshold=f"p{int(quantile*100)} warn>{warn_ms}ms, fail>{fail_ms}ms",
        n_bad=int((lat >= warn_ms).sum()) + neg, n_total=len(lat),
        message=(f"수신지연 p{int(quantile*100)}={q:.1f}ms, median={lat.median():.1f}ms"
                 + (f", 음수지연(시계역전) {neg}건 → NTP 점검" if neg else "")),
    )


@check("FEED.MSG_RATE", layer=Layer.FEED, cadence=Cadence.REALTIME, gating=False,
       desc="분당 메시지 수가 과거 동시간대 대비 급감/급증했는지. 조용한 장애 탐지.")
def message_rate_anomaly(current_rate, dataset="-", baseline_rates=None,
                         warn_z=3.0, fail_z=5.0) -> CheckResult:
    if baseline_rates is None:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP, message="베이스라인 미제공")
    b = pd.Series(baseline_rates, dtype="float64").dropna()
    if len(b) < 10:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP, message="베이스라인 표본 부족(<10)")
    mad = float((b - b.median()).abs().median()) or 1e-9
    z = abs(float(current_rate) - float(b.median())) / (1.4826 * mad)
    st = judge(z, warn_z, fail_z)
    return CheckResult(
        check_id="", layer="", cadence="", dataset=dataset, status=st,
        metric=z, threshold=f"robust-Z warn>{warn_z}, fail>{fail_z}",
        message=f"현재 {current_rate:.0f} msg/min vs 기준중앙값 {b.median():.0f} (Z={z:.2f})",
    )


@check("FEED.RECONNECT", layer=Layer.FEED, cadence=Cadence.INTRADAY, gating=False,
       desc="세션 내 재접속 횟수. 잦은 재접속은 뒤에서 조용한 데이터 구멍을 만든다.")
def reconnect_count(n_reconnect, dataset="-", warn=1, fail=3) -> CheckResult:
    st = judge(float(n_reconnect), float(warn), float(fail))
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=float(n_reconnect),
                       threshold=f"warn>{warn}회, fail>{fail}회",
                       message=f"세션 내 재접속 {n_reconnect}회")


@check("FEED.DUP_MSG", layer=Layer.FEED, cadence=Cadence.REALTIME, gating=False,
       desc="동일 (시각, 심볼, 시퀀스) 중복 수신 비율. 이중 구독/재전송 처리 누락 탐지.")
def duplicate_messages(df, dataset="-", keys=("symbol", "exch_ts", "seq"),
                       warn_ratio=0.0, fail_ratio=0.001) -> CheckResult:
    keys = [k for k in keys if k in df.columns]
    if not keys:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP, message="중복 판정 키 컬럼 없음")
    dup = df.duplicated(subset=keys, keep="first")
    ratio = float(dup.mean()) if len(df) else 0.0
    st = judge(ratio, warn_ratio, fail_ratio)
    return CheckResult(
        check_id="", layer="", cadence="", dataset=dataset, status=st,
        metric=ratio, threshold=f"warn>{warn_ratio}, fail>{fail_ratio}",
        n_bad=int(dup.sum()), n_total=len(df),
        sample=df.loc[dup, keys].head(5).astype(str).to_dict("records"),
        message=f"중복 메시지 {int(dup.sum())}/{len(df)}건 ({ratio:.4%})",
    )
