"""
L3/L4 — ML 피처 계층 무결성 점검.

비유: 요리 재료 검수 + 레시피 재현성 테스트.
  - 재료가 상했는가 (NaN/inf/상수화)
  - 재료가 어제와 다른 산지인가 (분포 드리프트)
  - 레시피를 다시 돌리면 같은 맛이 나는가 (결정성/재현성)
  - 실수로 '완성된 요리'를 재료에 섞었는가 (룩어헤드/타깃 누수)  ← 가장 치명적

원칙: 원본 데이터가 멀쩡해도 피처 단계에서 깨질 수 있으므로,
      "피처는 원본과 별개의 감시 대상"으로 취급한다.
"""
from __future__ import annotations

import hashlib

import numpy as np
import pandas as pd

from ..core import CheckResult, Cadence, Layer, Status, check, judge, utc


# ------------------------------------------------------------ 기본 위생

@check("FEAT.NULL_RATIO", layer=Layer.FEATURE, cadence=Cadence.EOD, gating=True,
       desc="피처별 결측률. 임계 초과 피처는 모델 입력에서 제외하거나 배치를 중단.")
def null_ratio(df, dataset="-", cols=None, warn=0.01, fail=0.05,
               per_feature_override=None) -> CheckResult:
    cols = cols or [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c])]
    ov = per_feature_override or {}
    rows, worst, worst_c = [], 0.0, None
    st = Status.PASS
    for c in cols:
        r = float(df[c].isna().mean())
        w, f = ov.get(c, (warn, fail))
        s = judge(r, w, f)
        if r > worst:
            worst, worst_c = r, c
        if s != Status.PASS:
            rows.append({"feature": c, "null_ratio": round(r, 5), "status": s})
        if s == Status.FAIL:
            st = Status.FAIL
        elif s == Status.WARN and st == Status.PASS:
            st = Status.WARN
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=worst, threshold=f"warn>{warn:.1%}, fail>{fail:.1%}",
                       n_bad=len(rows), n_total=len(cols), sample=rows[:5],
                       message=f"최대 결측률 {worst:.2%} ({worst_c}), 임계 초과 피처 {len(rows)}개")


@check("FEAT.INF_EXTREME", layer=Layer.FEATURE, cadence=Cadence.EOD, gating=True,
       desc="inf / 비정상 절대값(|x|>1e12) 존재 여부. 0으로 나누기·로그(0) 등 계산 사고의 흔적.")
def inf_or_extreme(df, dataset="-", cols=None, huge=1e12) -> CheckResult:
    cols = cols or [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c])]
    bad, rows = 0, []
    for c in cols:
        v = df[c].to_numpy(dtype="float64", na_value=np.nan)
        n = int(np.isinf(v).sum() + (np.abs(v) > huge).sum())
        if n:
            bad += n
            rows.append({"feature": c, "n_bad": n})
    st = Status.FAIL if bad else Status.PASS
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=float(bad), threshold="inf/극단값 0건",
                       n_bad=bad, n_total=len(df) * max(len(cols), 1), sample=rows[:5],
                       message=f"inf·극단값 {bad}건 ({len(rows)}개 피처)")


@check("FEAT.DEGENERATE", layer=Layer.FEATURE, cadence=Cadence.EOD, gating=False,
       desc="분산이 0이거나 고유값이 1~2개로 붕괴한 피처. 상류 데이터가 멈췄다는 신호.")
def degenerate_feature(df, dataset="-", cols=None, min_unique=3, min_std=1e-12) -> CheckResult:
    cols = cols or [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c])]
    rows = []
    for c in cols:
        s = df[c].replace([np.inf, -np.inf], np.nan).dropna()
        if len(s) == 0:
            rows.append({"feature": c, "reason": "전량 결측"})
        elif s.nunique() < min_unique or float(s.std()) < min_std:
            rows.append({"feature": c, "reason": f"unique={s.nunique()}, std={float(s.std()):.3g}"})
    st = Status.FAIL if rows else Status.PASS
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=float(len(rows)), threshold=f"unique>={min_unique}",
                       n_bad=len(rows), n_total=len(cols), sample=rows[:5],
                       message=f"붕괴 피처 {len(rows)}개 / {len(cols)}개")


@check("FEAT.RANGE_CONTRACT", layer=Layer.FEATURE, cadence=Cadence.EOD, gating=True,
       desc="피처 계약(min/max)을 벗어난 값 비율. 예: RSI∈[0,100], IV∈[0,3], 비중합=1.")
def range_contract(df, dataset="-", spec=None, warn_ratio=0.0, fail_ratio=0.001) -> CheckResult:
    spec = spec or {}
    if not spec:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP, message="range 계약 미정의 → 생략")
    bad, total, rows = 0, 0, []
    for c, (lo, hi) in spec.items():
        if c not in df.columns:
            rows.append({"feature": c, "reason": "컬럼 없음"})
            bad += 1
            continue
        v = df[c].astype("float64")
        n = int(((v < lo) | (v > hi)).sum())
        total += len(v)
        bad += n
        if n:
            rows.append({"feature": c, "n_out": n, "range": [lo, hi],
                         "min": float(v.min()), "max": float(v.max())})
    ratio = bad / max(total, 1)
    st = judge(ratio, warn_ratio, fail_ratio)
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=ratio, threshold=f"계약 이탈률 fail>{fail_ratio:.2%}",
                       n_bad=bad, n_total=total, sample=rows[:5],
                       message=f"범위 계약 위반 {bad}건 ({len(rows)}개 피처)")


@check("FEAT.ROWCOUNT", layer=Layer.FEATURE, cadence=Cadence.EOD, gating=True,
       desc="기대 유니버스(종목×시각) 대비 실제 행 수. 조용한 부분 실패(partial write) 탐지.")
def rowcount_expectation(df, dataset="-", expected=None, warn=0.005, fail=0.02) -> CheckResult:
    if not expected:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP, message="기대 행 수 미지정")
    dev = abs(len(df) - expected) / max(expected, 1)
    st = judge(dev, warn, fail)
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=dev, threshold=f"편차 warn>{warn:.1%}, fail>{fail:.1%}",
                       n_bad=abs(len(df) - expected), n_total=expected,
                       message=f"행 수 {len(df)} vs 기대 {expected} (편차 {dev:.2%})")


@check("FEAT.FRESHNESS", layer=Layer.SERVING, cadence=Cadence.REALTIME, gating=True,
       desc="피처 테이블의 최신 타임스탬프가 현재 대비 얼마나 뒤처졌는지. 서빙 직전 최종 관문.")
def feature_freshness(df, dataset="-", ts="ts", now=None,
                      warn_sec=120.0, fail_sec=600.0) -> CheckResult:
    now = utc(now, default_now=True)
    last = pd.to_datetime(df[ts], utc=True).max()
    age = (now - last).total_seconds()
    st = judge(age, warn_sec, fail_sec)
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=age, threshold=f"warn>{warn_sec}s, fail>{fail_sec}s",
                       message=f"피처 최신 시각 {last} ({age:.0f}초 경과)")


# ------------------------------------------------------------ 드리프트

def _psi(base: np.ndarray, cur: np.ndarray, bins: int = 10) -> float:
    """Population Stability Index. 0.1 미만 안정, 0.25 이상 심각한 분포 이동."""
    base = base[np.isfinite(base)]
    cur = cur[np.isfinite(cur)]
    if len(base) < 50 or len(cur) < 50:
        return float("nan")
    qs = np.unique(np.quantile(base, np.linspace(0, 1, bins + 1)))
    if len(qs) < 3:
        return float("nan")
    qs[0], qs[-1] = -np.inf, np.inf
    b = np.histogram(base, bins=qs)[0].astype("float64")
    c = np.histogram(cur, bins=qs)[0].astype("float64")
    b = np.maximum(b / b.sum(), 1e-6)
    c = np.maximum(c / c.sum(), 1e-6)
    return float(np.sum((c - b) * np.log(c / b)))


@check("FEAT.PSI_DRIFT", layer=Layer.FEATURE, cadence=Cadence.WEEKLY, gating=False,
       desc="학습 기준분포 대비 PSI. 데이터 파이프 변경/벤더 교체를 조기에 잡아낸다.")
def psi_drift(current, dataset="-", baseline=None, cols=None,
              warn=0.10, fail=0.25, bins=10) -> CheckResult:
    if baseline is None:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP, message="기준(학습) 분포 스냅샷 없음")
    cols = cols or [c for c in current.columns
                    if pd.api.types.is_numeric_dtype(current[c]) and c in baseline.columns]
    rows, worst, worst_c = [], 0.0, None
    for c in cols:
        p = _psi(baseline[c].to_numpy(dtype="float64", na_value=np.nan),
                 current[c].to_numpy(dtype="float64", na_value=np.nan), bins)
        if not np.isfinite(p):
            continue
        if p > worst:
            worst, worst_c = p, c
        if p >= warn:
            rows.append({"feature": c, "psi": round(p, 4)})
    st = judge(worst, warn, fail)
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=worst, threshold=f"PSI warn>{warn}, fail>{fail}",
                       n_bad=len(rows), n_total=len(cols),
                       sample=sorted(rows, key=lambda r: -r["psi"])[:5],
                       message=f"최대 PSI {worst:.3f} ({worst_c}), 임계 초과 {len(rows)}개 피처")


@check("FEAT.CORR_STRUCTURE", layer=Layer.FEATURE, cadence=Cadence.WEEKLY, gating=False,
       desc="피처 간 상관행렬의 구조 변화량. 개별 피처는 멀쩡한데 관계가 깨지는 오류를 잡는다.")
def corr_structure_shift(current, dataset="-", baseline=None, cols=None,
                         warn=0.15, fail=0.30) -> CheckResult:
    if baseline is None:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP, message="기준 상관행렬 없음")
    cols = cols or [c for c in current.columns
                    if pd.api.types.is_numeric_dtype(current[c]) and c in baseline.columns]
    if len(cols) < 2:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP, message="비교 피처 2개 미만")
    a = current[cols].corr().to_numpy()
    b = baseline[cols].corr().to_numpy()
    d = np.abs(a - b)
    np.fill_diagonal(d, 0.0)
    mean_shift = float(np.nanmean(d))
    i, j = np.unravel_index(np.nanargmax(d), d.shape)
    st = judge(mean_shift, warn, fail)
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=mean_shift, threshold=f"평균 |Δρ| warn>{warn}, fail>{fail}",
                       sample=[{"pair": f"{cols[i]}~{cols[j]}", "delta": round(float(d[i, j]), 3)}],
                       message=f"상관 구조 평균 변화 {mean_shift:.3f}, 최대 {float(d[i, j]):.3f}")


@check("FEAT.IC_MONITOR", layer=Layer.SERVING, cadence=Cadence.WEEKLY, gating=False,
       desc="피처↔미래수익률 IC(순위상관)의 부호 반전/급락. 알파 소멸과 데이터 사고의 공통 조기신호.")
def ic_monitor(df, dataset="-", feature_cols=None, target="fwd_ret",
               baseline_ic=None, warn_drop=0.5, fail_drop=1.0,
               min_abs_baseline=0.01) -> CheckResult:
    feature_cols = feature_cols or [c for c in df.columns
                                    if pd.api.types.is_numeric_dtype(df[c]) and c != target]
    if target not in df.columns:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP, message=f"타깃 '{target}' 없음")
    rows, worst = [], 0.0
    base = baseline_ic or {}
    # 노이즈 바닥: Spearman IC의 표준오차 ≈ 1/sqrt(n). 기준 IC가 2*SE 미만이면
    # 애초에 0과 구분되지 않으므로 '상대 변화'를 논할 수 없다.
    n_obs = max(len(df.dropna(subset=[target])), 2)
    floor = max(min_abs_baseline, 2.0 / np.sqrt(n_obs))
    for c in feature_cols:
        ic = float(df[[c, target]].corr(method="spearman").iloc[0, 1])
        if not np.isfinite(ic):
            continue
        b = base.get(c)
        if b is None:
            rows.append({"feature": c, "ic": round(ic, 4), "baseline": None})
            continue
        if abs(b) < floor:
            continue   # 통계적 노이즈 구간 → 비교 제외
        rel = abs(ic - b) / max(abs(b), 1e-6)
        worst = max(worst, rel)
        if rel >= warn_drop or (np.sign(ic) != np.sign(b) and abs(b) > 0.01):
            rows.append({"feature": c, "ic": round(ic, 4), "baseline": round(b, 4),
                         "rel_change": round(rel, 3)})
    st = judge(worst, warn_drop, fail_drop) if base else Status.SKIP
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=worst,
                       threshold=(f"IC 상대변화 warn>{warn_drop:.0%}, fail>{fail_drop:.0%} "
                                  f"(노이즈 바닥 |IC|<{floor:.3f} 제외)"),
                       n_bad=len(rows), n_total=len(feature_cols), sample=rows[:5],
                       message=(f"IC 급변 피처 {len(rows)}개 (최대 상대변화 {worst:.0%})"
                                if base else "베이스라인 IC 없음 → 이번 값을 기준으로 저장"))


# ------------------------------------------------------------ 재현성·누수

@check("FEAT.DETERMINISM", layer=Layer.FEATURE, cadence=Cadence.EOD, gating=True,
       desc="동일 입력으로 피처를 재계산했을 때 저장본과 해시가 일치하는지. 파이프라인 재현성 보증.")
def determinism_hash(stored, dataset="-", recomputed=None, cols=None,
                     round_to=10) -> CheckResult:
    if recomputed is None:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP, message="재계산본 미제공")
    cols = cols or [c for c in stored.columns if c in recomputed.columns]

    def h(d):
        v = d[cols].select_dtypes("number").round(round_to).to_numpy(dtype="float64",
                                                                    na_value=np.nan)
        return hashlib.sha256(np.ascontiguousarray(v).tobytes()).hexdigest()[:16]

    h1, h2 = h(stored), h(recomputed)
    if h1 == h2:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.PASS, threshold="해시 일치",
                           message=f"재현성 OK (sha256[:16]={h1})")
    num = [c for c in cols if pd.api.types.is_numeric_dtype(stored[c])]
    n = min(len(stored), len(recomputed))
    diff = {c: int((~np.isclose(stored[c].to_numpy(dtype='float64', na_value=np.nan)[:n],
                                recomputed[c].to_numpy(dtype='float64', na_value=np.nan)[:n],
                                rtol=1e-9, equal_nan=True)).sum()) for c in num}
    diff = {k: v for k, v in diff.items() if v}
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=Status.FAIL,
                       threshold="해시 일치", n_bad=sum(diff.values()), n_total=n * max(len(num), 1),
                       sample=[diff], message=f"재현 실패 ({h1} != {h2}), 불일치 피처 {len(diff)}개")


@check("FEAT.LOOKAHEAD", layer=Layer.FEATURE, cadence=Cadence.EOD, gating=True,
       desc="시점 t 이후 데이터를 잘라내고 재계산해도 값이 같은지(절단 테스트). 미래참조 직접 검출.")
def lookahead_truncation_test(df, dataset="-", compute_fn=None, ts="ts",
                              keys=("ts", "symbol"), cut_points=3, cols=None,
                              exclude=("fwd_ret",), edge_rows=0, rtol=1e-9) -> CheckResult:
    """compute_fn(raw_df) -> feature_df 를 넘기면, 데이터를 t까지 잘라 재계산해 비교한다.

    미래참조 피처는 '뒤 데이터가 있을 때'와 '없을 때' 값이 달라진다.
    이 성질을 직접 찌르는 것이 가장 확실한 룩어헤드 검출법이다.

    주의 2가지:
      - 비교는 반드시 키(ts, symbol) 조인으로. 행 순서 비교는 오탐을 만든다.
      - 타깃(fwd_ret 등)은 정의상 미래를 보므로 exclude 로 뺀다.
      - edge_rows 는 기본 0. 절단면 근처를 잘라내면 정작 잡아야 할
        미래참조(shift(-k) 류)가 그 구간에만 나타나므로 오히려 놓친다.
        롤링 워밍업 때문에 오탐이 난다면 그때만 소폭 키운다.
    """
    if compute_fn is None:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP, message="compute_fn 미제공 → 절단 테스트 생략")
    keys = [k for k in keys if k in df.columns]
    d = df.sort_values(ts).reset_index(drop=True)
    full = compute_fn(d.copy())
    cols = cols or [c for c in full.columns
                    if pd.api.types.is_numeric_dtype(full[c]) and c not in keys
                    and c not in set(exclude)]
    n = len(d)
    bad_feats: dict[str, int] = {}
    tested = 0
    for frac in np.linspace(0.5, 0.9, cut_points):
        cut = int(n * frac)
        if cut < 50:
            continue
        part = compute_fn(d.iloc[:cut].copy())
        cutoff = (pd.to_datetime(part[ts]).sort_values().iloc[-edge_rows]
                  if edge_rows > 0 and len(part) > edge_rows else None)
        m = full.merge(part, on=keys, how="inner", suffixes=("", "_cut"))
        if cutoff is not None:
            m = m[pd.to_datetime(m[ts]) < cutoff]
        if m.empty:
            continue
        for c in cols:
            if f"{c}_cut" not in m.columns:
                continue
            a = m[c].to_numpy(dtype="float64", na_value=np.nan)
            b = m[f"{c}_cut"].to_numpy(dtype="float64", na_value=np.nan)
            k = int((~np.isclose(a, b, rtol=rtol, equal_nan=True)).sum())
            tested += len(m)
            if k:
                bad_feats[c] = bad_feats.get(c, 0) + k
    st = Status.FAIL if bad_feats else Status.PASS
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=float(len(bad_feats)), threshold="절단 전후 불일치 0건",
                       n_bad=sum(bad_feats.values()), n_total=tested,
                       sample=[dict(sorted(bad_feats.items(), key=lambda x: -x[1])[:5])],
                       message=(f"미래참조 의심 피처 {len(bad_feats)}개: "
                                f"{list(bad_feats)[:5]}" if bad_feats else "절단 테스트 통과"))


@check("FEAT.TARGET_LEAKAGE", layer=Layer.FEATURE, cadence=Cadence.WEEKLY, gating=True,
       desc="피처↔타깃 동시점 상관이 비상식적으로 높은지. |IC|>0.3은 알파가 아니라 누수일 확률이 높다.")
def target_leakage(df, dataset="-", feature_cols=None, target="fwd_ret",
                   exclude=(), warn_abs=0.20, fail_abs=0.35) -> CheckResult:
    if target not in df.columns:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP, message=f"타깃 '{target}' 없음")
    # 화이트리스트보다 블랙리스트가 안전하다 — 새로 추가된 피처가 감시망을 빠져나가지 않는다.
    feature_cols = feature_cols or [c for c in df.columns
                                    if pd.api.types.is_numeric_dtype(df[c])
                                    and c != target and c not in set(exclude)]
    rows, worst, worst_c = [], 0.0, None
    for c in feature_cols:
        ic = df[[c, target]].corr(method="spearman").iloc[0, 1]
        if not np.isfinite(ic):
            continue
        a = abs(float(ic))
        if a > worst:
            worst, worst_c = a, c
        if a >= warn_abs:
            rows.append({"feature": c, "abs_ic": round(a, 4)})
    st = judge(worst, warn_abs, fail_abs)
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=worst, threshold=f"|IC| warn>{warn_abs}, fail>{fail_abs}",
                       n_bad=len(rows), n_total=len(feature_cols), sample=rows[:5],
                       message=(f"최대 |IC| {worst:.3f} ({worst_c}) "
                                f"— 실전 단일피처 IC는 보통 0.02~0.06"))


@check("FEAT.TRAIN_SERVE_SKEW", layer=Layer.SERVING, cadence=Cadence.EOD, gating=True,
       desc="오프라인(배치) 피처와 온라인(서빙) 피처의 동일 키 값 불일치율. 두 코드 경로의 분기 탐지.")
def train_serve_skew(offline, dataset="-", online=None, keys=("ts", "symbol"),
                     cols=None, rtol=1e-6, warn_ratio=0.0, fail_ratio=0.001) -> CheckResult:
    if online is None:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP, message="온라인 서빙 스냅샷 미제공")
    keys = list(keys)
    m = offline.merge(online, on=keys, how="inner", suffixes=("", "_srv"))
    cols = cols or [c for c in offline.columns
                    if c not in keys and f"{c}_srv" in m.columns
                    and pd.api.types.is_numeric_dtype(offline[c])]
    bad, rows = 0, []
    for c in cols:
        a = m[c].to_numpy(dtype="float64", na_value=np.nan)
        b = m[f"{c}_srv"].to_numpy(dtype="float64", na_value=np.nan)
        k = int((~np.isclose(a, b, rtol=rtol, equal_nan=True)).sum())
        bad += k
        if k:
            rows.append({"feature": c, "n_diff": k})
    total = max(len(m) * max(len(cols), 1), 1)
    ratio = bad / total
    st = judge(ratio, warn_ratio, fail_ratio)
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=ratio, threshold=f"skew 비율 fail>{fail_ratio:.2%}",
                       n_bad=bad, n_total=total, sample=rows[:5],
                       message=f"train/serve 불일치 {bad}건 ({len(rows)}개 피처, 매칭 {len(m)}행)")
