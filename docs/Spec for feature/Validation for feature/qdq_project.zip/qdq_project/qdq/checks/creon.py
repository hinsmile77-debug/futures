"""
L0 CREON — 대신 CYBOS Plus / CREON Plus 로컬 수집기 건강 점검.

실측 사양(대신증권 공식 FAQ / CybosPlus 도움말 기준):
  · Plus API가 32bit COM → 파이썬도 반드시 32비트 (프로세스 주소공간 제약)
  · 시세(비주문) 요청 : 15초당 60건   (초과 시 대기)
  · 주문 요청        : 15초당 20건   (초과 시 함수가 4 반환)
  · 실시간 구독      : 최대 400건    (초과 시 오류)
  · CpUtil.CpCybos : IsConnect(0/1), ServerType(0/1/2),
                     GetLimitRemainCount(LT_TRADE_REQUEST|LT_NONTRADE_REQUEST|LT_SUBSCRIBE),
                     LimitRequestRemainTime(ms), OnDisConnect 이벤트

비유: 잠수부의 공기통 게이지 세 개.
  남은 공기(요청 한도), 호스 꼬임(큐 적체), 부력조끼 용량(구독 슬롯).
  물속(장중)에서는 셋 다 *미리* 봐야 한다. 숨이 막힌 뒤에 확인하면 늦는다.

크레온 고유의 함정:
  구독 슬롯 400개는 생각보다 빨리 찬다. 옵션 체인 하나(행사가 40 × 콜/풋)를
  체결+호가로 구독하면 그것만 160슬롯이고, 만기 2개면 320슬롯이다.
  여기에 선물 몇 종목만 얹으면 한도를 넘고, 그때부터 **일부 종목이 조용히 안 들어온다**.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from ..core import CheckResult, Cadence, Layer, Status, check, judge, utc

# CYBOS Plus / CREON Plus 공식 제한치
NONTRADE_LIMIT_PER_15S = 60      # 시세 요청
TRADE_LIMIT_PER_15S = 20         # 주문 요청
SUBSCRIBE_LIMIT = 400            # 실시간 구독 슬롯
BIT32_LIMIT_MB = 2048.0          # 32비트 프로세스 주소공간 (LAA 미적용 기준)


# ------------------------------------------------------------ 프로세스 건강

@check("CREON.CONNECT", layer=Layer.FEED, cadence=Cadence.REALTIME, gating=True,
       desc="CpCybos.IsConnect / ServerType 상태. ServerType=2(HTS 보통서버)면 Plus 기능이 제한된다.")
def connection_state(is_connect, dataset="-", server_type=None,
                     disconnect_events=0) -> CheckResult:
    ok = int(is_connect) == 1
    st = Status.PASS if ok else Status.FAIL
    msg = f"IsConnect={int(is_connect)}"
    if server_type is not None:
        names = {0: "연결끊김", 1: "cybosplus 서버", 2: "HTS 보통서버"}
        msg += f", ServerType={int(server_type)}({names.get(int(server_type), '?')})"
        if int(server_type) == 2 and st == Status.PASS:
            st = Status.WARN
            msg += " → Plus 전용 기능 제한 가능, 접속 주소 확인"
    if disconnect_events:
        msg += f", 세션 내 OnDisConnect {int(disconnect_events)}회"
        if st == Status.PASS:
            st = Status.WARN
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=float(int(is_connect)),
                       threshold="IsConnect=1, ServerType=1, OnDisConnect 0회",
                       message=msg)


@check("CREON.MEMORY", layer=Layer.FEED, cadence=Cadence.REALTIME, gating=True,
       desc="수집 프로세스 RSS. 32비트 COM 바인딩이라 2GB 벽에 부딪히면 조용히 응답이 멈춘다.")
def process_memory(rss_mb, dataset="-", limit_mb=BIT32_LIMIT_MB,
                   warn_frac=0.65, fail_frac=0.80, history_mb=None,
                   leak_slope_mb_per_hour=80.0) -> CheckResult:
    """rss_mb: 현재 RSS(MB). history_mb: 최근 N분 RSS 시계열(1분 간격 가정).

    크레온 장애의 전형은 '에러가 나는 것'이 아니라 '아무 말 없이 이벤트가 끊기는 것'이다.
    그래서 레벨보다 **증가 기울기**가 더 유용한 조기 경보다.
    """
    rss = float(rss_mb)
    frac = rss / limit_mb
    st = judge(frac, warn_frac, fail_frac)

    slope = None
    if history_mb is not None and len(history_mb) >= 10:
        h = pd.Series(history_mb, dtype="float64").dropna()
        x = np.arange(len(h), dtype="float64")
        slope = float(np.polyfit(x, h.to_numpy(), 1)[0] * 60)   # MB/시간
        if slope > leak_slope_mb_per_hour and st == Status.PASS:
            st = Status.WARN

    msg = f"RSS {rss:.0f}MB / 한계 {limit_mb:.0f}MB ({frac:.0%})"
    if slope is not None:
        msg += f", 증가율 {slope:+.0f}MB/h"
        if slope > leak_slope_mb_per_hour:
            eta = (limit_mb * fail_frac - rss) / max(slope, 1e-9)
            msg += f" → 누수 의심, 임계까지 약 {eta:.1f}h (장 마감 전 재기동 검토)"
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=frac,
                       threshold=(f"사용률 warn>{warn_frac:.0%}, fail>{fail_frac:.0%} / "
                                  f"증가율 {leak_slope_mb_per_hour:.0f}MB/h 초과 시 경고"),
                       message=msg)


@check("CREON.QUEUE_DEPTH", layer=Layer.FEED, cadence=Cadence.REALTIME, gating=True,
       desc="COM 이벤트 → 워커 큐 적체. 큐가 쌓인다는 건 이미 늦게 처리 중이라는 뜻이고 곧 드롭이 시작된다.")
def queue_depth(depth, dataset="-", warn=500, fail=5000, capacity=None,
                history=None) -> CheckResult:
    d = float(depth)
    st = judge(d, float(warn), float(fail))
    msg = f"큐 대기 {int(d)}건"
    if capacity:
        msg += f" / 용량 {int(capacity)} ({d / capacity:.0%})"
    if history is not None and len(history) >= 5:
        h = pd.Series(history, dtype="float64")
        if bool((h.diff().dropna() > 0).all()) and st == Status.PASS:
            st = Status.WARN
            msg += " · 연속 증가 → 소비 스레드 처리량 부족 (파싱을 이벤트 핸들러 밖으로 빼야 함)"
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=d, threshold=f"warn>{warn}건, fail>{fail}건", message=msg)


@check("CREON.HEARTBEAT", layer=Layer.FEED, cadence=Cadence.REALTIME, gating=True,
       desc="수집 스레드가 1분마다 남기는 하트비트(메모리·큐·최근틱시각)의 결번과 신선도.")
def heartbeat_log(df, dataset="-", ts="ts", now=None, expected_interval_sec=60,
                  warn_miss=1, fail_miss=3) -> CheckResult:
    """비유: 등대의 회전 불빛. 몇 번 건너뛰었는지 세면 수집 스레드가 기절했던 구간을 정확히 짚는다.

    반드시 **메인 트레이딩 스레드와 별개 스레드**에서 기록해야 한다.
    메인 스레드가 멈추면 하트비트도 같이 멈춰서 아무것도 못 알려주기 때문이다.
    """
    now = utc(now, default_now=True)
    t = pd.to_datetime(df[ts], utc=True).sort_values()
    if len(t) < 2:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP, message="하트비트 표본 부족")
    gaps = t.diff().dt.total_seconds().dropna()
    missed = int(((gaps / expected_interval_sec) - 1).round().clip(lower=0).sum())
    age = (now - t.iloc[-1]).total_seconds()
    st = judge(float(missed), float(warn_miss), float(fail_miss))
    if age > expected_interval_sec * 3:
        st = Status.FAIL
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=float(missed),
                       threshold=(f"결번 warn>{warn_miss}, fail>{fail_miss} / "
                                  f"최신성 {expected_interval_sec * 3}s"),
                       n_bad=missed, n_total=len(t),
                       message=(f"하트비트 결번 {missed}회, 마지막 기록 {age:.0f}초 전"
                                + (" → 수집 스레드 정지 의심" if age > expected_interval_sec * 3 else "")))


# ------------------------------------------------------------ 크레온 고유 한도

@check("CREON.SUBSCRIBE_SLOTS", layer=Layer.FEED, cadence=Cadence.REALTIME, gating=True,
       desc="실시간 구독 슬롯(최대 400) 소진율. 초과분은 구독이 안 걸리고 그 종목만 조용히 비어버린다.")
def subscribe_slots(used, dataset="-", limit=SUBSCRIBE_LIMIT, remain=None,
                    requested_symbols=None, active_symbols=None,
                    warn_frac=0.85, fail_frac=0.97) -> CheckResult:
    """used: 현재 구독 중인 슬롯 수. remain: GetLimitRemainCount(LT_SUBSCRIBE) 값.

    핵심은 **요청한 종목 수 vs 실제 이벤트가 들어오는 종목 수**를 대조하는 것이다.
    슬롯이 모자라면 구독 등록만 실패하고 프로그램은 멀쩡히 돌아가므로,
    "왜 이 옵션만 데이터가 없지?"를 몇 주 뒤에 알게 되는 사고가 난다.
    """
    u = float(used if remain is None else limit - remain)
    frac = u / max(float(limit), 1.0)
    st = judge(frac, warn_frac, fail_frac)

    missing: list[str] = []
    if requested_symbols is not None and active_symbols is not None:
        missing = sorted(set(requested_symbols) - set(active_symbols))
        if missing:
            st = Status.FAIL

    msg = f"구독 {int(u)}/{int(limit)} 슬롯 ({frac:.0%})"
    if missing:
        msg += f" · 구독 요청했으나 수신 없는 종목 {len(missing)}개 → 슬롯 부족 또는 등록 실패"
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=frac,
                       threshold=f"소진율 warn>{warn_frac:.0%}, fail>{fail_frac:.0%} / 미수신 종목 0개",
                       n_bad=len(missing), n_total=int(limit),
                       sample=[{"미수신종목": missing[:20]}] if missing else [],
                       message=msg)


@check("CREON.REQUEST_QUOTA", layer=Layer.FEED, cadence=Cadence.INTRADAY, gating=False,
       desc="시세 15초/60건, 주문 15초/20건 잔여 한도. EOD 대사용 조회 여유를 반드시 남겨야 한다.")
def request_quota(remain_nontrade, dataset="-", remain_trade=None, remain_time_ms=None,
                  nontrade_limit=NONTRADE_LIMIT_PER_15S, trade_limit=TRADE_LIMIT_PER_15S,
                  warn_frac=0.7, fail_frac=0.9) -> CheckResult:
    """remain_* 는 CpCybos.GetLimitRemainCount(...) 반환값(남은 개수)."""
    used_n = nontrade_limit - float(remain_nontrade)
    frac_n = used_n / max(float(nontrade_limit), 1.0)
    st = judge(frac_n, warn_frac, fail_frac)

    parts = [f"시세 {int(used_n)}/{nontrade_limit}건 (15초 창, {frac_n:.0%})"]
    if remain_trade is not None:
        used_t = trade_limit - float(remain_trade)
        frac_t = used_t / max(float(trade_limit), 1.0)
        parts.append(f"주문 {int(used_t)}/{trade_limit}건 ({frac_t:.0%})")
        st_t = judge(frac_t, warn_frac, fail_frac)
        if st_t == Status.FAIL:
            st = Status.FAIL   # 주문 한도 초과는 곧 '주문이 안 나간다'는 뜻
        elif st_t == Status.WARN and st == Status.PASS:
            st = Status.WARN
    if remain_time_ms is not None:
        parts.append(f"재계산까지 {int(remain_time_ms)}ms")

    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=frac_n,
                       threshold=f"소진율 warn>{warn_frac:.0%}, fail>{fail_frac:.0%}",
                       message=" · ".join(parts))


# ------------------------------------------------------------ 틱 무결성 (크레온 핵심)

@check("CREON.TICK_CONTINUITY", layer=Layer.FEED, cadence=Cadence.REALTIME, gating=True,
       desc="누적거래량의 단조성과 1회 증분 크기. FutureCurOnly는 체결수량을 안 주므로 이게 유일한 유실 탐지 수단이다.")
def tick_continuity(df, dataset="-", cum_vol="cum_volume", ts="ts", key="symbol",
                    max_delta_qty=None, z_warn=8.0, z_fail=20.0) -> CheckResult:
    """크레온 파생 실시간(FutureCurOnly)은 **체결가·체결수량 필드를 제공하지 않는다.**
    제공되는 건 현재가(1), 누적거래량(13), 시각(15), 체결구분(24), 누적체결매수/매도(23/22) 등이다.

    따라서 틱 볼륨은 `누적거래량.diff()` 로 만들 수밖에 없는데, 여기에 함정이 있다.

      이벤트를 놓쳐도 **다음 이벤트의 차분이 놓친 물량을 통째로 흡수**한다.
      → 총 거래량은 그대로 맞는다. 거래량 대사는 통과한다.
      → 그런데 그 물량 전체가 '다음 틱의 체결구분'으로 잘못 분류된다. CVD만 틀린다.

    비유: 수도 계량기만 보고 있는 것과 같다. 총 사용량은 맞지만
    "언제 얼마나 썼는지"는 검침 사이가 벌어질수록 뭉개진다.

    그래서 여기서는 ① 누적거래량 역행(리셋/재접속) ② 비정상적으로 큰 증분(= 그 사이 유실)
    두 가지를 본다.
    """
    if cum_vol not in df.columns:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP, message=f"'{cum_vol}' 컬럼 없음")
    back, big, total, samples = 0, 0, 0, []
    worst_z = 0.0
    grouper = df.groupby(key, observed=True) if key in df.columns else [(None, df)]
    for sym, g in grouper:
        g = g.sort_values(ts) if ts in g.columns else g
        v = g[cum_vol].astype("float64")
        d = v.diff().dropna()
        if d.empty:
            continue
        total += len(d)
        b = int((d < 0).sum())          # 역행 = 세션 리셋 또는 재접속 후 카운터 초기화
        back += b
        pos = d[d > 0]
        if len(pos) >= 30:
            med = float(pos.median())
            mad = float((pos - med).abs().median()) or 1e-9
            z = (pos - med) / (1.4826 * mad)
            worst_z = max(worst_z, float(z.max()))
            hit = z[z > z_warn]
            big += len(hit)
            for i in hit.head(3).index:
                samples.append({"symbol": str(sym), "ts": str(g.loc[i, ts]) if ts in g else str(i),
                                "delta": float(d[i]), "z": round(float(z[i]), 1)})
        if max_delta_qty is not None:
            over = int((d > max_delta_qty).sum())
            big += over

    st = judge(worst_z, z_warn, z_fail)
    if back:
        st = Status.FAIL
    return CheckResult(
        check_id="", layer="", cadence="", dataset=dataset, status=st,
        metric=worst_z,
        threshold=f"증분 robust-Z warn>{z_warn}, fail>{z_fail} / 누적거래량 역행 0건",
        n_bad=back + big, n_total=total, sample=samples[:5],
        message=(f"누적거래량 역행 {back}건, 비정상 증분 {big}건 (최대 Z={worst_z:.1f})"
                 + (" → 역행은 세션 리셋/재접속 신호, 해당 시점 이후 재동기화 필요" if back else "")),
    )


@check("CREON.CVD_ANCHOR", layer=Layer.CURATED, cadence=Cadence.INTRADAY, gating=True,
       desc="자체 누적 CVD vs 서버 제공 (누적체결매수−누적체결매도). 크레온에서 CVD를 검증하는 유일한 정답지.")
def cvd_anchor(df, dataset="-", my_cvd="cvd_cum", buy_col="cum_buy", sell_col="cum_sell",
               vol_col="cum_volume", warn_frac=0.005, fail_frac=0.02) -> CheckResult:
    """FutureCurOnly 는 누적체결매수(23) / 누적체결매도(22) 를 그대로 준다.
    내가 체결구분(24)으로 분류해 쌓은 CVD가 이 값과 맞는지 대조하면
    분류 로직 버그도, 이벤트 유실로 인한 오배분도 한 번에 잡힌다.

    |CVD| ≤ Volume 같은 부등식 점검보다 훨씬 강하다.
    부등식은 '말이 되는지'만 보지만, 이건 '정답과 같은지'를 본다.
    """
    need = [my_cvd, buy_col, sell_col]
    miss = [c for c in need if c not in df.columns]
    if miss:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP,
                           message=f"앵커 컬럼 없음 {miss} — 누적체결매수/매도(23/22)를 함께 저장할 것")

    mine_cum = df[my_cvd].astype("float64")
    anchor_cum = df[buy_col].astype("float64") - df[sell_col].astype("float64")

    # ── 주지표: 봉 단위 증분 비교 ────────────────────────────────
    # 누적끼리 비교하면 오차가 누적거래량으로 나눠지면서 장 후반으로 갈수록 희석된다.
    # (오전에 생긴 오차가 오후엔 '작아 보인다') 증분 비교는 그 희석이 없고,
    # 사고가 난 정확한 봉을 짚어준다.
    d_mine = mine_cum.diff()
    d_anchor = anchor_cum.diff()
    d_vol = (df[vol_col].astype("float64").diff() if vol_col in df.columns
             else d_anchor.abs())
    scale = d_vol.abs().clip(lower=1.0)
    rel = ((d_mine - d_anchor).abs() / scale).iloc[1:]
    worst = float(rel.max()) if len(rel) else 0.0
    st = judge(worst, warn_frac, fail_frac)
    bad = rel > warn_frac

    # ── 보조지표: 하루 끝 누적 오프셋(한 번 어긋나면 계속 남는다) ──
    off = float((mine_cum - anchor_cum).iloc[-1]) if len(df) else 0.0
    off_rel = abs(off) / max(float(df[vol_col].iloc[-1]) if vol_col in df.columns else 1.0, 1.0)

    cols = [c for c in ("ts", "symbol") if c in df.columns]
    idx = rel[bad].nlargest(5).index
    return CheckResult(
        check_id="", layer="", cadence="", dataset=dataset, status=st,
        metric=worst,
        threshold=(f"봉단위 |Δ자체−Δ앵커|/Δ거래량 warn>{warn_frac:.2%}, fail>{fail_frac:.2%}"),
        n_bad=int(bad.sum()), n_total=int(len(rel)),
        sample=(df.loc[idx, cols].assign(
            자체증분=d_mine[idx].round(0), 앵커증분=d_anchor[idx].round(0),
            괴리율=rel[idx].round(4)).astype(str).to_dict("records") if bad.any() else []),
        message=(f"봉단위 CVD 최대 괴리 {worst:.2%}, 이탈 {int(bad.sum())}/{len(rel)}봉 · "
                 f"장 마감 누적 오프셋 {off:+,.0f}계약({off_rel:.3%})"
                 + (" → 체결구분 분류 로직 또는 이벤트 유실 점검" if bad.any() else "")),
    )


@check("CREON.ZERO_VALUE", layer=Layer.CURATED, cadence=Cadence.REALTIME, gating=True,
       desc="현재가 0 / 거래량 음수 / 피처 NaN 이 들어온 봉을 식별하고 그 봉의 신호 생성을 차단.")
def zero_value_guard(df, dataset="-", price_cols=("close",), vol_col="volume",
                     feature_cols=None, allow_zero_volume=False,
                     warn_ratio=0.0, fail_ratio=0.0) -> CheckResult:
    """0 은 결측의 위장이다.

    동시호가 직후나 구독 등록 직후 첫 이벤트에서 현재가 0 이 들어오면
    수익률이 −100% 로 찍히고, 이 한 봉이 이동평균·변동성·Z-score 를 통째로 오염시킨다.
    결과의 sample 에 '차단해야 할 타임스탬프'를 담아준다.
    """
    bad = pd.Series(False, index=df.index)
    reasons: dict[str, int] = {}

    for c in price_cols:
        if c in df.columns:
            m = ((df[c] <= 0) | df[c].isna()).fillna(True)
            if m.any():
                reasons[f"{c}<=0/NaN"] = int(m.sum())
            bad |= m

    if vol_col in df.columns and not allow_zero_volume:
        m = (df[vol_col].isna() | (df[vol_col] < 0)).fillna(True)
        if m.any():
            reasons[f"{vol_col} 음수/NaN"] = int(m.sum())
        bad |= m

    for c in (feature_cols or []):
        if c in df.columns:
            v = df[c].to_numpy(dtype="float64", na_value=np.nan)
            m = pd.Series(~np.isfinite(v), index=df.index)
            if m.any():
                reasons[f"{c} NaN/inf"] = int(m.sum())
            bad |= m

    ratio = float(bad.mean()) if len(df) else 0.0
    st = judge(ratio, warn_ratio, fail_ratio)
    ts_col = "ts" if "ts" in df.columns else None
    blocked = ([str(x) for x in df.loc[bad, ts_col].head(20)] if ts_col
               else [int(i) for i in df.index[bad][:20]])
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=ratio, threshold="0/NaN 봉 0건 (발생 시 해당 봉 신호 차단)",
                       n_bad=int(bad.sum()), n_total=len(df),
                       sample=[{"사유별": reasons, "차단대상": blocked}],
                       message=f"0/NaN 오염 봉 {int(bad.sum())}/{len(df)}건 → 해당 봉 매매신호 차단")


def blocked_timestamps(df, price_cols=("close",), vol_col="volume",
                       feature_cols=(), allow_zero_volume=False) -> pd.Index:
    """전략 코드에서 바로 쓰는 헬퍼.

        block = blocked_timestamps(bars, feature_cols=["cvd", "hurst"])
        signal.loc[block] = 0
    """
    bad = pd.Series(False, index=df.index)
    for c in price_cols:
        if c in df.columns:
            bad |= ((df[c] <= 0) | df[c].isna()).fillna(True)
    if vol_col in df.columns and not allow_zero_volume:
        bad |= (df[vol_col].isna() | (df[vol_col] < 0)).fillna(True)
    for c in feature_cols:
        if c in df.columns:
            v = df[c].to_numpy(dtype="float64", na_value=np.nan)
            bad |= pd.Series(~np.isfinite(v), index=df.index)
    return df.index[bad]
