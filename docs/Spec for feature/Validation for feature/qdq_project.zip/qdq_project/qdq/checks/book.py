"""
L2 — 호가(Order Book / Quote) 무결성 점검.

비유: 경매장 호가판.
  파는 사람이 부르는 최저가(ask)가 사는 사람이 부르는 최고가(bid)보다
  낮아지면(= crossed) 그건 경매가 아니라 오류다.
  또 호가는 위에서 아래로 가격이 정렬돼 있어야 하고, 수량은 음수일 수 없다.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from ..core import CheckResult, Cadence, Layer, Status, check, judge


@check("BOOK.CROSSED", layer=Layer.CURATED, cadence=Cadence.REALTIME, gating=True,
       desc="bid1 >= ask1 인 crossed/locked book 비율. 스냅샷-델타 적용 오류의 대표 증상.")
def crossed_or_locked(df, dataset="-", bid="bid1", ask="ask1",
                      warn_ratio=0.0, fail_ratio=0.0001) -> CheckResult:
    b, a = df[bid].astype("float64"), df[ask].astype("float64")
    crossed = (b > a) & b.notna() & a.notna()
    locked = (b == a) & b.notna() & a.notna()
    ratio = float((crossed | locked).mean()) if len(df) else 0.0
    st = judge(ratio, warn_ratio, fail_ratio)
    if crossed.any():
        st = Status.FAIL
    cols = [c for c in ("ts", "symbol", bid, ask) if c in df.columns]
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=ratio, threshold="crossed 0건 (locked는 경고)",
                       n_bad=int((crossed | locked).sum()), n_total=len(df),
                       sample=df.loc[crossed | locked, cols].head(5).astype(str).to_dict("records"),
                       message=f"crossed {int(crossed.sum())}건, locked {int(locked.sum())}건")


@check("BOOK.LEVEL_ORDER", layer=Layer.CURATED, cadence=Cadence.INTRADAY, gating=True,
       desc="호가 단계별 가격 정렬(매수 내림차순, 매도 오름차순)과 수량 양수 조건.")
def level_ordering(df, dataset="-", depth=5, warn_ratio=0.0, fail_ratio=0.0) -> CheckResult:
    bad = pd.Series(False, index=df.index)
    checked = 0
    for i in range(1, depth):
        bp0, bp1 = f"bid{i}", f"bid{i+1}"
        ap0, ap1 = f"ask{i}", f"ask{i+1}"
        if bp0 in df and bp1 in df:
            bad |= (df[bp1] >= df[bp0]).fillna(False); checked += 1
        if ap0 in df and ap1 in df:
            bad |= (df[ap1] <= df[ap0]).fillna(False); checked += 1
    for i in range(1, depth + 1):
        for q in (f"bid{i}_qty", f"ask{i}_qty"):
            if q in df:
                bad |= (df[q] < 0).fillna(False); checked += 1
    if checked == 0:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP, message="다단계 호가 컬럼 없음")
    ratio = float(bad.mean()) if len(df) else 0.0
    st = judge(ratio, warn_ratio, fail_ratio)
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=ratio, threshold="정렬 위반 0건",
                       n_bad=int(bad.sum()), n_total=len(df),
                       message=f"호가 정렬/수량 위반 {int(bad.sum())}/{len(df)}건")


@check("BOOK.SPREAD_OUTLIER", layer=Layer.CURATED, cadence=Cadence.INTRADAY, gating=False,
       desc="상대 스프레드(bp)의 극단값 비율. 한쪽 호가 소실/오염 탐지.")
def spread_outlier(df, dataset="-", bid="bid1", ask="ask1",
                   max_bp=500.0, warn_ratio=0.005, fail_ratio=0.02) -> CheckResult:
    b, a = df[bid].astype("float64"), df[ask].astype("float64")
    mid = (a + b) / 2
    sp_bp = (a - b) / mid * 1e4
    valid = mid > 0
    bad = ((sp_bp > max_bp) | (sp_bp < 0)) & valid
    ratio = float(bad.sum() / max(int(valid.sum()), 1))
    st = judge(ratio, warn_ratio, fail_ratio)
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=ratio, threshold=f"스프레드>{max_bp}bp 비율 fail>{fail_ratio:.2%}",
                       n_bad=int(bad.sum()), n_total=int(valid.sum()),
                       message=(f"이상 스프레드 {int(bad.sum())}건, "
                                f"중앙값 {float(sp_bp[valid].median()):.2f}bp"))


@check("BOOK.TRADE_IN_RANGE", layer=Layer.CURATED, cadence=Cadence.INTRADAY, gating=False,
       desc="체결가가 동시각 호가 범위(bid1~ask1) 밖인 비율. 체결-호가 시계 정합성 검증.")
def trade_within_quote(trades, dataset="-", quotes=None, ts="ts", sym="symbol",
                       px="price", tol_tick=1, tick=0.05,
                       warn_ratio=0.02, fail_ratio=0.10) -> CheckResult:
    if quotes is None:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP, message="호가 데이터 미제공")
    t = trades.sort_values(ts)
    q = quotes.sort_values(ts)
    m = pd.merge_asof(t, q[[ts, sym, "bid1", "ask1"]], on=ts, by=sym,
                      direction="backward", allow_exact_matches=True)
    valid = m["bid1"].notna() & m["ask1"].notna()
    out = ((m[px] < m["bid1"] - tol_tick * tick) |
           (m[px] > m["ask1"] + tol_tick * tick)) & valid
    ratio = float(out.sum() / max(int(valid.sum()), 1))
    st = judge(ratio, warn_ratio, fail_ratio)
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=ratio, threshold=f"이탈률 warn>{warn_ratio:.1%}, fail>{fail_ratio:.1%}",
                       n_bad=int(out.sum()), n_total=int(valid.sum()),
                       sample=m.loc[out, [ts, sym, px, "bid1", "ask1"]].head(5).astype(str).to_dict("records"),
                       message=f"호가 범위 밖 체결 {int(out.sum())}/{int(valid.sum())}건")


@check("BOOK.SNAPSHOT_DELTA", layer=Layer.FEED, cadence=Cadence.REALTIME, gating=True,
       desc="델타 누적으로 재구성한 북과 주기적 스냅샷의 일치 여부. 실시간 북의 핵심 검증.")
def snapshot_delta_consistency(rebuilt, dataset="-", snapshot=None,
                               cols=("bid1", "ask1", "bid1_qty", "ask1_qty"),
                               rtol=1e-9) -> CheckResult:
    if snapshot is None:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP, message="스냅샷 미제공")
    cols = [c for c in cols if c in rebuilt and c in snapshot]
    if not cols:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP, message="비교 가능한 컬럼 없음")
    mism = 0
    for c in cols:
        a = np.asarray(rebuilt[c], dtype="float64")
        b = np.asarray(snapshot[c], dtype="float64")
        n = min(len(a), len(b))
        mism += int((~np.isclose(a[:n], b[:n], rtol=rtol, equal_nan=True)).sum())
    total = max(min(len(rebuilt), len(snapshot)) * len(cols), 1)
    ratio = mism / total
    st = Status.FAIL if mism else Status.PASS
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=ratio, threshold="불일치 0건 → 발생 시 즉시 재동기화",
                       n_bad=mism, n_total=total,
                       message=f"델타 재구성 vs 스냅샷 불일치 {mism}건")
