"""
L3 FEATURE-MATH — 가공 지표의 수학적 한계 검증.

비유: 체온계 눈금 검사.
  "43도"가 찍혔다면 환자를 의심할 게 아니라 체온계를 의심해야 한다.
  피처에도 물리적으로 넘을 수 없는 선이 있고, 그 선을 넘었다는 건
  시장이 이상한 게 아니라 계산이 깨졌다는 뜻이다.

단, 선을 긋기 전에 **그 선이 이론값의 선인지 추정량의 선인지**를 구분해야 한다.
이 둘을 섞으면 멀쩡한 값을 계속 FAIL 처리하게 되고, 결국 아무도 알림을 안 본다.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from ..core import CheckResult, Cadence, Layer, Status, check, judge


# ------------------------------------------------------------ CVD

@check("MATH.CVD_BOUND", layer=Layer.FEATURE, cadence=Cadence.INTRADAY, gating=True,
       desc="|봉내 CVD| ≤ 봉 거래량, 그리고 매수량+매도량 = 총거래량. 체결 분류 로직의 항등식.")
def cvd_bound(df, dataset="-", cvd="cvd_1m", vol="volume",
              buy="buy_volume", sell="sell_volume", tol=1e-6,
              warn_ratio=0.0, fail_ratio=0.0) -> CheckResult:
    """두 가지를 본다. 두 번째가 훨씬 예리하다.

      ① 부등식  |CVD| ≤ Volume            — 말이 되는지 (약한 조건)
      ② 항등식  Buy + Sell == Volume      — 정확히 맞는지 (강한 조건)

    ①만 보면 '매수 60 / 매도 30 / 총 100' 처럼 10이 증발한 상태를 통과시킨다.
    (|30| ≤ 100 이므로) 분류 로직 버그는 대개 이런 형태로 나타나므로 ②가 필요하다.
    """
    if cvd not in df.columns or vol not in df.columns:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP, message=f"'{cvd}' 또는 '{vol}' 컬럼 없음")
    v = df[vol].astype("float64")
    c = df[cvd].astype("float64")
    viol_ineq = (c.abs() > v + tol) | ~np.isfinite(c)
    reasons = {"부등식 |CVD|>Volume": int(viol_ineq.sum())}
    bad = viol_ineq.copy()

    if buy in df.columns and sell in df.columns:
        b, s = df[buy].astype("float64"), df[sell].astype("float64")
        viol_id = ((b + s) - v).abs() > tol * np.maximum(v.abs(), 1.0)
        viol_neg = (b < 0) | (s < 0)
        viol_cvd = ((b - s) - c).abs() > tol * np.maximum(v.abs(), 1.0)
        reasons["항등식 Buy+Sell≠Volume"] = int(viol_id.sum())
        reasons["매수/매도 음수"] = int(viol_neg.sum())
        reasons["CVD≠Buy−Sell"] = int(viol_cvd.sum())
        bad |= viol_id | viol_neg | viol_cvd
    else:
        reasons["※ buy/sell 컬럼 없음"] = -1     # 약한 조건만 검증 중임을 표시

    ratio = float(bad.mean()) if len(df) else 0.0
    st = judge(ratio, warn_ratio, fail_ratio)
    cols = [x for x in ("ts", "symbol", cvd, vol, buy, sell) if x in df.columns]
    return CheckResult(
        check_id="", layer="", cadence="", dataset=dataset, status=st,
        metric=ratio, threshold="위반 0건 (항등식이므로 예외 없음)",
        n_bad=int(bad.sum()), n_total=len(df),
        sample=[reasons] + df.loc[bad, cols].head(4).astype(str).to_dict("records"),
        message=(f"CVD 제약 위반 {int(bad.sum())}/{len(df)}건 · "
                 + ", ".join(f"{k}={v}" for k, v in reasons.items() if v)),
    )


@check("MATH.CVD_CONSISTENCY", layer=Layer.FEATURE, cadence=Cadence.EOD, gating=False,
       desc="누적 CVD가 봉단위 CVD의 누적합과 일치하는지. 리샘플링·재시작 시 어긋나는 지점을 찾는다.")
def cvd_consistency(df, dataset="-", cvd_1m="cvd_1m", cvd_cum="cvd_cum",
                    key="symbol", reset_daily=True, tol=1e-6) -> CheckResult:
    if cvd_1m not in df.columns or cvd_cum not in df.columns:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP, message="누적/봉단위 CVD 컬럼 없음")
    bad, total, samples = 0, 0, []
    grouper = ([(None, df)] if key not in df.columns
               else list(df.groupby(key, observed=True)))
    for sym, g in grouper:
        g = g.sort_values("ts") if "ts" in g.columns else g
        if reset_daily and "ts" in g.columns:
            day = pd.to_datetime(g["ts"], utc=True).dt.normalize()
            expect = g[cvd_1m].astype("float64").groupby(day).cumsum()
        else:
            expect = g[cvd_1m].astype("float64").cumsum()
        d = (expect - g[cvd_cum].astype("float64")).abs()
        scale = np.maximum(g[cvd_cum].abs().to_numpy(dtype="float64"), 1.0)
        m = d.to_numpy() > tol * scale
        total += len(g)
        bad += int(m.sum())
        if m.any() and len(samples) < 5:
            i = int(np.argmax(m))
            samples.append({"symbol": str(sym),
                            "ts": str(g.iloc[i]["ts"]) if "ts" in g else i,
                            "누적합": float(expect.iloc[i]), "저장값": float(g.iloc[i][cvd_cum])})
    ratio = bad / max(total, 1)
    st = judge(ratio, 0.0, 0.001)
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=ratio, threshold="누적합 불일치 0건",
                       n_bad=bad, n_total=total, sample=samples,
                       message=f"누적 CVD 불일치 {bad}/{total}건 (일별 리셋={reset_daily})")


# ------------------------------------------------------------ Hurst

@check("MATH.HURST_BOUND", layer=Layer.FEATURE, cadence=Cadence.INTRADAY, gating=True,
       desc="Hurst 값의 유한성·범위·분모0 진단. 이론값은 (0,1)이지만 추정량은 그 밖으로 나갈 수 있다.")
def hurst_bound(df, dataset="-", col="hurst", price="close", window=None,
                lo=0.0, hi=1.0, warn_ratio=0.01, fail_ratio=0.05,
                soft_lo=-0.1, soft_hi=1.1) -> CheckResult:
    """중요한 구분 — 이 체크를 두 단계로 나눈 이유.

    · **이론값** H 는 정의상 (0, 1) 구간의 파라미터다.
    · **추정량** (R/S, DFA 등)은 유한 표본에서 이 구간을 벗어날 수 있다.
      특히 짧은 윈도우에 강한 추세가 있으면 R/S 추정치가 1을 넘는 일이 정상적으로 생긴다.
      "1.05가 찍혔으니 무조건 버그"라고 잘라 말하면 오탐이 계속 나고, 알림이 무시된다.

    그래서:
      NaN / inf                    → 즉시 FAIL (분모 0, 상수 구간, log(0) 등 계산 사고)
      [soft_lo, soft_hi] 밖        → FAIL (추정량으로도 설명 안 되는 값 = 확실한 버그)
      (lo, hi) 밖이지만 soft 안    → WARN (윈도우/추세 효과 가능성, 원인 표시)

    그리고 진짜 원인인 **'윈도우 내 가격 변동이 0'** 을 직접 진단한다.
    이게 분모를 0으로 만드는 실제 범인이다.
    """
    if col not in df.columns:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP, message=f"'{col}' 컬럼 없음")
    h = df[col].to_numpy(dtype="float64", na_value=np.nan)
    nonfinite = ~np.isfinite(h)
    # 롤링 워밍업(선두 연속 NaN)은 정상이다. 내부에 뚫린 NaN만 사고로 센다.
    warmup = 0
    if nonfinite.size and nonfinite[0]:
        warmup = int(np.argmax(~nonfinite)) if (~nonfinite).any() else len(nonfinite)
        nonfinite = nonfinite.copy()
        nonfinite[:warmup] = False
    hard = (~nonfinite) & ((h < soft_lo) | (h > soft_hi))
    soft = (~nonfinite) & ~hard & ((h < lo) | (h > hi))

    # 분모 0 진단: 해당 윈도우에서 가격이 전혀 안 움직였는가?
    flat_hits = 0
    if window and price in df.columns:
        p = df[price].astype("float64")
        rng = p.rolling(window).max() - p.rolling(window).min()
        flat = (rng == 0) & rng.notna()
        flat_hits = int((flat.to_numpy() & (nonfinite | hard | soft)).sum())

    n_bad = int(nonfinite.sum() + hard.sum())
    ratio = (n_bad + int(soft.sum())) / max(len(df), 1)
    st = Status.PASS
    if nonfinite.any() or hard.any():
        st = Status.FAIL
    elif soft.any():
        st = judge(float(soft.mean()), warn_ratio, fail_ratio)

    diag = []
    if nonfinite.any():
        diag.append(f"내부 NaN/inf {int(nonfinite.sum())}건")
    if hard.any():
        diag.append(f"범위 이탈(하드) {int(hard.sum())}건")
    if soft.any():
        diag.append(f"(0,1) 밖이나 추정오차 범위 {int(soft.sum())}건")
    if flat_hits:
        diag.append(f"※ 그중 {flat_hits}건은 윈도우 내 가격변동 0 → 분모 0이 원인")

    return CheckResult(
        check_id="", layer="", cadence="", dataset=dataset, status=st,
        metric=ratio,
        threshold=(f"NaN/inf 0건, [{soft_lo},{soft_hi}] 이탈 0건, "
                   f"({lo},{hi}) 이탈률 warn>{warn_ratio:.0%}"),
        n_bad=n_bad + int(soft.sum()), n_total=len(df),
        sample=[{"min": float(np.nanmin(h)) if np.isfinite(h).any() else None,
                 "max": float(np.nanmax(h)) if np.isfinite(h).any() else None,
                 "warmup_rows": warmup, "flat_window_hits": flat_hits}],
        message=("Hurst 정상" if not diag else " · ".join(diag)),
    )


@check("MATH.FLAT_WINDOW", layer=Layer.FEATURE, cadence=Cadence.INTRADAY, gating=False,
       desc="롤링 윈도우 내 가격 변동이 0인 구간 비율. 분모0 계열 피처(Hurst·변동성비·RSI) 사고의 공통 뿌리.")
def flat_window_ratio(df, dataset="-", price="close", key="symbol", window=64,
                      warn_ratio=0.01, fail_ratio=0.05) -> CheckResult:
    """비유: 저울에 아무것도 안 올려놓고 '무게 비율'을 구하는 상황.
    가격이 안 움직인 구간은 그 자체로 잘못이 아니지만,
    거기서 나눗셈을 하는 피처는 전부 폭발한다. 원인을 한 곳에서 보고 있으면 진단이 빨라진다.
    """
    if price not in df.columns:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP, message=f"'{price}' 컬럼 없음")
    flat, total = 0, 0
    grouper = ([(None, df)] if key not in df.columns
               else list(df.groupby(key, observed=True)))
    for _, g in grouper:
        p = g[price].astype("float64")
        rng = p.rolling(window).max() - p.rolling(window).min()
        v = rng.dropna()
        total += len(v)
        flat += int((v == 0).sum())
    ratio = flat / max(total, 1)
    st = judge(ratio, warn_ratio, fail_ratio)
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=ratio, threshold=f"평탄 구간 비율 warn>{warn_ratio:.0%}, fail>{fail_ratio:.0%}",
                       n_bad=flat, n_total=total,
                       message=(f"윈도우({window}) 내 가격변동 0 구간 {flat}/{total} ({ratio:.2%}) "
                                f"→ 분모 보호(epsilon) 또는 해당 구간 피처 NaN 처리 필요"))


# ------------------------------------------------------------ 정규화

@check("MATH.NORM_BOUND", layer=Layer.SERVING, cadence=Cadence.INTRADAY, gating=True,
       desc="정규화 피처가 학습 시 가정한 범위를 벗어나는 비율 + 클리핑 포화율. 극단장에서 모델 입력이 붕괴하는 걸 막는다.")
def normalization_bound(df, dataset="-", cols=None, lo=-1.0, hi=1.0,
                        hard_lo=None, hard_hi=None,
                        warn_ratio=0.005, fail_ratio=0.02,
                        saturation_warn=0.02, saturation_fail=0.10) -> CheckResult:
    """두 가지를 동시에 본다.

      ① 범위 이탈률  — 서킷브레이커 같은 극단장에서 Z-score가 학습 범위를 벗어난 비율
      ② 클리핑 포화율 — 경계값(±1)에 딱 붙은 값의 비율

    ②가 왜 중요한가: 클리핑을 걸어두면 ①은 영원히 0이 된다.
    문제가 사라진 게 아니라 **보이지 않게 된 것**이다.
    경계에 5%가 눌려 있다면 그 구간에서 모델은 사실상 눈을 감고 있다.

    비유: 최고 눈금 100kg짜리 저울. 120kg인 사람이 올라가도 100으로 찍힌다.
    저울은 고장 나지 않았지만, 그 측정값으로는 아무 판단도 할 수 없다.
    """
    cols = cols or [c for c in df.columns
                    if pd.api.types.is_numeric_dtype(df[c]) and c.endswith(("_z", "_norm"))]
    if not cols:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP, message="정규화 대상 컬럼 미지정")
    hard_lo = lo * 3 if hard_lo is None else hard_lo
    hard_hi = hi * 3 if hard_hi is None else hard_hi

    rows, worst_out, worst_sat, st = [], 0.0, 0.0, Status.PASS
    for c in cols:
        v = df[c].to_numpy(dtype="float64", na_value=np.nan)
        fin = np.isfinite(v)
        n = max(int(fin.sum()), 1)
        out = float(((v < lo) | (v > hi))[fin].sum() / n)
        hard = int((((v < hard_lo) | (v > hard_hi))[fin]).sum())
        sat = float((np.isclose(v[fin], lo) | np.isclose(v[fin], hi)).sum() / n)
        worst_out = max(worst_out, out)
        worst_sat = max(worst_sat, sat)

        s = judge(out, warn_ratio, fail_ratio)
        s_sat = judge(sat, saturation_warn, saturation_fail)
        if hard:
            s = Status.FAIL
        for cand in (s, s_sat):
            if cand == Status.FAIL:
                st = Status.FAIL
            elif cand == Status.WARN and st == Status.PASS:
                st = Status.WARN
        if s != Status.PASS or s_sat != Status.PASS:
            rows.append({"feature": c, "이탈률": round(out, 5), "포화율": round(sat, 5),
                         "하드이탈": hard,
                         "min": round(float(np.nanmin(v)), 3) if fin.any() else None,
                         "max": round(float(np.nanmax(v)), 3) if fin.any() else None})

    return CheckResult(
        check_id="", layer="", cadence="", dataset=dataset, status=st,
        metric=max(worst_out, worst_sat),
        threshold=(f"[{lo},{hi}] 이탈률 warn>{warn_ratio:.1%}, fail>{fail_ratio:.1%} / "
                   f"포화율 warn>{saturation_warn:.0%}, fail>{saturation_fail:.0%} / "
                   f"[{hard_lo},{hard_hi}] 이탈 0건"),
        n_bad=len(rows), n_total=len(cols), sample=rows[:5],
        message=(f"최대 범위이탈 {worst_out:.2%}, 최대 클리핑 포화 {worst_sat:.2%}, "
                 f"문제 피처 {len(rows)}/{len(cols)}개"),
    )


@check("MATH.SCALER_PARAMS", layer=Layer.SERVING, cadence=Cadence.WEEKLY, gating=True,
       desc="서빙에 쓰는 스케일러 파라미터(mean/std)가 학습 시점 값과 동일한지. 재적합되면 조용한 룩어헤드가 된다.")
def scaler_params(current, dataset="-", trained=None, rtol=1e-9) -> CheckResult:
    """현재 서빙 중인 스케일러의 mean/std 딕셔너리를 학습 때 저장한 값과 비교한다.

    스케일러를 매일 전체 데이터로 다시 fit 하면, 오늘의 평균이 어제 데이터를 정규화하는 데 쓰인다.
    백테스트에서는 이게 미래 정보 누수이고, 실전에서는 train/serve skew 다.
    스케일러는 **학습 시점에 고정하고 파일로 저장**하는 게 맞다.
    """
    if trained is None:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.SKIP, message="학습 시 스케일러 파라미터 미제공")
    diffs = []
    for k, v in (trained or {}).items():
        cur = (current or {}).get(k)
        if cur is None:
            diffs.append({"param": k, "issue": "서빙 측에 없음"})
            continue
        if not np.isclose(float(cur), float(v), rtol=rtol, equal_nan=True):
            diffs.append({"param": k, "학습": float(v), "서빙": float(cur)})
    st = Status.FAIL if diffs else Status.PASS
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=float(len(diffs)), threshold="학습 시점 파라미터와 완전 일치",
                       n_bad=len(diffs), n_total=len(trained or {}), sample=diffs[:5],
                       message=(f"스케일러 파라미터 불일치 {len(diffs)}개 "
                                f"→ 서빙 중 재적합(refit) 여부 확인" if diffs
                                else "스케일러 파라미터 일치 (학습 시점 고정 확인)"))
