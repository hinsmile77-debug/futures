"""
L3 CONTRACT — 피처 계약서에서 자동 생성되는 범용 점검.

여기 있는 체크들은 특정 피처를 모른다. 계약서만 읽는다.
그래서 피처가 CVD든 Hurst든 새로 만든 임베딩이든 코드 변경 없이 점검된다.

비유: 계량기 검정 절차.
  검정관은 '이 저울이 쌀을 재는지 금을 재는지' 알 필요가 없다.
  표시된 최대 용량, 눈금 간격, 영점만 확인하면 된다.
  피처 점검도 같은 수준으로 표준화될 수 있다.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from ..core import CheckResult, Cadence, Layer, Status, check, judge
from ..contract import FeatureContract, active_mask, eval_expr

CONTRACTS: dict[str, FeatureContract] = {}      # 런타임에 주입 (register_contracts)


def register_contracts(contracts: dict[str, FeatureContract]) -> None:
    CONTRACTS.clear()
    CONTRACTS.update(contracts)


def _c(name: str) -> FeatureContract | None:
    return CONTRACTS.get(name)


def _skip(dataset, msg) -> CheckResult:
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                       status=Status.SKIP, message=msg)


# ------------------------------------------------------------ ① 치역

@check("CONTRACT.RANGE", layer=Layer.FEATURE, cadence=Cadence.INTRADAY, gating=True,
       desc="계약서의 치역 준수. 이론 경계(soft)와 절대 경계(hard)를 분리해 오탐을 줄인다.")
def contract_range(df, dataset="-", contract=None) -> CheckResult:
    c = _c(contract or dataset)
    if c is None:
        return _skip(dataset, f"계약서 없음: {contract or dataset}")
    if c.name not in df.columns:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.FAIL, threshold="컬럼 존재",
                           message=f"계약된 피처 '{c.name}' 가 데이터에 없음 — 파이프라인 누락")

    v = df[c.name].to_numpy(dtype="float64", na_value=np.nan)
    m = active_mask(df, c) & np.isfinite(v)
    x = v[m]
    n = max(len(x), 1)

    hard_lo = c.soft_lo if c.soft_lo is not None else c.lo
    hard_hi = c.soft_hi if c.soft_hi is not None else c.hi
    hard = np.zeros(len(x), dtype=bool)
    if hard_lo is not None:
        hard |= x < hard_lo
    if hard_hi is not None:
        hard |= x > hard_hi

    soft = np.zeros(len(x), dtype=bool)
    if c.lo is not None:
        soft |= x < c.lo
    if c.hi is not None:
        soft |= x > c.hi
    soft &= ~hard

    hard_ratio, soft_ratio = int(hard.sum()) / n, int(soft.sum()) / n
    st = judge(hard_ratio, c.range_fail_ratio, c.range_fail_ratio)
    if st == Status.PASS and soft.any():
        st = judge(soft_ratio, c.soft_warn_ratio, c.soft_warn_ratio * 5)

    msg = f"[{c.lo},{c.hi}] 기준 · 절대이탈 {int(hard.sum())}건"
    if c.soft_lo is not None or c.soft_hi is not None:
        msg += f", 이론경계 밖(추정오차 허용) {int(soft.sum())}건"
    if len(x):
        msg += f" · 실측 [{x.min():.4g}, {x.max():.4g}]"
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=max(hard_ratio, soft_ratio),
                       threshold=(f"절대 [{hard_lo},{hard_hi}] 이탈 {c.range_fail_ratio:.1%} 이하, "
                                  f"이론 [{c.lo},{c.hi}] 이탈 warn>{c.soft_warn_ratio:.0%}"),
                       n_bad=int(hard.sum() + soft.sum()), n_total=n,
                       sample=[{"warmup_제외행": c.effective_warmup}],
                       message=msg)


# ------------------------------------------------------------ ② 불변식

@check("CONTRACT.INVARIANT", layer=Layer.FEATURE, cadence=Cadence.INTRADAY, gating=True,
       desc="계약서의 항등식·부등식. 피처 무결성 검증 중 가장 강력한 축.")
def contract_invariant(df, dataset="-", contract=None) -> CheckResult:
    c = _c(contract or dataset)
    if c is None or not c.invariants:
        return _skip(dataset, "불변식 미선언")
    m = active_mask(df, c)
    per, bad_total, samples = {}, 0, []
    for expr in c.invariants:
        try:
            ok = eval_expr(expr, df)
        except Exception as e:                       # noqa: BLE001
            per[expr] = "식 평가 실패"
            samples.append({"expr": expr, "error": f"{type(e).__name__}: {e}"})
            bad_total += len(df)
            continue
        ok_np = np.asarray(ok, dtype="object")
        viol = np.zeros(len(df), dtype=bool)
        fin = np.array([isinstance(x, (bool, np.bool_)) for x in ok_np])
        viol[fin] = ~np.asarray(ok_np[fin], dtype=bool)
        viol[~fin] = True                            # 판정 불가(NaN 비교 등)도 위반
        viol &= m
        per[expr] = int(viol.sum())
        bad_total += int(viol.sum())
        if viol.any() and len(samples) < 5:
            cols = [x for x in ("ts", "symbol", c.name) if x in df.columns]
            samples += df.loc[viol, cols].head(2).astype(str).to_dict("records")

    ratio = bad_total / max(int(m.sum()) * max(len(c.invariants), 1), 1)
    st = Status.FAIL if bad_total else Status.PASS
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset, status=st,
                       metric=ratio, threshold="불변식 위반 0건 (항등식이므로 예외 없음)",
                       n_bad=bad_total, n_total=int(m.sum()),
                       sample=[per] + samples,
                       message=(f"불변식 {len(c.invariants)}개 중 위반 "
                                f"{sum(1 for v in per.values() if v)}개 / 위반 행 {bad_total}건"))


# ------------------------------------------------------------ ③ 정의구간

@check("CONTRACT.SUPPORT", layer=Layer.FEATURE, cadence=Cadence.INTRADAY, gating=True,
       desc="분모 0·표본 부족 등 계산이 성립하지 않는 구간. NaN의 '원인'을 짚어준다.")
def contract_support(df, dataset="-", contract=None,
                     warn_ratio=0.01, fail_ratio=0.05) -> CheckResult:
    c = _c(contract or dataset)
    if c is None or not c.denominator:
        return _skip(dataset, "정의구간(분모) 미선언")
    try:
        den = eval_expr(c.denominator, df).astype("float64")
    except Exception as e:                           # noqa: BLE001
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.ERROR,
                           message=f"분모식 평가 실패: {type(e).__name__}: {e}")
    m = active_mask(df, c)
    degenerate = (den.abs() <= c.denom_eps).to_numpy() & m
    feat = (df[c.name].to_numpy(dtype="float64", na_value=np.nan)
            if c.name in df.columns else np.full(len(df), np.nan))
    broken = (~np.isfinite(feat)) & m
    # '분모가 0이라서 NaN이 된' 교집합 — 진짜 원인
    caused = degenerate & broken
    orphan = broken & ~degenerate                    # 원인 불명 NaN (더 위험)

    ratio = float(broken.sum()) / max(int(m.sum()), 1)
    st = judge(ratio, warn_ratio, fail_ratio)
    if orphan.any() and st == Status.PASS:
        st = Status.WARN
    return CheckResult(
        check_id="", layer="", cadence="", dataset=dataset, status=st,
        metric=ratio,
        threshold=f"NaN 비율 warn>{warn_ratio:.0%}, fail>{fail_ratio:.0%} (워밍업 제외)",
        n_bad=int(broken.sum()), n_total=int(m.sum()),
        sample=[{"분모식": c.denominator, "분모≈0 구간": int(degenerate.sum()),
                 "분모0이_원인인_NaN": int(caused.sum()),
                 "원인불명_NaN": int(orphan.sum())}],
        message=(f"NaN {int(broken.sum())}건 (분모≈0이 원인 {int(caused.sum())}건, "
                 f"원인불명 {int(orphan.sum())}건) · 분모식 `{c.denominator}`"),
    )


# ------------------------------------------------------------ ⑤ 앵커

@check("CONTRACT.ANCHOR", layer=Layer.FEATURE, cadence=Cadence.INTRADAY, gating=True,
       desc="외부 정답지 대조. '말이 되는지'가 아니라 '맞는지'를 본다 — 가능하면 항상 이 축을 채울 것.")
def contract_anchor(df, dataset="-", contract=None) -> CheckResult:
    c = _c(contract or dataset)
    if c is None or not c.anchor:
        return _skip(dataset, "앵커 미선언")
    if c.name not in df.columns:
        return _skip(dataset, f"'{c.name}' 컬럼 없음")
    try:
        anc = eval_expr(c.anchor, df).astype("float64")
    except Exception as e:                           # noqa: BLE001
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.ERROR,
                           message=f"앵커식 평가 실패: {type(e).__name__}: {e}")
    mine = df[c.name].astype("float64")
    scale = (eval_expr(c.anchor_scale, df).astype("float64").abs()
             if c.anchor_scale else anc.abs())

    if c.anchor_diff:
        # 누적끼리 비교하면 오차가 누적값으로 희석돼 후반부에 둔감해진다.
        a, b, s = mine.diff(), anc.diff(), scale.diff().abs()
        a, b, s = a.iloc[1:], b.iloc[1:], s.iloc[1:]
    else:
        a, b, s = mine, anc, scale
    rel = (a - b).abs() / s.clip(lower=1.0)
    rel = rel.replace([np.inf, -np.inf], np.nan).dropna()
    worst = float(rel.max()) if len(rel) else 0.0
    st = judge(worst, c.anchor_warn, c.anchor_fail)
    bad = rel > c.anchor_warn
    idx = rel[bad].nlargest(5).index
    cols = [x for x in ("ts", "symbol") if x in df.columns]
    return CheckResult(
        check_id="", layer="", cadence="", dataset=dataset, status=st,
        metric=worst,
        threshold=(f"{'증분' if c.anchor_diff else '수준'} 상대괴리 "
                   f"warn>{c.anchor_warn:.2%}, fail>{c.anchor_fail:.2%}"),
        n_bad=int(bad.sum()), n_total=int(len(rel)),
        sample=(df.loc[idx, cols].assign(자체=mine[idx].round(2), 앵커=anc[idx].round(2),
                                         괴리율=rel[idx].round(4))
                .astype(str).to_dict("records") if bad.any() else
                [{"앵커식": c.anchor}]),
        message=(f"앵커 `{c.anchor}` 대비 최대 괴리 {worst:.2%}, "
                 f"이탈 {int(bad.sum())}/{len(rel)}건"),
    )


# ------------------------------------------------------------ ⑥ 위생

@check("CONTRACT.HYGIENE", layer=Layer.FEATURE, cadence=Cadence.EOD, gating=True,
       desc="결측률·inf·상수화·워밍업 길이. 모든 피처에 무조건 적용되는 기본 검진.")
def contract_hygiene(df, dataset="-", contract=None) -> CheckResult:
    c = _c(contract or dataset)
    if c is None:
        return _skip(dataset, f"계약서 없음: {contract or dataset}")
    if c.name not in df.columns:
        return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                           status=Status.FAIL, threshold="컬럼 존재",
                           message=f"계약된 피처 '{c.name}' 가 데이터에 없음")
    v = df[c.name].to_numpy(dtype="float64", na_value=np.nan)
    m = active_mask(df, c)
    n = max(int(m.sum()), 1)
    nan = int((~np.isfinite(v) & m).sum())
    inf = int((np.isinf(v) & m).sum())
    x = v[m & np.isfinite(v)]
    uniq = int(len(np.unique(x)))
    null_ratio = nan / n

    st = judge(null_ratio, c.null_warn, c.null_fail)
    issues = []
    if inf:
        st = Status.FAIL
        issues.append(f"inf {inf}건")
    if uniq < c.min_unique:
        st = Status.FAIL
        issues.append(f"고유값 {uniq}개(상수화)")
    # 워밍업이 선언값보다 길면 계약서가 틀린 것 — 조용한 결측이 숨는다
    lead = int(np.argmax(np.isfinite(v))) if np.isfinite(v).any() else len(v)
    if lead > c.effective_warmup:
        # 계약서가 틀렸다는 뜻이고, 틀린 계약서는 조용한 결측을 숨긴다.
        # 값 자체가 임계 안이어도 무조건 실패로 올린다 — 계약이 먼저 맞아야 한다.
        st = Status.FAIL
        issues.append(f"실제 워밍업 {lead}행 > 선언 {c.effective_warmup}행 (계약서 수정 필요)")

    return CheckResult(
        check_id="", layer="", cadence="", dataset=dataset, status=st,
        metric=null_ratio,
        threshold=(f"결측률 warn>{c.null_warn:.1%}, fail>{c.null_fail:.1%} / "
                   f"inf 0건 / 고유값≥{c.min_unique} / 워밍업≤{c.effective_warmup}행"),
        n_bad=nan + inf, n_total=n,
        sample=[{"결측": nan, "inf": inf, "고유값": uniq, "선두NaN": lead,
                 "선언워밍업": c.effective_warmup}],
        message=(f"결측률 {null_ratio:.2%} (워밍업 {c.effective_warmup}행 제외)"
                 + (" · " + ", ".join(issues) if issues else "")),
    )


# ------------------------------------------------------------ 계약 커버리지

@check("CONTRACT.COVERAGE", layer=Layer.FEATURE, cadence=Cadence.EOD, gating=True,
       desc="계약서가 없는 피처를 찾아낸다. 한 개라도 있으면 경고 — 점검되지 않는 피처가 가장 위험하다.")
def contract_coverage(df, dataset="-", exclude=(), warn=0, fail=2) -> CheckResult:
    from ..contract import coverage_report
    rep = coverage_report(CONTRACTS, df.columns)
    undeclared = [c for c in rep["undeclared"] if c not in set(exclude)]
    st = judge(float(len(undeclared)), float(warn), float(fail))
    weak = [{"feature": k, "채워진_축": v} for k, v in rep["weakest"] if v < 4]
    if weak and st == Status.PASS:
        st = Status.WARN
    return CheckResult(
        check_id="", layer="", cadence="", dataset=dataset, status=st,
        metric=float(len(undeclared)),
        threshold=f"미선언 피처 warn>{warn}개, fail>{fail}개 / 축 4개 이상 선언 권장",
        n_bad=len(undeclared), n_total=rep["declared"] + len(undeclared),
        sample=[{"미선언_피처": undeclared[:15], "축이_빈약한_계약": weak}],
        message=(f"계약 {rep['declared']}개 · 미선언 피처 {len(undeclared)}개"
                 + (f" {undeclared[:5]}" if undeclared else "")
                 + (f" · 축 빈약 {len(weak)}개" if weak else "")),
    )
