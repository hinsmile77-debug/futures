"""
qdq.core — 데이터 무결성 점검의 뼈대(공통 규격).

비유: 공항 보안검색대.
  - Check      = 검색 게이트 1개 (금속탐지기, X-ray, 액체검사...)
  - CheckResult= 게이트가 찍어주는 판정 스탬프 (통과/경고/차단)
  - Registry   = 게이트 배치도 (어떤 게이트를 어떤 주기로 돌릴지)
  - Gate       = 최종 탑승 허가. 하나라도 FAIL이면 모델(비행기)에 못 태운다.
"""
from __future__ import annotations

import functools
import traceback
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Callable, Iterable

# ---------------------------------------------------------------- 상수 정의

class Status:
    PASS = "PASS"
    WARN = "WARN"
    FAIL = "FAIL"
    SKIP = "SKIP"
    ERROR = "ERROR"          # 체크 자체가 터진 경우 (= 검색대 고장, FAIL과 동급 취급)


SEVERITY_ORDER = {Status.PASS: 0, Status.SKIP: 0, Status.WARN: 1,
                  Status.FAIL: 2, Status.ERROR: 2}


class Layer:
    """데이터가 흘러가는 파이프라인 단계. 앞단에서 막을수록 싸게 막는다."""
    FEED = "L0_FEED"          # 소켓/REST 수집 계층 (하트비트, 시퀀스, 지연)
    RAW = "L1_RAW"            # 원본 저장 계층 (스키마, 중복, 타임스탬프)
    CURATED = "L2_CURATED"    # 정제 계층 (분봉/호가/옵션 도메인 규칙)
    FEATURE = "L3_FEATURE"    # 피처 계층 (결측, 드리프트, 룩어헤드)
    SERVING = "L4_SERVING"    # 모델 입력 계층 (train/serve skew, 게이팅)


class Cadence:
    """점검 주기."""
    REALTIME = "realtime"     # 10초~1분, 스트리밍 감시
    INTRADAY = "intraday"     # 5분, 장중 배치
    EOD = "eod"               # 장 마감 후 1일 1회
    WEEKLY = "weekly"
    MONTHLY = "monthly"


# ---------------------------------------------------------------- 결과 객체

@dataclass
class CheckResult:
    check_id: str
    layer: str
    cadence: str
    dataset: str
    status: str
    message: str
    metric: float | None = None
    threshold: str = ""
    n_bad: int = 0
    n_total: int = 0
    sample: list = field(default_factory=list)   # 위반 사례 샘플 (최대 5건)
    ts: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    gating: bool = False      # True면 FAIL 시 모델 입력을 차단해야 하는 항목

    @property
    def bad_ratio(self) -> float:
        return (self.n_bad / self.n_total) if self.n_total else 0.0

    def to_dict(self) -> dict:
        d = asdict(self)
        d["bad_ratio"] = round(self.bad_ratio, 6)
        return d

    def __str__(self) -> str:
        m = f" metric={self.metric:.6g}" if self.metric is not None else ""
        return f"[{self.status}] {self.check_id} ({self.dataset}){m} :: {self.message}"


# ---------------------------------------------------------------- 레지스트리

REGISTRY: dict[str, dict[str, Any]] = {}


def check(check_id: str, *, layer: str, cadence: str,
          gating: bool = False, desc: str = ""):
    """점검 함수를 레지스트리에 등록하는 데코레이터.

    등록된 함수 시그니처: fn(data, dataset: str, **params) -> CheckResult
    예외가 나면 자동으로 ERROR 결과로 감싸준다 (점검이 파이프라인을 죽이면 안 되므로).
    """
    def deco(fn: Callable[..., CheckResult]):
        @functools.wraps(fn)
        def wrapper(data, dataset: str = "-", **params) -> CheckResult:
            try:
                res = fn(data, dataset=dataset, **params)
                res.check_id = check_id
                res.layer, res.cadence, res.gating = layer, cadence, gating
                return res
            except Exception as e:  # noqa: BLE001
                return CheckResult(
                    check_id=check_id, layer=layer, cadence=cadence,
                    dataset=dataset, status=Status.ERROR,
                    message=f"체크 실행 실패: {type(e).__name__}: {e}",
                    sample=[traceback.format_exc(limit=2)],
                    gating=gating,
                )
        REGISTRY[check_id] = {"fn": wrapper, "layer": layer, "cadence": cadence,
                              "gating": gating, "desc": desc or (fn.__doc__ or "").strip()}
        return wrapper
    return deco


def ok(dataset, msg, **kw) -> CheckResult:
    return CheckResult(check_id="", layer="", cadence="", dataset=dataset,
                       status=Status.PASS, message=msg, **kw)


def judge(metric: float, warn: float, fail: float, *, higher_is_worse: bool = True) -> str:
    """지표 하나를 WARN/FAIL 임계치와 비교해 상태로 바꾼다.

    임계치는 '초과(strict)' 기준이다. warn=0, fail=0 으로 두면
    '단 1건이라도 발생하면 FAIL' 이라는 무관용 규칙이 된다.
    """
    if higher_is_worse:
        if metric > fail:
            return Status.FAIL
        if metric > warn:
            return Status.WARN
    else:
        if metric < fail:
            return Status.FAIL
        if metric < warn:
            return Status.WARN
    return Status.PASS


def utc(x, default_now: bool = False):
    """tz 유무와 무관하게 UTC Timestamp로 정규화."""
    import pandas as pd
    if x is None:
        return pd.Timestamp.now(tz="UTC") if default_now else None
    t = pd.Timestamp(x)
    return t.tz_localize("UTC") if t.tzinfo is None else t.tz_convert("UTC")


def worst(results: Iterable[CheckResult]) -> str:
    s = Status.PASS
    for r in results:
        if SEVERITY_ORDER[r.status] > SEVERITY_ORDER[s]:
            s = r.status
    return s
