"""
qdq.dashboard — '3초 판독' 데이터 무결성 탭.

설계 원칙 (왜 이렇게 배치했는가):

  0.5초  탭 라벨의 상태 점(●)      — 다른 탭을 보고 있어도 이상을 안다
  1초    히어로 판정               — 매매 가능인가 차단인가, 그리고 왜
  2초    파이프라인 4칩            — 어느 단계에서 깨졌나 (수신/조립/대사/피처)
  3초    세션 타임라인             — 언제 깨졌나 (구멍이 눈에 보인다)
  그 이후 KPI 타일 → 상세 테이블   — 얼마나 깨졌나

비유: 비행기 조종석의 계기 배치.
  고도계를 제일 크게, 정중앙에 둔다. 나머지는 그 주변에 둔다.
  조종사는 평소 0.5초씩 훑고, 이상할 때만 시선을 내린다.
  대시보드도 같다 — '평소에 안 읽히는 정보'는 위쪽에 있으면 안 된다.

접근성: 상태는 색 단독으로 표현하지 않는다.
  색 + 아이콘(●▲■✖○) + 한글 라벨 삼중, 타임라인은 색 + 막대 높이 이중 부호화.
  색각 이상이나 흑백 출력에서도 판독된다.
"""
from __future__ import annotations

import html
import json
import os
from datetime import datetime, timezone

from .core import Status
from .runner import RECOVERY_PLAYBOOK

_ICON = {Status.PASS: "●", Status.WARN: "▲", Status.FAIL: "■",
         Status.ERROR: "✖", Status.SKIP: "○"}
_LABEL = {Status.PASS: "정상", Status.WARN: "경고", Status.FAIL: "실패",
          Status.ERROR: "오류", Status.SKIP: "대기"}
_VAR = {Status.PASS: "--good", Status.WARN: "--warning", Status.FAIL: "--critical",
        Status.ERROR: "--critical", Status.SKIP: "--neutral"}
_RANK = {Status.PASS: 0, Status.SKIP: 0, Status.WARN: 1, Status.FAIL: 2, Status.ERROR: 2}

# 파이프라인 4단계 ← 체크 ID 접두사 매핑
STAGES = [
    ("수신", "CREON·FEED", ("CREON.", "FEED.")),
    ("조립", "분봉·호가", ("BAR.", "BOOK.")),
    ("대사", "공식 TR 대조", ("RECON.",)),
    ("피처", "계약·수학·누수", ("FEAT.", "MATH.", "CONTRACT.", "OPT.", "FUT.", "MACRO.")),
]

_CSS = """
:root{color-scheme:light;--surface-0:#f6f5f2;--surface-1:#fcfcfb;--surface-2:#efeeea;
--border:#e3e2dd;--text-primary:#0b0b0b;--text-secondary:#52514e;--text-muted:#83817a;
--good:#0ca30c;--warning:#fab219;--serious:#ec835a;--critical:#d03b3b;--neutral:#a9a79e;}
@media(prefers-color-scheme:dark){:root{color-scheme:dark;--surface-0:#111110;
--surface-1:#1a1a19;--surface-2:#232321;--border:#33332f;--text-primary:#fff;
--text-secondary:#c3c2b7;--text-muted:#8f8e85;--neutral:#6f6e67;}}
*{box-sizing:border-box}
body{margin:0;background:var(--surface-0);color:var(--text-primary);
font:14px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI","Noto Sans KR",sans-serif}
.app{max-width:1180px;margin:0 auto;padding:20px 18px 48px}
.topbar{display:flex;align-items:baseline;justify-content:space-between;gap:12px;
flex-wrap:wrap;margin-bottom:14px}
.topbar h1{font-size:16px;margin:0;font-weight:650}
.topbar .meta{font-size:12px;color:var(--text-muted);font-variant-numeric:tabular-nums}

/* ---------- 탭 ---------- */
.tabs{display:flex;gap:2px;border-bottom:1px solid var(--border);margin-bottom:20px;
overflow-x:auto}
.tab{appearance:none;background:none;border:0;border-bottom:2px solid transparent;
padding:10px 16px;font:inherit;font-weight:600;color:var(--text-muted);cursor:pointer;
white-space:nowrap;display:flex;align-items:center;gap:7px}
.tab:hover{color:var(--text-secondary)}
.tab[aria-selected="true"]{color:var(--text-primary);border-bottom-color:var(--text-primary)}
.tab .dot{font-size:11px;line-height:1}
.panel{display:none}
.panel.active{display:block}

/* ---------- 히어로 판정 ---------- */
.hero{border:1px solid var(--border);border-radius:14px;background:var(--surface-1);
padding:22px 24px;margin-bottom:16px;display:flex;gap:20px;align-items:flex-start;
flex-wrap:wrap;position:relative;overflow:hidden}
.hero::before{content:"";position:absolute;left:0;top:0;bottom:0;width:6px;
background:var(--hero-color)}
.hero .mark{font-size:34px;line-height:1;color:var(--hero-color);margin-top:2px}
.hero .body{flex:1 1 320px;min-width:0}
.hero .verdict{font-size:30px;font-weight:700;letter-spacing:-.02em;line-height:1.15;
color:var(--hero-color)}
.hero .why{margin-top:6px;font-size:14px;color:var(--text-secondary)}
.hero .why b{color:var(--text-primary)}
.hero .stamp{font-size:12px;color:var(--text-muted);margin-top:8px;
font-variant-numeric:tabular-nums}
.hero .actions{flex:0 0 auto;font-size:12px;color:var(--text-secondary);
background:var(--surface-2);border-radius:10px;padding:12px 14px;max-width:340px}
.hero .actions b{display:block;color:var(--text-primary);margin-bottom:4px;font-size:12px}

/* ---------- 파이프라인 칩 ---------- */
.stages{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px;
margin-bottom:18px}
.stage{border:1px solid var(--border);border-radius:12px;background:var(--surface-1);
padding:12px 14px;position:relative}
.stage .top{display:flex;align-items:center;gap:7px;font-weight:650;font-size:14px}
.stage .top .ic{color:var(--st);font-size:13px}
.stage .sub{font-size:11px;color:var(--text-muted);margin-top:3px}
.stage .cnt{font-size:11px;color:var(--text-secondary);margin-top:7px;
font-variant-numeric:tabular-nums}
.stage .bar{height:3px;border-radius:2px;background:var(--st);margin-top:9px;opacity:.85}
.arrow{display:none}

/* ---------- 세션 타임라인 ---------- */
.card{border:1px solid var(--border);border-radius:12px;background:var(--surface-1);
padding:14px 16px;margin-bottom:16px}
.card h2{font-size:13px;margin:0 0 2px;font-weight:650}
.card .hint{font-size:11px;color:var(--text-muted);margin-bottom:12px}
.tl{display:flex;align-items:flex-end;gap:1px;height:46px;padding:0 1px}
.tl .cell{flex:1 1 0;min-width:1px;border-radius:1.5px;background:var(--c);
transition:opacity .1s}
.tl .cell:hover{opacity:.6;outline:1px solid var(--text-primary)}
.tl .cell.miss{background:transparent;border:1.5px dashed var(--critical);
height:100%!important;min-width:4px;flex-grow:2}
.tl .cell.hit{min-width:4px;flex-grow:2}
.tl-axis{display:flex;justify-content:space-between;font-size:10px;
color:var(--text-muted);margin-top:6px;font-variant-numeric:tabular-nums}
.tl-legend{display:flex;gap:14px;flex-wrap:wrap;font-size:11px;
color:var(--text-secondary);margin-top:10px}
.tl-legend span{display:inline-flex;align-items:center;gap:5px}
.tl-legend i{width:9px;border-radius:1.5px;display:inline-block}

/* ---------- KPI 타일 ---------- */
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(158px,1fr));gap:10px;
margin-bottom:16px}
.kpi{border:1px solid var(--border);border-radius:12px;background:var(--surface-1);
padding:12px 14px}
.kpi .k{font-size:11px;color:var(--text-muted);display:flex;align-items:center;gap:5px}
.kpi .k .ic{color:var(--st)}
.kpi .v{font-size:23px;font-weight:660;letter-spacing:-.02em;margin-top:3px;
font-variant-numeric:tabular-nums}
.kpi .t{font-size:11px;color:var(--text-muted);margin-top:2px;font-variant-numeric:tabular-nums}

/* ---------- 상세 ---------- */
details.more{border:1px solid var(--border);border-radius:12px;background:var(--surface-1);
padding:0 16px}
details.more>summary{cursor:pointer;padding:13px 0;font-size:13px;font-weight:650;
list-style:none;display:flex;align-items:center;gap:8px}
details.more>summary::-webkit-details-marker{display:none}
details.more>summary::before{content:"▸";color:var(--text-muted);font-size:11px}
details.more[open]>summary::before{content:"▾"}
table{width:100%;border-collapse:collapse;margin-bottom:14px}
th,td{text-align:left;padding:8px 10px;border-top:1px solid var(--border);
vertical-align:top;font-size:13px}
th{font-size:11px;color:var(--text-muted);font-weight:600;border-top:0}
td.mono,th.mono{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:11.5px;
white-space:nowrap}
.badge{display:inline-flex;align-items:center;gap:4px;font-size:11.5px;font-weight:650;
white-space:nowrap;color:var(--st)}
.fix{margin-top:5px;font-size:11.5px;color:var(--text-secondary);
border-left:3px solid var(--serious);padding-left:8px}
pre{margin:5px 0 0;padding:7px 9px;background:var(--surface-2);border-radius:6px;
font-size:10.5px;overflow-x:auto;color:var(--text-secondary)}
.ph{border:1px dashed var(--border);border-radius:12px;padding:40px;text-align:center;
color:var(--text-muted);font-size:13px}
"""

_JS = """
document.querySelectorAll('.tab').forEach(function(t){
  t.addEventListener('click', function(){
    document.querySelectorAll('.tab').forEach(function(x){x.setAttribute('aria-selected','false')});
    document.querySelectorAll('.panel').forEach(function(p){p.classList.remove('active')});
    t.setAttribute('aria-selected','true');
    document.getElementById(t.dataset.panel).classList.add('active');
  });
});
"""


# ------------------------------------------------------------ 집계 유틸

def stage_rollup(results) -> list[dict]:
    """체크 결과를 파이프라인 4단계로 접는다."""
    out = []
    for name, sub, prefixes in STAGES:
        hits = [r for r in results if r.check_id.startswith(prefixes)]
        st = Status.SKIP if not hits else max((r.status for r in hits), key=lambda s: _RANK[s])
        n_bad = sum(1 for r in hits if r.status in (Status.WARN, Status.FAIL, Status.ERROR))
        worst = next((r for r in sorted(hits, key=lambda r: -_RANK[r.status])
                      if r.status in (Status.FAIL, Status.ERROR, Status.WARN)), None)
        out.append({"name": name, "sub": sub, "status": st, "total": len(hits),
                    "bad": n_bad, "worst": worst})
    return out


def build_timeline(bars, official=None, ts="ts", warn_ts=None, tz="Asia/Seoul"):
    """분 단위 타임라인 셀을 만든다.

    각 셀 status: PASS(수신 정상) / WARN(경고 구간) / FAIL(미수신)
    official 을 주면 '공식엔 있는데 내겐 없는 봉'을 결측으로 표시한다.
    시각은 반드시 **현지(KST)** 로 보여준다 — 09:47에 난 사고가 00:47로 찍히면
    타임라인의 존재 이유가 사라진다.
    """
    import pandas as pd
    mine = set(pd.to_datetime(bars[ts], utc=True))
    ref = set(pd.to_datetime(official[ts], utc=True)) if official is not None else mine
    grid = sorted(ref | mine)
    warn = set(pd.to_datetime(pd.Series(list(warn_ts)), utc=True)) if warn_ts else set()
    cells = []
    for t in grid:
        if t not in mine:
            st = Status.FAIL
        elif t in warn:
            st = Status.WARN
        else:
            st = Status.PASS
        cells.append({"ts": t.tz_convert(tz), "status": st})
    return {"cells": cells, "tz": tz}


def problem_timestamps(results, checks=None) -> list:
    """체크 결과의 sample 에서 문제 발생 타임스탬프를 긁어모은다.

    타임라인의 경고 구간을 손으로 지정하면 실제 사고 시각과 어긋난다.
    점검 결과가 스스로 '언제였는지' 말하게 하는 편이 항상 맞다.
    """
    import pandas as pd
    checks = checks or ("CREON.CVD_ANCHOR", "CREON.TICK_CONTINUITY",
                        "CREON.ZERO_VALUE", "RECON.OHLC_DIFF", "MATH.CVD_BOUND")
    out = []
    for r in results:
        if r.check_id not in checks or r.status == Status.PASS:
            continue
        for item in (r.sample or []):
            if not isinstance(item, dict):
                continue
            for k, v in item.items():
                if "ts" in str(k).lower() or "시각" in str(k):
                    try:
                        out.append(pd.Timestamp(v))
                    except (ValueError, TypeError):
                        pass
    return out


# ------------------------------------------------------------ 렌더링

def _badge(st):
    return (f'<span class="badge" style="--st:var({_VAR[st]})">'
            f'{_ICON[st]} {_LABEL[st]}</span>')


def _hero(report) -> str:
    ok = report.gate_open
    blockers = report.blockers
    warns = [r for r in report.results if r.status == Status.WARN]
    if not ok:
        color, mark, verdict = "var(--critical)", "■", "매매 차단"
        # 심각도가 같으면 게이팅 차단 사유를 여러 건 보여준다.
        # 첫 줄 하나만 보여주면 '가장 시급한 것'을 놓친다.
        top = blockers[0]
        lines = [f"<b>{html.escape(b.check_id)}</b> — {html.escape(b.message[:96])}"
                 for b in blockers[:3]]
        why = "<br>".join(lines)
        if len(blockers) > 3:
            why += (f"<br><span style='color:var(--text-muted)'>"
                    f"외 {len(blockers) - 3}건</span>")
        fix = RECOVERY_PLAYBOOK.get(top.check_id, "담당자 확인 필요")
    elif warns:
        color, mark, verdict = "var(--warning)", "▲", "매매 가능 · 주의"
        why = (f"차단 사유는 없으나 경고 {len(warns)}건 — "
               f"<b>{html.escape(warns[0].check_id)}</b>: {html.escape(warns[0].message)}")
        fix = "24시간 내 원인 규명. 반복되면 임계치가 아니라 파이프라인을 고칠 것"
    else:
        color, mark, verdict = "var(--good)", "●", "매매 가능"
        why = f"게이팅 체크 전체 통과 · 점검 {len(report.results)}건"
        fix = "이상 없음. 다음 점검까지 대기"
    return f"""<div class="hero" style="--hero-color:{color}">
  <div class="mark">{mark}</div>
  <div class="body">
    <div class="verdict">{verdict}</div>
    <div class="why">{why}</div>
    <div class="stamp">최종 점검 {html.escape(report.started_at[:19].replace('T', ' '))} UTC
      · run {html.escape(report.run_id)} · 주기 {html.escape(report.cadence)}</div>
  </div>
  <div class="actions"><b>다음 조치</b>{html.escape(fix)}</div>
</div>"""


def _stages(results) -> str:
    cells = []
    for i, s in enumerate(stage_rollup(results)):
        detail = (html.escape(s["worst"].check_id) if s["worst"]
                  else f"{s['total']}개 점검 통과")
        cells.append(f"""<div class="stage" style="--st:var({_VAR[s['status']]})">
  <div class="top"><span class="ic">{_ICON[s['status']]}</span>{s['name']}
    <span style="font-weight:400;color:var(--text-muted);font-size:12px">
    {_LABEL[s['status']]}</span></div>
  <div class="sub">{html.escape(s['sub'])}</div>
  <div class="cnt">이상 {s['bad']} / 점검 {s['total']} · {detail}</div>
  <div class="bar"></div>
</div>""")
    return f'<div class="stages">{"".join(cells)}</div>'


def _timeline(tl) -> str:
    if not tl or not tl["cells"]:
        return ""
    heights = {Status.PASS: 100, Status.WARN: 52, Status.FAIL: 100, Status.SKIP: 22}
    parts = []
    for c in tl["cells"]:
        st = c["status"]
        t = str(c["ts"])[11:16]
        # 이상 셀은 최소 폭을 강제한다. 400칸 넘어가면 1px짜리 이상 구간은
        # 사실상 안 보이고, 그러면 '3초 판독'이 성립하지 않는다.
        cls = ("cell miss" if st == Status.FAIL
               else ("cell hit" if st != Status.PASS else "cell"))
        parts.append(f'<div class="{cls}" style="--c:var({_VAR[st]});'
                     f'height:{heights[st]}%" title="{t} · {_LABEL[st]}"></div>')
    n = len(tl["cells"])
    miss = sum(1 for c in tl["cells"] if c["status"] == Status.FAIL)
    warn = sum(1 for c in tl["cells"] if c["status"] == Status.WARN)
    first, last = str(tl["cells"][0]["ts"])[11:16], str(tl["cells"][-1]["ts"])[11:16]
    mid = str(tl["cells"][n // 2]["ts"])[11:16]
    tzname = {"Asia/Seoul": "KST"}.get(tl.get("tz", "Asia/Seoul"),
                                   tl.get("tz", "").split("/")[-1])
    return f"""<div class="card">
  <h2>세션 타임라인 · 1칸 = 1분봉 <span style="font-weight:400;
    color:var(--text-muted)">({tzname} 기준)</span></h2>
  <div class="hint">점선 빈칸 = 미수신 · 반높이 = 경고 · 꽉찬 막대 = 정상
    (색이 안 보여도 높이로 구분됩니다)</div>
  <div class="tl">{''.join(parts)}</div>
  <div class="tl-axis"><span>{first}</span><span>{mid}</span><span>{last}</span></div>
  <div class="tl-legend">
    <span><i style="background:var(--good);height:14px"></i>정상 {n - miss - warn}분</span>
    <span><i style="background:var(--warning);height:8px"></i>경고 {warn}분</span>
    <span><i style="border:1px dashed var(--critical);height:14px;width:9px"></i>미수신 {miss}분</span>
    <span style="color:var(--text-muted)">총 {n}분</span>
  </div>
</div>"""


def _kpis(kpis) -> str:
    if not kpis:
        return ""
    out = []
    for k in kpis:
        st = k.get("status", Status.SKIP)
        out.append(f"""<div class="kpi" style="--st:var({_VAR[st]})">
  <div class="k"><span class="ic">{_ICON[st]}</span>{html.escape(k['label'])}</div>
  <div class="v">{html.escape(str(k['value']))}</div>
  <div class="t">{html.escape(k.get('threshold', ''))}</div>
</div>""")
    return f'<div class="kpis">{"".join(out)}</div>'


def _detail_table(results) -> str:
    rows = []
    for r in sorted(results, key=lambda x: (-_RANK[x.status], x.check_id)):
        if r.status == Status.PASS:
            continue
        extra = ""
        if r.sample:
            extra = ("<details><summary style='cursor:pointer;color:var(--text-muted);"
                     "font-size:11px'>샘플</summary><pre>"
                     + html.escape(json.dumps(r.sample, ensure_ascii=False,
                                              indent=1, default=str)[:900])
                     + "</pre></details>")
        if r.status in (Status.FAIL, Status.ERROR) and r.check_id in RECOVERY_PLAYBOOK:
            extra += f'<div class="fix">{html.escape(RECOVERY_PLAYBOOK[r.check_id])}</div>'
        m = "-" if r.metric is None else f"{r.metric:.4g}"
        rows.append(f"<tr><td>{_badge(r.status)}{' 🔒' if r.gating else ''}</td>"
                    f'<td class="mono">{html.escape(r.check_id)}</td>'
                    f'<td class="mono">{m}</td>'
                    f"<td>{html.escape(r.message)}"
                    f"<div style='font-size:11px;color:var(--text-muted);margin-top:2px'>"
                    f"기준 {html.escape(r.threshold or '-')}</div>{extra}</td></tr>")
    if not rows:
        rows = ['<tr><td colspan="4" style="color:var(--text-muted)">'
                '경고·실패 항목 없음 (전체 통과)</td></tr>']
    c = {}
    for r in results:
        c[r.status] = c.get(r.status, 0) + 1
    summary = " · ".join(f"{_LABEL[s]} {c.get(s, 0)}"
                         for s in (Status.PASS, Status.WARN, Status.FAIL,
                                   Status.ERROR, Status.SKIP))
    return f"""<details class="more">
  <summary>점검 상세 · {summary}</summary>
  <table><thead><tr><th>상태</th><th class="mono">체크 ID</th>
    <th class="mono">지표</th><th>내용</th></tr></thead>
  <tbody>{''.join(rows)}</tbody></table>
</details>"""


def render_dashboard(report, path: str, *, timeline=None, kpis=None,
                     title="파생 자동매매 콘솔",
                     other_tabs=("포지션", "손익", "체결로그")) -> str:
    """무결성 탭을 포함한 대시보드 HTML을 생성한다.

    other_tabs 는 기존 대시보드 탭 자리를 표시하는 플레이스홀더다.
    실제 시스템에 이식할 때는 이 탭들의 내용만 바꿔 끼우면 된다.
    """
    st = report.status if report.gate_open else Status.FAIL
    tabs, panels = [], []
    for i, name in enumerate(other_tabs):
        tabs.append(f'<button class="tab" role="tab" aria-selected="false" '
                    f'data-panel="p{i}">{html.escape(name)}</button>')
        panels.append(f'<section class="panel" id="p{i}" role="tabpanel">'
                      f'<div class="ph">{html.escape(name)} 패널 — 기존 대시보드 내용이 들어갑니다</div>'
                      f'</section>')
    idx = len(other_tabs)
    tabs.append(f'<button class="tab" role="tab" aria-selected="true" data-panel="p{idx}">'
                f'<span class="dot" style="color:var({_VAR[st]})">{_ICON[st]}</span>'
                f'데이터 무결성</button>')
    panels.append(f"""<section class="panel active" id="p{idx}" role="tabpanel">
{_hero(report)}
{_stages(report.results)}
{_timeline(timeline)}
{_kpis(kpis)}
{_detail_table(report.results)}
</section>""")

    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    doc = f"""<!doctype html><html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{html.escape(title)} · 데이터 무결성</title><style>{_CSS}</style></head><body>
<div class="app">
  <div class="topbar"><h1>{html.escape(title)}</h1>
    <div class="meta">대신 CYBOS Plus / CREON Plus · 렌더 {now} UTC</div></div>
  <div class="tabs" role="tablist">{''.join(tabs)}</div>
  {''.join(panels)}
</div>
<script>{_JS}</script></body></html>"""
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(doc)
    return path
