"""
qdq.runner — 설정(YAML) 기반 점검 실행기 + 게이팅.

비유: 발전소 제어실.
  계기판(체크)들이 각자 값을 올려보내면, 제어실은 두 가지를 결정한다.
    1) 경보를 울릴 것인가 (WARN/FAIL 알림)
    2) 원자로를 멈출 것인가 (게이팅 = 모델 입력·주문 차단)
  가장 중요한 규칙: "모르면 멈춘다(fail-closed)".
  데이터 품질이 불확실한 상태로 주문을 내는 것보다, 그날 안 하는 게 싸다.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

import yaml

from .core import REGISTRY, CheckResult, Status, Cadence, worst
# 체크 모듈을 import 하는 것만으로 레지스트리에 등록된다
from .checks import (stream, bars, book, derivs, macro, features,  # noqa: F401
                     creon, recon, feature_math, contract_checks)  # noqa: F401


@dataclass
class DQReport:
    run_id: str
    cadence: str
    started_at: str
    results: list[CheckResult] = field(default_factory=list)

    @property
    def status(self) -> str:
        return worst(self.results)

    @property
    def gate_open(self) -> bool:
        """gating=True 인 체크가 하나라도 FAIL/ERROR면 게이트를 닫는다."""
        return not any(r.gating and r.status in (Status.FAIL, Status.ERROR)
                       for r in self.results)

    @property
    def blockers(self) -> list[CheckResult]:
        return [r for r in self.results
                if r.gating and r.status in (Status.FAIL, Status.ERROR)]

    def counts(self) -> dict[str, int]:
        c = {s: 0 for s in (Status.PASS, Status.WARN, Status.FAIL,
                            Status.ERROR, Status.SKIP)}
        for r in self.results:
            c[r.status] += 1
        return c

    def to_dict(self) -> dict:
        return {"run_id": self.run_id, "cadence": self.cadence,
                "started_at": self.started_at, "status": self.status,
                "gate_open": self.gate_open, "counts": self.counts(),
                "results": [r.to_dict() for r in self.results]}

    def save_json(self, path: str) -> str:
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, ensure_ascii=False, indent=2, default=str)
        return path

    def print_summary(self) -> None:
        c = self.counts()
        print(f"\n=== DQ REPORT [{self.cadence}] {self.run_id} ===")
        print(f"종합: {self.status} | 게이트: {'OPEN ✅' if self.gate_open else 'CLOSED ⛔'} | "
              f"PASS {c['PASS']} / WARN {c['WARN']} / FAIL {c['FAIL']} / "
              f"ERROR {c['ERROR']} / SKIP {c['SKIP']}")
        for r in self.results:
            if r.status != Status.PASS:
                print(f"  {r}")
        if self.blockers:
            print("  ⛔ 차단 사유:", ", ".join(b.check_id for b in self.blockers))


class DQRunner:
    """YAML 스위트를 읽어 해당 주기의 체크만 실행한다."""

    def __init__(self, config: dict | str):
        if isinstance(config, str):
            with open(config, encoding="utf-8") as f:
                config = yaml.safe_load(f)
        self.cfg = config
        self.defaults = config.get("defaults", {})

    def run(self, cadence: str, data: dict[str, Any],
            run_id: str | None = None) -> DQReport:
        run_id = run_id or datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        rep = DQReport(run_id=run_id, cadence=cadence,
                       started_at=datetime.now(timezone.utc).isoformat())
        for item in self.cfg.get("suite", []):
            cid = item["check"]
            meta = REGISTRY.get(cid)
            if meta is None:
                rep.results.append(CheckResult(
                    check_id=cid, layer="-", cadence=cadence, dataset=item.get("dataset", "-"),
                    status=Status.ERROR, message="레지스트리에 없는 체크 ID"))
                continue
            if meta["cadence"] != cadence and item.get("cadence") != cadence:
                continue
            key = item.get("data")
            if key not in data:
                rep.results.append(CheckResult(
                    check_id=cid, layer=meta["layer"], cadence=cadence,
                    dataset=item.get("dataset", "-"), status=Status.SKIP,
                    message=f"입력 데이터 '{key}' 미제공"))
                continue

            params = dict(self.defaults.get(cid, {}))
            params.update(item.get("params", {}) or {})
            # extra: 다른 데이터셋을 파라미터로 주입 (예: 대조용 2차 벤더)
            for pname, dkey in (item.get("extra_data", {}) or {}).items():
                params[pname] = data.get(dkey)
            rep.results.append(
                meta["fn"](data[key], dataset=item.get("dataset", key), **params))
        return rep


# ------------------------------------------------------------ 재시도/복구 정책

RECOVERY_PLAYBOOK = {
    "FEED.SEQ_GAP": "① 스냅샷 재요청 후 델타 재적용 ② 갭 구간 REST로 백필 ③ 백필 불가 시 해당 구간 피처 무효화",
    "FEED.HEARTBEAT": "① 소켓 재연결 ② 보조 피드로 전환(failover) ③ 정지 구간을 데이터 공백으로 명시 기록",
    "BAR.GRID_COMPLETE": "① 결측 봉을 REST 재조회로 백필 ② 여전히 없으면 NaN 유지(0/ffill 금지) ③ 해당 시각 피처 마스킹",
    "BAR.VENDOR_RECON": "① 차이 원인 분류(조정/정정/누락) ② 공식 시세를 진실원본으로 덮어쓰기 ③ 영향받은 파티션 재계산",
    "BOOK.CROSSED": "① 즉시 스냅샷 재동기화 ② 재동기화 전 구간 마이크로구조 피처 무효화",
    "OPT.PUT_CALL_PARITY": "① 현물·금리·배당 매칭 시각 확인 ② 이론가 대신 시장 mid 재수집 ③ 괴리 지속 시 해당 만기 제외",
    "MACRO.ASOF_JOIN": "① 조인 로직을 merge_asof(direction=backward)로 교정 ② 영향 구간 백테스트 전면 재실행",
    "FEAT.LOOKAHEAD": "⛔ 즉시 배포 중단. 해당 피처 제거 후 전체 백테스트 재검증 (성과 지표 신뢰 불가)",
    "FEAT.TRAIN_SERVE_SKEW": "① 오프라인/온라인 피처 코드 단일화 ② 골든 샘플로 회귀 테스트 추가",
    "FEAT.PSI_DRIFT": "① 벤더/파이프 변경 이력 확인 ② 진짜 시장 변화면 재학습, 데이터 사고면 롤백",
    # --- 대신 사이보스/크레온 환경 ---
    "CREON.CONNECT": "① CpCybos.IsConnect 재확인 ② 플러스 재로그인 ③ ServerType=2면 접속 주소를 '사이보스플러스' 전용으로 변경",
    "CREON.MEMORY": "① 장중이면 구독 종목 축소로 버티기 ② 장 마감 후 프로세스 재기동 ③ 이벤트 핸들러 내 객체 참조 누수 점검(COM 객체 해제)",
    "CREON.QUEUE_DEPTH": "① 이벤트 핸들러에서는 큐에 넣기만 하고 파싱은 워커로 ② 구독 종목 축소 ③ 큐 상한 도달 시 드롭 대신 백프레셔",
    "CREON.SUBSCRIBE_SLOTS": "① 400슬롯 내로 구독 종목 재설계(ATM±N 만기 1개 우선) ② 구독 성공 여부를 반드시 확인 후 등록부에 기록",
    "CREON.REQUEST_QUOTA": "① 15초/60건 페이싱 큐 적용 ② EOD 대사용 여유 20건 상시 확보 ③ 조회 실패 시 재시도 백오프",
    "CREON.TICK_CONTINUITY": "① 누적거래량 역행 시점 이후 재동기화 ② 비정상 증분 구간의 CVD 무효화 ③ 해당 구간 피처 마스킹",
    "CREON.CVD_ANCHOR": "① 체결구분(24) 분류 로직 점검 ② 누적체결매수/매도(23/22)로 CVD 재계산 후 덮어쓰기 ③ 괴리 구간 신호 차단",
    "RECON.BAR_COVERAGE": "① FutOptChart로 결측 봉 재조회 ② 공식 OHLCV로 복원(자체본은 _raw 보존) ③ 틱 기반 피처는 복원 불가 → 마스킹",
    "RECON.VOLUME_BIAS": "① 부호 편향이 한쪽이면 유실, 양방향이면 봉 경계 로직 ② 불일치 집중 시각에 재접속/큐적체 로그 대조",
    "RECON.OHLC_DIFF": "① 종가만 맞고 고저가 틀리면 봉내 틱 유실 ② 공식 데이터로 덮어쓰고 해당 구간 변동성 피처 무효화",
    "MATH.CVD_BOUND": "⛔ 체결 분류 로직 버그. Buy+Sell=Volume 항등식부터 복구할 것",
    "MATH.HURST_BOUND": "① NaN/inf면 분모 보호(epsilon) 추가 ② 평탄 구간이면 해당 윈도우 피처를 NaN 처리 ③ 윈도우 길이 재검토",
    "MATH.NORM_BOUND": "① 클리핑에 가려진 포화인지 확인 ② 극단장 구간이면 로버스트 스케일러(median/IQR) 검토 ③ 포화 구간 신호 축소",
    "MATH.SCALER_PARAMS": "⛔ 서빙 중 재적합 의심. 학습 시점 스케일러를 파일에서 로드하도록 고정하고 백테스트 재검증",
}
