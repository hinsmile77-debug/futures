"""
tests_checks.py — 각 점검 함수가 '정상은 통과시키고, 주입한 오류는 잡아내는지' 검증.

비유: 화재경보기 점검.
  경보기를 달아놓기만 하면 안 되고, 연기를 직접 피워서 울리는지 확인해야 한다.
  동시에 평소엔 안 울리는지(오탐)도 확인해야 한다. 둘 다 봐야 점검이다.

  python tests_checks.py
"""
from __future__ import annotations

import sys

import numpy as np
import pandas as pd

from qdq.core import REGISTRY, Status
from qdq.checks import (stream, bars, book, derivs, macro, features,  # noqa: F401
                        creon, recon, feature_math)  # noqa: F401

RNG = np.random.default_rng(7)
FAILED: list[str] = []
ROWS: list[tuple] = []


def expect(name: str, res, want: str | tuple):
    want = want if isinstance(want, tuple) else (want,)
    okk = res.status in want
    ROWS.append((("PASS" if okk else "FAIL"), name, res.status, res.message[:64]))
    if not okk:
        FAILED.append(f"{name}: got {res.status}, want {want} — {res.message}")


# ---------------------------------------------------------------- 공통 픽스처

def clean_bars(n=400, sym=("F1", "F2")) -> pd.DataFrame:
    ts = pd.date_range("2026-08-06 00:00", periods=n, freq="1min", tz="UTC")
    out = []
    for s in sym:
        px = np.round(350 * np.exp(np.cumsum(RNG.normal(0, 5e-4, n))) / 0.05) * 0.05
        op = np.concatenate([[px[0]], px[:-1]])
        out.append(pd.DataFrame({
            "ts": ts, "symbol": s, "open": op,
            "high": np.maximum(op, px) + 0.05, "low": np.minimum(op, px) - 0.05,
            "close": px, "volume": RNG.integers(1, 999, n).astype("float64")}))
    return pd.concat(out, ignore_index=True)


def clean_quotes(n=300) -> pd.DataFrame:
    ts = pd.date_range("2026-08-06 00:00", periods=n, freq="1min", tz="UTC")
    mid = 350 + np.cumsum(RNG.normal(0, 0.05, n))
    q = pd.DataFrame({"ts": ts, "symbol": "F1"})
    for i in range(1, 6):
        q[f"bid{i}"] = np.round((mid - 0.05 * i) / 0.05) * 0.05
        q[f"ask{i}"] = np.round((mid + 0.05 * i) / 0.05) * 0.05
        q[f"bid{i}_qty"] = RNG.integers(1, 200, n)
        q[f"ask{i}_qty"] = RNG.integers(1, 200, n)
    return q


def clean_chain() -> pd.DataFrame:
    from scipy.stats import norm
    ts, S, r, q, T = pd.Timestamp("2026-08-06", tz="UTC"), 350.0, 0.03, 0.01, 0.1
    rows = []
    for K in np.arange(330.0, 371.0, 2.5):
        sig = 0.2 + 0.5 * np.log(K / S) ** 2
        d1 = (np.log(S / K) + (r - q + 0.5 * sig ** 2) * T) / (sig * np.sqrt(T))
        d2 = d1 - sig * np.sqrt(T)
        c = S * np.exp(-q * T) * norm.cdf(d1) - K * np.exp(-r * T) * norm.cdf(d2)
        p = K * np.exp(-r * T) * norm.cdf(-d2) - S * np.exp(-q * T) * norm.cdf(-d1)
        for cp, px in (("C", c), ("P", p)):
            rows.append({"ts": ts, "expiry": pd.Timestamp("2026-09-10", tz="UTC"),
                         "cp": cp, "strike": float(K), "price": float(px), "iv": float(sig),
                         "spot": S, "r": r, "q": q, "tau_years": T})
    return pd.DataFrame(rows)


def clean_macro() -> pd.DataFrame:
    rows = []
    for s, step in (("CPI", 30), ("RATE", 45)):
        for i in range(36, 0, -1):
            pe = pd.Timestamp("2026-08-09", tz="UTC") - pd.Timedelta(days=step * i)
            rows.append({"series": s, "period_end": pe,
                         "release_ts": pe + pd.Timedelta(days=10),
                         "vintage": pe, "value": 2.5 + RNG.normal(0, 0.02)})
    return pd.DataFrame(rows)


def clean_feat(n=600) -> pd.DataFrame:
    ts = pd.date_range("2026-08-06 00:00", periods=n, freq="1min", tz="UTC")
    return pd.DataFrame({
        "ts": ts, "symbol": "F1",
        "rsi_14": RNG.uniform(20, 80, n), "ret_5": RNG.normal(0, 0.002, n),
        "vol_20": RNG.uniform(0.001, 0.01, n), "fwd_ret": RNG.normal(0, 0.002, n),
        "macro_release_ts": ts - pd.Timedelta(days=2)})


# ---------------------------------------------------------------- 테스트 본문

def run():
    R = {k: v["fn"] for k, v in REGISTRY.items()}
    now = pd.Timestamp("2026-08-06 06:40", tz="UTC")

    # ---- L0 FEED
    expect("FEED.HEARTBEAT/정상", R["FEED.HEARTBEAT"](now - pd.Timedelta("2s"), now=now), Status.PASS)
    expect("FEED.HEARTBEAT/피드정지", R["FEED.HEARTBEAT"](now - pd.Timedelta("120s"), now=now), Status.FAIL)

    seq = pd.Series(np.arange(1, 5001))
    expect("FEED.SEQ_GAP/정상", R["FEED.SEQ_GAP"](seq), Status.PASS)
    expect("FEED.SEQ_GAP/결번", R["FEED.SEQ_GAP"](seq.drop(index=range(100, 200))), Status.FAIL)
    expect("FEED.SEQ_GAP/역행", R["FEED.SEQ_GAP"](pd.concat([seq, pd.Series([3])])), Status.FAIL)

    t0 = pd.date_range("2026-08-06", periods=2000, freq="100ms", tz="UTC")
    tk = pd.DataFrame({"symbol": "F1", "seq": np.arange(2000), "exch_ts": t0,
                       "recv_ts": t0 + pd.to_timedelta(np.abs(RNG.normal(30, 10, 2000)), unit="ms")})
    expect("FEED.INGEST_LATENCY/정상", R["FEED.INGEST_LATENCY"](tk), Status.PASS)
    bad = tk.copy(); bad["recv_ts"] = bad["exch_ts"] + pd.Timedelta("2s")
    expect("FEED.INGEST_LATENCY/지연", R["FEED.INGEST_LATENCY"](bad), Status.FAIL)
    clk = tk.copy(); clk.loc[:5, "recv_ts"] = clk.loc[:5, "exch_ts"] - pd.Timedelta("50ms")
    expect("FEED.INGEST_LATENCY/시계역전", R["FEED.INGEST_LATENCY"](clk), Status.FAIL)

    expect("FEED.DUP_MSG/정상", R["FEED.DUP_MSG"](tk), Status.PASS)
    expect("FEED.DUP_MSG/중복", R["FEED.DUP_MSG"](pd.concat([tk, tk.head(50)])), Status.FAIL)
    base = RNG.normal(200, 5, 300)
    expect("FEED.MSG_RATE/정상", R["FEED.MSG_RATE"](201.0, baseline_rates=base), Status.PASS)
    expect("FEED.MSG_RATE/급감", R["FEED.MSG_RATE"](20.0, baseline_rates=base), Status.FAIL)
    expect("FEED.RECONNECT/정상", R["FEED.RECONNECT"](0, warn=0, fail=2), Status.PASS)
    expect("FEED.RECONNECT/잦은재접속", R["FEED.RECONNECT"](5, warn=0, fail=2), Status.FAIL)

    # ---- L1/L2 BAR
    b = clean_bars()
    expect("BAR.SCHEMA/정상", R["BAR.SCHEMA"](b), Status.PASS)
    expect("BAR.SCHEMA/컬럼누락", R["BAR.SCHEMA"](b.drop(columns=["volume"])), Status.FAIL)
    expect("BAR.SCHEMA/타입오류", R["BAR.SCHEMA"](b.assign(close=b["close"].astype(str))), Status.FAIL)

    expect("BAR.TS_MONOTONIC/정상", R["BAR.TS_MONOTONIC"](b), Status.PASS)
    expect("BAR.TS_MONOTONIC/중복", R["BAR.TS_MONOTONIC"](pd.concat([b, b.head(3)])), Status.FAIL)
    sh = b.copy(); sh.loc[10, "ts"] = sh.loc[300, "ts"]
    expect("BAR.TS_MONOTONIC/역행", R["BAR.TS_MONOTONIC"](sh), Status.FAIL)

    ses = [["09:00", "15:45"]]
    full = b[b.ts < b.ts.min() + pd.Timedelta(minutes=405)]
    expect("BAR.GRID_COMPLETE/결측多",
           R["BAR.GRID_COMPLETE"](full, sessions=ses, trading_days=1), Status.FAIL)
    expect("BAR.OHLC_SANITY/정상", R["BAR.OHLC_SANITY"](b), Status.PASS)
    bb = b.copy(); bb.loc[5, "high"] = bb.loc[5, "low"] - 1
    expect("BAR.OHLC_SANITY/고가<저가", R["BAR.OHLC_SANITY"](bb), Status.FAIL)
    bb = b.copy(); bb.loc[7, "volume"] = -3
    expect("BAR.OHLC_SANITY/음수거래량", R["BAR.OHLC_SANITY"](bb), Status.FAIL)

    expect("BAR.TICK_SIZE/정상", R["BAR.TICK_SIZE"](b, tick=0.05), Status.PASS)
    bb = b.copy(); bb.loc[0:9, "close"] = 350.017
    expect("BAR.TICK_SIZE/호가단위위반", R["BAR.TICK_SIZE"](bb, tick=0.05), (Status.WARN, Status.FAIL))

    expect("BAR.STALE_PRICE/정상", R["BAR.STALE_PRICE"](b), Status.PASS)
    bb = b.copy(); bb.loc[100:150, "close"] = bb.loc[100, "close"]; bb.loc[100:150, "volume"] = 0
    expect("BAR.STALE_PRICE/좀비피드", R["BAR.STALE_PRICE"](bb), Status.FAIL)

    expect("BAR.PRICE_JUMP/정상", R["BAR.PRICE_JUMP"](b), Status.PASS)
    bb = b.copy(); bb.loc[200, "close"] *= 1.4
    expect("BAR.PRICE_JUMP/팻핑거", R["BAR.PRICE_JUMP"](bb), Status.FAIL)

    eod = b.groupby("symbol", observed=True).tail(1)[["ts", "symbol", "close", "volume"]]
    expect("BAR.VENDOR_RECON/일치", R["BAR.VENDOR_RECON"](eod, ref=eod.copy()), Status.PASS)
    ref = eod.copy(); ref.iloc[0, ref.columns.get_loc("close")] += 0.5
    expect("BAR.VENDOR_RECON/불일치", R["BAR.VENDOR_RECON"](eod, ref=ref), Status.FAIL)
    expect("BAR.VENDOR_RECON/소스없음", R["BAR.VENDOR_RECON"](eod, ref=None), Status.SKIP)

    # ---- L2 BOOK
    q = clean_quotes()
    expect("BOOK.CROSSED/정상", R["BOOK.CROSSED"](q), Status.PASS)
    qq = q.copy(); qq.loc[3, "bid1"] = qq.loc[3, "ask1"] + 0.1
    expect("BOOK.CROSSED/역전", R["BOOK.CROSSED"](qq), Status.FAIL)
    qq = q.copy(); qq.loc[3, "bid1"] = qq.loc[3, "ask1"]
    expect("BOOK.CROSSED/locked", R["BOOK.CROSSED"](qq), (Status.WARN, Status.FAIL))

    expect("BOOK.LEVEL_ORDER/정상", R["BOOK.LEVEL_ORDER"](q), Status.PASS)
    qq = q.copy(); qq.loc[4, "bid3"] = qq.loc[4, "bid1"] + 1
    expect("BOOK.LEVEL_ORDER/정렬붕괴", R["BOOK.LEVEL_ORDER"](qq), Status.FAIL)
    qq = q.copy(); qq.loc[4, "ask2_qty"] = -5
    expect("BOOK.LEVEL_ORDER/음수수량", R["BOOK.LEVEL_ORDER"](qq), Status.FAIL)

    expect("BOOK.SPREAD_OUTLIER/정상", R["BOOK.SPREAD_OUTLIER"](q, max_bp=300), Status.PASS)
    qq = q.copy(); qq.loc[:40, "ask1"] = qq.loc[:40, "bid1"] * 1.1
    expect("BOOK.SPREAD_OUTLIER/스프레드폭발", R["BOOK.SPREAD_OUTLIER"](qq, max_bp=300), Status.FAIL)

    tr = q[["ts", "symbol", "bid1", "ask1"]].copy()
    tr["price"] = tr["ask1"]
    expect("BOOK.TRADE_IN_RANGE/정상",
           R["BOOK.TRADE_IN_RANGE"](tr[["ts", "symbol", "price"]], quotes=q), Status.PASS)
    tr2 = tr.copy(); tr2.loc[:200, "price"] = tr2.loc[:200, "ask1"] * 1.05
    expect("BOOK.TRADE_IN_RANGE/범위이탈",
           R["BOOK.TRADE_IN_RANGE"](tr2[["ts", "symbol", "price"]], quotes=q), Status.FAIL)

    rb = q.head(50)
    expect("BOOK.SNAPSHOT_DELTA/일치", R["BOOK.SNAPSHOT_DELTA"](rb, snapshot=rb.copy()), Status.PASS)
    sn = rb.copy(); sn.iloc[0, sn.columns.get_loc("bid1")] += 0.05
    expect("BOOK.SNAPSHOT_DELTA/불일치", R["BOOK.SNAPSHOT_DELTA"](rb, snapshot=sn), Status.FAIL)

    # ---- L2 선물/옵션
    fe = pd.DataFrame({"ts": pd.to_datetime(["2026-08-06"] * 2, utc=True),
                       "symbol": ["F1", "F2"],
                       "expiry": pd.to_datetime(["2026-09-10", "2026-12-10"], utc=True),
                       "open_interest": [1000.0, 2000.0]})
    expect("FUT.EXPIRY_VALID/정상", R["FUT.EXPIRY_VALID"](fe), Status.PASS)
    fx = fe.copy(); fx.loc[0, "expiry"] = pd.Timestamp("2026-07-01", tz="UTC")
    expect("FUT.EXPIRY_VALID/만기경과", R["FUT.EXPIRY_VALID"](fx), Status.FAIL)

    cts = pd.date_range("2026-05-01", periods=80, freq="B", tz="UTC")
    cont = pd.DataFrame({"ts": cts, "close": 350 * np.exp(np.cumsum(RNG.normal(0, 0.008, 80)))})
    rolls = [cts[30], cts[60]]
    expect("FUT.ROLL_CONTINUITY/정상", R["FUT.ROLL_CONTINUITY"](cont, roll_dates=rolls), Status.PASS)
    cx = cont.copy(); cx.loc[30, "close"] *= 1.12
    expect("FUT.ROLL_CONTINUITY/조정미적용", R["FUT.ROLL_CONTINUITY"](cx, roll_dates=rolls),
           (Status.WARN, Status.FAIL))

    bs = pd.DataFrame({"fut_close": 350 * (1 + RNG.normal(0.002, 0.0004, 200)),
                       "spot_close": 350.0, "tau_years": 0.1})
    expect("FUT.BASIS_SANITY/정상", R["FUT.BASIS_SANITY"](bs), Status.PASS)
    bx = bs.copy(); bx["fut_close"] = bx["spot_close"] * 1.5
    expect("FUT.BASIS_SANITY/현물오매칭", R["FUT.BASIS_SANITY"](bx), Status.FAIL)

    oi = pd.DataFrame({"symbol": ["F1"] * 10, "open_interest": np.linspace(1000, 1100, 10)})
    expect("FUT.OPEN_INTEREST/정상", R["FUT.OPEN_INTEREST"](oi), Status.PASS)
    ox = oi.copy(); ox.loc[5, "open_interest"] = -1
    expect("FUT.OPEN_INTEREST/음수", R["FUT.OPEN_INTEREST"](ox), Status.FAIL)

    ch = clean_chain()
    expect("OPT.CHAIN_COMPLETE/정상", R["OPT.CHAIN_COMPLETE"](ch), Status.PASS)
    cx = ch[~((ch.cp == "P") & (ch.strike.between(345, 355)))]
    expect("OPT.CHAIN_COMPLETE/체인구멍", R["OPT.CHAIN_COMPLETE"](cx), Status.FAIL)

    expect("OPT.NOARB_MONOTONIC/정상", R["OPT.NOARB_MONOTONIC"](ch), Status.PASS)
    cx = ch.copy(); cx.loc[cx[(cx.cp == "C") & (cx.strike == 350.0)].index, "price"] *= 3
    expect("OPT.NOARB_MONOTONIC/단조성위반", R["OPT.NOARB_MONOTONIC"](cx), Status.FAIL)
    expect("OPT.NOARB_BUTTERFLY/정상", R["OPT.NOARB_BUTTERFLY"](ch), Status.PASS)
    expect("OPT.NOARB_BUTTERFLY/볼록성위반", R["OPT.NOARB_BUTTERFLY"](cx), Status.FAIL)

    expect("OPT.PUT_CALL_PARITY/정상", R["OPT.PUT_CALL_PARITY"](ch), Status.PASS)
    expect("OPT.PUT_CALL_PARITY/오염호가", R["OPT.PUT_CALL_PARITY"](cx), Status.FAIL)
    cx2 = ch.copy(); cx2["spot"] = 380.0                      # 현물 매칭 오류
    expect("OPT.PUT_CALL_PARITY/현물오매칭", R["OPT.PUT_CALL_PARITY"](cx2), Status.FAIL)

    expect("OPT.IV_SANITY/정상", R["OPT.IV_SANITY"](ch), Status.PASS)
    cx3 = ch.copy(); cx3.loc[cx3.index[:4], "iv"] = 7.0
    expect("OPT.IV_SANITY/IV범위이탈", R["OPT.IV_SANITY"](cx3), (Status.WARN, Status.FAIL))

    ch2 = pd.concat([ch, ch.assign(expiry=pd.Timestamp("2026-12-10", tz="UTC"),
                                   price=ch["price"] * 1.4)], ignore_index=True)
    expect("OPT.CALENDAR_ARB/정상", R["OPT.CALENDAR_ARB"](ch2), Status.PASS)
    ch3 = pd.concat([ch, ch.assign(expiry=pd.Timestamp("2026-12-10", tz="UTC"),
                                   price=ch["price"] * 0.6)], ignore_index=True)
    expect("OPT.CALENDAR_ARB/만기라벨오류", R["OPT.CALENDAR_ARB"](ch3), Status.FAIL)

    # ---- 매크로 PIT
    mc = clean_macro()
    expect("MACRO.PIT_FIELDS/정상", R["MACRO.PIT_FIELDS"](mc), Status.PASS)
    mx = mc.copy(); mx.loc[0, "release_ts"] = mx.loc[0, "period_end"] - pd.Timedelta(days=3)
    expect("MACRO.PIT_FIELDS/발표시각역전", R["MACRO.PIT_FIELDS"](mx), Status.FAIL)
    expect("MACRO.PIT_FIELDS/필드없음",
           R["MACRO.PIT_FIELDS"](mc.drop(columns=["release_ts"])), Status.FAIL)

    expect("MACRO.REVISION/최초실행", R["MACRO.REVISION"](mc, previous=None), Status.SKIP)
    expect("MACRO.REVISION/변경없음", R["MACRO.REVISION"](mc, previous=mc.copy()), Status.PASS)
    pv = mc.copy(); pv.loc[pv.index[:40], "value"] *= 1.05
    expect("MACRO.REVISION/대량개정", R["MACRO.REVISION"](mc, previous=pv), Status.FAIL)

    nowd = pd.Timestamp("2026-08-09", tz="UTC")
    expect("MACRO.STALENESS/정상",
           R["MACRO.STALENESS"](mc, expected_days={"CPI": 31, "RATE": 46}, now=nowd), Status.PASS)
    stale = mc[mc.period_end < pd.Timestamp("2026-01-01", tz="UTC")]
    expect("MACRO.STALENESS/시리즈정지",
           R["MACRO.STALENESS"](stale, expected_days={"CPI": 31, "RATE": 46}, now=nowd), Status.FAIL)

    f = clean_feat()
    expect("MACRO.ASOF_JOIN/정상", R["MACRO.ASOF_JOIN"](f), Status.PASS)
    fx = f.copy(); fx.loc[:5, "macro_release_ts"] = fx.loc[:5, "ts"] + pd.Timedelta(days=1)
    expect("MACRO.ASOF_JOIN/미래값사용", R["MACRO.ASOF_JOIN"](fx), Status.FAIL)
    expect("MACRO.ASOF_JOIN/계보없음",
           R["MACRO.ASOF_JOIN"](f.drop(columns=["macro_release_ts"])), Status.FAIL)

    expect("MACRO.SCALE_SHIFT/정상", R["MACRO.SCALE_SHIFT"](mc), Status.PASS)
    mx = mc.copy(); mx.loc[mx.index[-1], "value"] *= 1000
    expect("MACRO.SCALE_SHIFT/단위변경", R["MACRO.SCALE_SHIFT"](mx), Status.FAIL)

    # ---- 피처
    cols = ["rsi_14", "ret_5", "vol_20"]
    expect("FEAT.NULL_RATIO/정상", R["FEAT.NULL_RATIO"](f, cols=cols), Status.PASS)
    fx = f.copy(); fx.loc[:100, "rsi_14"] = np.nan
    expect("FEAT.NULL_RATIO/결측폭증", R["FEAT.NULL_RATIO"](fx, cols=cols), Status.FAIL)

    expect("FEAT.INF_EXTREME/정상", R["FEAT.INF_EXTREME"](f, cols=cols), Status.PASS)
    fx = f.copy(); fx.loc[3, "ret_5"] = np.inf
    expect("FEAT.INF_EXTREME/0으로나눔", R["FEAT.INF_EXTREME"](fx, cols=cols), Status.FAIL)

    expect("FEAT.DEGENERATE/정상", R["FEAT.DEGENERATE"](f, cols=cols), Status.PASS)
    fx = f.copy(); fx["vol_20"] = 0.005
    expect("FEAT.DEGENERATE/상수화", R["FEAT.DEGENERATE"](fx, cols=cols), Status.FAIL)

    spec = {"rsi_14": [0, 100]}
    expect("FEAT.RANGE_CONTRACT/정상", R["FEAT.RANGE_CONTRACT"](f, spec=spec), Status.PASS)
    fx = f.copy(); fx.loc[:20, "rsi_14"] = 250
    expect("FEAT.RANGE_CONTRACT/계약위반", R["FEAT.RANGE_CONTRACT"](fx, spec=spec), Status.FAIL)
    expect("FEAT.RANGE_CONTRACT/컬럼삭제",
           R["FEAT.RANGE_CONTRACT"](f.drop(columns=["rsi_14"]), spec=spec), Status.FAIL)

    expect("FEAT.ROWCOUNT/정상", R["FEAT.ROWCOUNT"](f, expected=len(f)), Status.PASS)
    expect("FEAT.ROWCOUNT/부분적재", R["FEAT.ROWCOUNT"](f.head(400), expected=len(f)), Status.FAIL)

    last = f["ts"].max()
    expect("FEAT.FRESHNESS/정상", R["FEAT.FRESHNESS"](f, now=last + pd.Timedelta("30s")), Status.PASS)
    expect("FEAT.FRESHNESS/지연", R["FEAT.FRESHNESS"](f, now=last + pd.Timedelta("1h")), Status.FAIL)

    b1, b2 = clean_feat(), clean_feat()
    expect("FEAT.PSI_DRIFT/동일분포", R["FEAT.PSI_DRIFT"](b1, baseline=b2, cols=cols), Status.PASS)
    sh = b1.copy(); sh["rsi_14"] = sh["rsi_14"] * 0.3 + 5
    expect("FEAT.PSI_DRIFT/분포이동", R["FEAT.PSI_DRIFT"](sh, baseline=b2, cols=cols), Status.FAIL)
    expect("FEAT.PSI_DRIFT/기준없음", R["FEAT.PSI_DRIFT"](b1, baseline=None), Status.SKIP)

    n = 800
    x = RNG.normal(0, 1, n); y = x * 0.8 + RNG.normal(0, 0.6, n)
    cbase = pd.DataFrame({"a": x, "b": y, "c": RNG.normal(0, 1, n)})
    ccur = pd.DataFrame({"a": x, "b": y, "c": RNG.normal(0, 1, n)})
    expect("FEAT.CORR_STRUCTURE/정상", R["FEAT.CORR_STRUCTURE"](ccur, baseline=cbase), Status.PASS)
    cbroken = ccur.copy(); cbroken["b"] = RNG.normal(0, 1, n)
    expect("FEAT.CORR_STRUCTURE/관계붕괴",
           R["FEAT.CORR_STRUCTURE"](cbroken, baseline=cbase), (Status.WARN, Status.FAIL))

    expect("FEAT.DETERMINISM/재현OK", R["FEAT.DETERMINISM"](f, recomputed=f.copy()), Status.PASS)
    fx = f.copy(); fx.loc[0, "ret_5"] += 1e-3
    expect("FEAT.DETERMINISM/재현실패", R["FEAT.DETERMINISM"](f, recomputed=fx), Status.FAIL)

    expect("FEAT.TARGET_LEAKAGE/정상",
           R["FEAT.TARGET_LEAKAGE"](f, feature_cols=cols), Status.PASS)
    fx = f.copy(); fx["leak"] = fx["fwd_ret"] * 0.95 + RNG.normal(0, 1e-4, len(fx))
    expect("FEAT.TARGET_LEAKAGE/타깃누수",
           R["FEAT.TARGET_LEAKAGE"](fx, exclude=["ts"]), Status.FAIL)

    expect("FEAT.TRAIN_SERVE_SKEW/정상",
           R["FEAT.TRAIN_SERVE_SKEW"](f, online=f.copy(), cols=cols), Status.PASS)
    on = f.copy(); on.loc[:50, "rsi_14"] *= 1.01
    expect("FEAT.TRAIN_SERVE_SKEW/코드경로분기",
           R["FEAT.TRAIN_SERVE_SKEW"](f, online=on, cols=cols), Status.FAIL)

    def honest(raw):
        g = raw.sort_values("ts").copy()
        g["ma"] = g["close"].rolling(10).mean()
        return g

    def leaky(raw):
        g = honest(raw)
        g["z"] = (g["close"] - g["close"].mean()) / g["close"].std()   # 전구간 통계 = 미래참조
        return g

    b1sym = clean_bars(sym=("F1",))
    expect("FEAT.LOOKAHEAD/정상", R["FEAT.LOOKAHEAD"](b1sym, compute_fn=honest,
                                                      keys=["ts", "symbol"]), Status.PASS)
    expect("FEAT.LOOKAHEAD/전구간정규화", R["FEAT.LOOKAHEAD"](b1sym, compute_fn=leaky,
                                                        keys=["ts", "symbol"]), Status.FAIL)

    ic_base = {"rsi_14": 0.15, "ret_5": -0.12}
    expect("FEAT.IC_MONITOR/기준없음", R["FEAT.IC_MONITOR"](f, feature_cols=cols), Status.SKIP)
    fx = f.copy()
    fx["rsi_14"] = fx["fwd_ret"].rank() + RNG.normal(0, 50, len(fx))     # IC 급등
    expect("FEAT.IC_MONITOR/IC급변",
           R["FEAT.IC_MONITOR"](fx, feature_cols=cols, baseline_ic=ic_base), Status.FAIL)

    # ---- 예외 안전성: 체크가 터져도 파이프라인은 죽지 않고 ERROR로 기록
    expect("예외안전성/ERROR로수렴", R["BAR.OHLC_SANITY"](pd.DataFrame({"x": [1]})), Status.ERROR)


# ================================================================
# 대신 CYBOS Plus / CREON Plus 환경 체크 (추가분)
# ================================================================

def run_creon():
    R = {k: v["fn"] for k, v in REGISTRY.items()}
    now = pd.Timestamp("2026-08-07 06:45", tz="UTC")

    # ---- 접속 / 프로세스
    expect("CREON.CONNECT/정상", R["CREON.CONNECT"](1, server_type=1), Status.PASS)
    expect("CREON.CONNECT/끊김", R["CREON.CONNECT"](0, server_type=0), Status.FAIL)
    expect("CREON.CONNECT/보통서버", R["CREON.CONNECT"](1, server_type=2), Status.WARN)

    flat = np.full(60, 620.0)
    expect("CREON.MEMORY/정상", R["CREON.MEMORY"](620, history_mb=flat), Status.PASS)
    expect("CREON.MEMORY/한계근접", R["CREON.MEMORY"](1750, history_mb=flat), Status.FAIL)
    rising = np.linspace(700, 900, 60)          # 200MB/시간 상승
    expect("CREON.MEMORY/누수기울기", R["CREON.MEMORY"](900, history_mb=rising), Status.WARN)

    expect("CREON.QUEUE_DEPTH/정상", R["CREON.QUEUE_DEPTH"](12, history=[10, 12, 9, 11, 12]),
           Status.PASS)
    expect("CREON.QUEUE_DEPTH/적체", R["CREON.QUEUE_DEPTH"](7000), Status.FAIL)
    expect("CREON.QUEUE_DEPTH/연속증가",
           R["CREON.QUEUE_DEPTH"](60, history=[10, 20, 30, 45, 60]), Status.WARN)

    hb = pd.DataFrame({"ts": pd.date_range("2026-08-07 00:00", periods=405,
                                           freq="1min", tz="UTC")})
    expect("CREON.HEARTBEAT/정상",
           R["CREON.HEARTBEAT"](hb, now=hb.ts.max() + pd.Timedelta("20s")), Status.PASS)
    gap = hb.drop(index=range(100, 105))
    expect("CREON.HEARTBEAT/결번",
           R["CREON.HEARTBEAT"](gap, now=gap.ts.max() + pd.Timedelta("20s")), Status.FAIL)
    expect("CREON.HEARTBEAT/스레드정지",
           R["CREON.HEARTBEAT"](hb, now=hb.ts.max() + pd.Timedelta("10min")),
           Status.FAIL)

    # ---- 크레온 고유 한도
    expect("CREON.SUBSCRIBE_SLOTS/여유", R["CREON.SUBSCRIBE_SLOTS"](150), Status.PASS)
    expect("CREON.SUBSCRIBE_SLOTS/포화", R["CREON.SUBSCRIBE_SLOTS"](395), Status.FAIL)
    expect("CREON.SUBSCRIBE_SLOTS/미수신종목",
           R["CREON.SUBSCRIBE_SLOTS"](200, requested_symbols=["A", "B", "C"],
                                      active_symbols=["A", "B"]), Status.FAIL)
    expect("CREON.SUBSCRIBE_SLOTS/remain으로계산",
           R["CREON.SUBSCRIBE_SLOTS"](0, remain=250), Status.PASS)

    expect("CREON.REQUEST_QUOTA/여유", R["CREON.REQUEST_QUOTA"](50, remain_trade=18),
           Status.PASS)
    expect("CREON.REQUEST_QUOTA/시세소진", R["CREON.REQUEST_QUOTA"](2), Status.FAIL)
    expect("CREON.REQUEST_QUOTA/주문소진",
           R["CREON.REQUEST_QUOTA"](50, remain_trade=1), Status.FAIL)

    # ---- 틱 무결성
    ts = pd.date_range("2026-08-07 00:00", periods=800, freq="1s", tz="UTC")
    cum = np.cumsum(RNG.integers(1, 30, 800)).astype("float64")
    tk = pd.DataFrame({"ts": ts, "symbol": "F", "cum_volume": cum})
    expect("CREON.TICK_CONTINUITY/정상", R["CREON.TICK_CONTINUITY"](tk), Status.PASS)
    jump = tk.copy(); jump.loc[400:, "cum_volume"] += 9000     # 한 이벤트에 대량 흡수
    expect("CREON.TICK_CONTINUITY/유실흡수", R["CREON.TICK_CONTINUITY"](jump), Status.FAIL)
    rev = tk.copy(); rev.loc[500:, "cum_volume"] -= 5000       # 세션 리셋
    expect("CREON.TICK_CONTINUITY/누적역행", R["CREON.TICK_CONTINUITY"](rev), Status.FAIL)

    n = 300
    buy = np.cumsum(RNG.integers(0, 20, n)).astype("float64")
    sell = np.cumsum(RNG.integers(0, 20, n)).astype("float64")
    anch = pd.DataFrame({"ts": pd.date_range("2026-08-07", periods=n, freq="1min", tz="UTC"),
                         "cum_buy": buy, "cum_sell": sell,
                         "cum_volume": buy + sell, "cvd_cum": buy - sell})
    expect("CREON.CVD_ANCHOR/일치", R["CREON.CVD_ANCHOR"](anch), Status.PASS)
    off = anch.copy(); off.loc[150:, "cvd_cum"] += 400          # 오배분 발생
    expect("CREON.CVD_ANCHOR/오배분", R["CREON.CVD_ANCHOR"](off), Status.FAIL)
    expect("CREON.CVD_ANCHOR/앵커없음",
           R["CREON.CVD_ANCHOR"](anch.drop(columns=["cum_buy"])), Status.SKIP)

    zb = clean_bars(sym=("F1",))
    expect("CREON.ZERO_VALUE/정상", R["CREON.ZERO_VALUE"](zb), Status.PASS)
    z2 = zb.copy(); z2.loc[3, "close"] = 0.0
    expect("CREON.ZERO_VALUE/현재가0", R["CREON.ZERO_VALUE"](z2), Status.FAIL)
    z3 = zb.copy(); z3["cvd"] = np.nan
    expect("CREON.ZERO_VALUE/피처NaN",
           R["CREON.ZERO_VALUE"](z3, feature_cols=["cvd"]), Status.FAIL)

    # ---- EOD 대사
    off_bars = clean_bars(sym=("F1",))[["ts", "symbol", "open", "high", "low",
                                        "close", "volume"]]
    expect("RECON.BAR_COVERAGE/완전",
           R["RECON.BAR_COVERAGE"](off_bars, official=off_bars.copy()), Status.PASS)
    lost = off_bars.drop(index=range(100, 106))
    expect("RECON.BAR_COVERAGE/연속유실",
           R["RECON.BAR_COVERAGE"](lost, official=off_bars), Status.FAIL)
    ghost = pd.concat([off_bars, off_bars.tail(1).assign(
        ts=off_bars.ts.max() + pd.Timedelta("1min"))], ignore_index=True)
    expect("RECON.BAR_COVERAGE/유령봉",
           R["RECON.BAR_COVERAGE"](ghost, official=off_bars), Status.FAIL)
    expect("RECON.BAR_COVERAGE/공식없음",
           R["RECON.BAR_COVERAGE"](off_bars, official=None), Status.SKIP)

    expect("RECON.VOLUME_BIAS/일치",
           R["RECON.VOLUME_BIAS"](off_bars, official=off_bars.copy()), Status.PASS)
    under = off_bars.copy()
    under.loc[under.index[:40], "volume"] *= 0.9      # 전부 '내 쪽이 적음' = 틱 유실
    r = R["RECON.VOLUME_BIAS"](under, official=off_bars)
    expect("RECON.VOLUME_BIAS/체계적유실", r, Status.FAIL)
    assert "틱 유실" in r.message, r.message
    over = off_bars.copy()
    over.loc[over.index[:40], "volume"] *= 1.1
    r2 = R["RECON.VOLUME_BIAS"](over, official=off_bars)
    expect("RECON.VOLUME_BIAS/중복집계", r2, Status.FAIL)
    assert "중복 집계" in r2.message, r2.message

    expect("RECON.OHLC_DIFF/일치",
           R["RECON.OHLC_DIFF"](off_bars, official=off_bars.copy()), Status.PASS)
    hl = off_bars.copy()
    hl.loc[hl.index[:30], "high"] += 0.5              # 종가는 맞고 고가만 틀림
    r3 = R["RECON.OHLC_DIFF"](hl, official=off_bars)
    expect("RECON.OHLC_DIFF/봉내틱유실", r3, Status.FAIL)
    assert "봉 내부 틱 유실" in r3.message, r3.message

    # ---- commit 판정
    from qdq.checks.recon import commit_decision
    good = [R["RECON.BAR_COVERAGE"](off_bars, official=off_bars.copy()),
            R["RECON.VOLUME_BIAS"](off_bars, official=off_bars.copy()),
            R["RECON.OHLC_DIFF"](off_bars, official=off_bars.copy())]
    assert commit_decision(good)["action"] == "COMMIT"
    bad = good[:2] + [R["RECON.OHLC_DIFF"](hl, official=off_bars)]
    assert commit_decision(bad)["action"] == "OVERWRITE"
    ROWS.append(("PASS", "commit_decision/COMMIT·OVERWRITE 분기", "-", "정상 동작"))

    # ---- 피처 수학
    m = pd.DataFrame({"volume": [100.0] * 50,
                      "buy_volume": [60.0] * 50, "sell_volume": [40.0] * 50})
    m["cvd_1m"] = m.buy_volume - m.sell_volume
    expect("MATH.CVD_BOUND/정상", R["MATH.CVD_BOUND"](m), Status.PASS)
    m2 = m.copy(); m2.loc[3, "cvd_1m"] = 150.0
    expect("MATH.CVD_BOUND/부등식위반", R["MATH.CVD_BOUND"](m2), Status.FAIL)
    m3 = m.copy(); m3.loc[5, "sell_volume"] = 30.0        # Buy+Sell != Volume
    m3["cvd_1m"] = m3.buy_volume - m3.sell_volume
    r4 = R["MATH.CVD_BOUND"](m3)
    expect("MATH.CVD_BOUND/항등식위반(부등식은통과)", r4, Status.FAIL)

    cc = pd.DataFrame({"ts": pd.date_range("2026-08-07", periods=60, freq="1min", tz="UTC"),
                       "cvd_1m": RNG.normal(0, 10, 60)})
    cc["cvd_cum"] = cc.cvd_1m.cumsum()
    expect("MATH.CVD_CONSISTENCY/정상", R["MATH.CVD_CONSISTENCY"](cc), Status.PASS)
    cc2 = cc.copy(); cc2.loc[30:, "cvd_cum"] += 5
    expect("MATH.CVD_CONSISTENCY/누적어긋남", R["MATH.CVD_CONSISTENCY"](cc2), Status.FAIL)

    hb2 = pd.DataFrame({"hurst": np.concatenate([np.full(63, np.nan),
                                                 RNG.uniform(.35, .65, 300)]),
                        "close": np.r_[np.full(63, 350.0), 350 + np.cumsum(
                            RNG.normal(0, .1, 300))]})
    expect("MATH.HURST_BOUND/워밍업은정상", R["MATH.HURST_BOUND"](hb2), Status.PASS)
    hb3 = hb2.copy(); hb3.loc[200, "hurst"] = np.nan
    expect("MATH.HURST_BOUND/내부NaN", R["MATH.HURST_BOUND"](hb3), Status.FAIL)
    hb4 = hb2.copy(); hb4.loc[200, "hurst"] = 2.4
    expect("MATH.HURST_BOUND/하드이탈", R["MATH.HURST_BOUND"](hb4), Status.FAIL)
    hb5 = hb2.copy(); hb5.loc[200:230, "hurst"] = 1.04
    expect("MATH.HURST_BOUND/추정오차범위", R["MATH.HURST_BOUND"](hb5),
           (Status.WARN, Status.FAIL))

    fw = pd.DataFrame({"close": 350 + np.cumsum(RNG.normal(0, .1, 500))})
    expect("MATH.FLAT_WINDOW/정상", R["MATH.FLAT_WINDOW"](fw, window=64), Status.PASS)
    fw2 = fw.copy(); fw2.loc[100:250, "close"] = 350.0
    expect("MATH.FLAT_WINDOW/평탄구간", R["MATH.FLAT_WINDOW"](fw2, window=64), Status.FAIL)

    nb = pd.DataFrame({"ret_z": np.clip(RNG.normal(0, .3, 500), -1, 1),
                       "cvd_z": np.clip(RNG.normal(0, .3, 500), -1, 1)})
    expect("MATH.NORM_BOUND/정상", R["MATH.NORM_BOUND"](nb, cols=["ret_z", "cvd_z"]),
           Status.PASS)
    nb2 = nb.copy(); nb2.loc[:100, "ret_z"] = 1.0        # 20% 경계 포화
    expect("MATH.NORM_BOUND/클리핑포화", R["MATH.NORM_BOUND"](nb2, cols=["ret_z", "cvd_z"]),
           Status.FAIL)
    nb3 = nb.copy(); nb3.loc[3, "ret_z"] = 7.0           # 하드 이탈
    expect("MATH.NORM_BOUND/하드이탈", R["MATH.NORM_BOUND"](nb3, cols=["ret_z", "cvd_z"]),
           Status.FAIL)

    tr = {"mean": 0.001, "std": 0.02}
    expect("MATH.SCALER_PARAMS/일치", R["MATH.SCALER_PARAMS"](dict(tr), trained=tr),
           Status.PASS)
    expect("MATH.SCALER_PARAMS/재적합", R["MATH.SCALER_PARAMS"]({"mean": 0.001, "std": 0.03},
                                                            trained=tr), Status.FAIL)
    expect("MATH.SCALER_PARAMS/기준없음", R["MATH.SCALER_PARAMS"]({}, trained=None),
           Status.SKIP)


# ================================================================
# 피처 계약 엔진 (범용) — 계약서만 바꿔서 임의 피처를 점검할 수 있는가
# ================================================================

def run_contract():
    from qdq.contract import load_contracts, contract_suite, coverage_report
    from qdq.checks.contract_checks import register_contracts
    R = {k: v["fn"] for k, v in REGISTRY.items()}

    spec = {"features": {
        "myfeat": {
            "desc": "테스트용 임의 피처",
            "lo": 0.0, "hi": 1.0, "soft_lo": -0.1, "soft_hi": 1.1,
            "invariants": ["myfeat == num / den", "myfeat >= 0"],
            "denominator": "den",
            "anchor": "server_val", "anchor_diff": False,
            "anchor_scale": "one", "anchor_warn": 0.01, "anchor_fail": 0.05,
            "warmup": 5, "null_warn": 0.02, "null_fail": 0.08, "min_unique": 3,
        }}}
    contracts = load_contracts(spec)
    register_contracts(contracts)

    n = 200
    den = RNG.uniform(2, 5, n)
    num = RNG.uniform(0, 1, n) * den
    base = pd.DataFrame({"num": num, "den": den, "one": np.ones(n)})
    base["myfeat"] = base.num / base.den
    base["server_val"] = base["myfeat"]
    base.loc[:4, "myfeat"] = np.nan            # 선언한 워밍업 5행

    expect("CONTRACT.RANGE/정상", R["CONTRACT.RANGE"](base, contract="myfeat"), Status.PASS)
    expect("CONTRACT.INVARIANT/정상", R["CONTRACT.INVARIANT"](base, contract="myfeat"),
           Status.PASS)
    expect("CONTRACT.SUPPORT/정상", R["CONTRACT.SUPPORT"](base, contract="myfeat"),
           Status.PASS)
    expect("CONTRACT.ANCHOR/정상", R["CONTRACT.ANCHOR"](base, contract="myfeat"), Status.PASS)
    expect("CONTRACT.HYGIENE/정상", R["CONTRACT.HYGIENE"](base, contract="myfeat"), Status.PASS)

    # ① 치역: 절대경계 이탈 = FAIL, 이론경계만 벗어나면 = WARN
    b1 = base.copy(); b1.loc[50, "myfeat"] = 3.0
    expect("CONTRACT.RANGE/절대이탈", R["CONTRACT.RANGE"](b1, contract="myfeat"), Status.FAIL)
    b2 = base.copy(); b2.loc[50:60, "myfeat"] = 1.05
    expect("CONTRACT.RANGE/이론경계밖",
           R["CONTRACT.RANGE"](b2, contract="myfeat"), (Status.WARN, Status.FAIL))

    # ② 불변식: 정의식이 깨지면 잡힌다
    b3 = base.copy(); b3.loc[70:75, "myfeat"] = b3.loc[70:75, "myfeat"] * 1.0001
    expect("CONTRACT.INVARIANT/정의식위반", R["CONTRACT.INVARIANT"](b3, contract="myfeat"),
           Status.FAIL)

    # ③ 정의구간: 분모 0 → NaN 의 원인을 짚어주는가
    b4 = base.copy(); b4.loc[80:95, "den"] = 0.0; b4.loc[80:95, "myfeat"] = np.nan
    r = R["CONTRACT.SUPPORT"](b4, contract="myfeat")
    expect("CONTRACT.SUPPORT/분모0", r, (Status.WARN, Status.FAIL))
    assert r.sample[0]["분모0이_원인인_NaN"] == 16, r.sample
    b5 = base.copy(); b5.loc[80:95, "myfeat"] = np.nan          # 분모 멀쩡한데 NaN
    r5 = R["CONTRACT.SUPPORT"](b5, contract="myfeat")
    expect("CONTRACT.SUPPORT/원인불명NaN", r5, (Status.WARN, Status.FAIL))
    assert r5.sample[0]["원인불명_NaN"] == 16, r5.sample

    # ④ 앵커: 외부 정답지와 어긋나면 잡힌다
    b6 = base.copy(); b6.loc[100:110, "server_val"] += 0.5
    expect("CONTRACT.ANCHOR/정답지불일치", R["CONTRACT.ANCHOR"](b6, contract="myfeat"),
           Status.FAIL)

    # ⑤ 위생: inf / 상수화 / 워밍업 선언 오류
    b7 = base.copy(); b7.loc[30, "myfeat"] = np.inf
    expect("CONTRACT.HYGIENE/inf", R["CONTRACT.HYGIENE"](b7, contract="myfeat"), Status.FAIL)
    b8 = base.copy(); b8["myfeat"] = 0.5; b8.loc[:4, "myfeat"] = np.nan
    expect("CONTRACT.HYGIENE/상수화", R["CONTRACT.HYGIENE"](b8, contract="myfeat"),
           Status.FAIL)
    b9 = base.copy(); b9.loc[:19, "myfeat"] = np.nan     # 실제 워밍업 20 > 선언 5
    expect("CONTRACT.HYGIENE/워밍업선언오류", R["CONTRACT.HYGIENE"](b9, contract="myfeat"),
           Status.FAIL)

    # 계약 없는 피처 / 계약만 있고 컬럼이 없는 경우
    expect("CONTRACT.RANGE/계약없음", R["CONTRACT.RANGE"](base, contract="unknown"),
           Status.SKIP)
    expect("CONTRACT.RANGE/컬럼누락",
           R["CONTRACT.RANGE"](base.drop(columns=["myfeat"]), contract="myfeat"),
           Status.FAIL)

    b10 = base.copy(); b10["shadow_alpha"] = 1.0
    expect("CONTRACT.COVERAGE/미선언피처탐지",
           R["CONTRACT.COVERAGE"](b10, exclude=["num", "den", "one", "server_val"],
                                  warn=0, fail=2), (Status.WARN, Status.FAIL))
    expect("CONTRACT.COVERAGE/전부선언",
           R["CONTRACT.COVERAGE"](base, exclude=["num", "den", "one", "server_val"],
                                  warn=0, fail=2), Status.PASS)

    # 스위트 자동 생성: 축을 선언한 만큼만 체크가 생긴다
    items = contract_suite(contracts, data_key="feat")
    ids = {i["check"] for i in items}
    assert ids == {"CONTRACT.RANGE", "CONTRACT.INVARIANT", "CONTRACT.SUPPORT",
                   "CONTRACT.ANCHOR", "CONTRACT.HYGIENE"}, ids
    minimal = load_contracts({"features": {"plain": {"null_warn": 0.01}}})
    assert {i["check"] for i in contract_suite(minimal, data_key="f")} == \
        {"CONTRACT.HYGIENE"}
    ROWS.append(("PASS", "contract_suite/선언한 축만 체크 생성", "-", "정상 동작"))

    # 실전 계약서 로딩 + 커버리지
    real = load_contracts("config/feature_contracts.yaml")
    assert len(real) >= 15, len(real)
    assert real["hurst_64"].soft_hi == 1.1 and real["hurst_64"].hi == 1.0
    assert real["fwd_ret"].allow_forward is True
    ROWS.append(("PASS", f"feature_contracts.yaml/{len(real)}개 피처 로딩", "-", "정상"))
    register_contracts(real)


if __name__ == "__main__":
    run()
    run_creon()
    run_contract()
    w = max(len(r[1]) for r in ROWS) + 2
    print(f"{'결과':<6}{'테스트':<{w}}{'상태':<8}메시지")
    print("-" * (w + 60))
    for okk, name, st, msg in ROWS:
        print(f"{('OK' if okk == 'PASS' else 'XX'):<6}{name:<{w}}{st:<8}{msg}")
    print("-" * (w + 60))
    print(f"총 {len(ROWS)}건 중 성공 {len(ROWS) - len(FAILED)}건, 실패 {len(FAILED)}건")
    for m in FAILED:
        print("  ✗", m)
    sys.exit(1 if FAILED else 0)
