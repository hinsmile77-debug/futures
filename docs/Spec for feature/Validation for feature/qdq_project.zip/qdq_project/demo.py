"""
demo.py — 합성 데이터로 전체 점검 스위트를 돌려보는 실행 예제.

  python demo.py clean    # 정상 데이터 → 게이트 OPEN 기대
  python demo.py dirty    # 오류 주입 데이터 → 게이트 CLOSED 기대
"""
from __future__ import annotations

import sys
import zlib

import numpy as np
import pandas as pd
from scipy.stats import norm

from qdq import DQRunner, Cadence, render_html

RNG = np.random.default_rng(20260809)
TZ = "Asia/Seoul"
SYMS = ["101W09", "101W12"]


# ------------------------------------------------------------------ 합성 데이터

SESSIONS = [("09:00", "15:45"), ("18:00", "05:00")]   # KRX 파생 정규장 + 야간장
TRADING_DAYS = 2


def _session_index(days=TRADING_DAYS, sessions=SESSIONS):
    idx = []
    for d in range(days):
        day = pd.Timestamp("2026-08-05", tz=TZ) + pd.Timedelta(days=d)
        for st, en in sessions:
            a = day + pd.Timedelta(f"{st}:00")
            b = day + pd.Timedelta(f"{en}:00")
            if b <= a:
                b += pd.Timedelta(days=1)
            idx.append(pd.date_range(a, b, freq="1min", inclusive="left"))
    return pd.DatetimeIndex(np.sort(np.concatenate(idx))).tz_convert("UTC")


def make_bars() -> pd.DataFrame:
    ts = _session_index()
    out = []
    for s in SYMS:
        n = len(ts)
        r = RNG.normal(0, 0.0006, n)
        px = 350.0 * np.exp(np.cumsum(r))
        px = np.round(px / 0.05) * 0.05
        hi = np.round((px * (1 + np.abs(RNG.normal(0, 0.0004, n)))) / 0.05) * 0.05
        lo = np.round((px * (1 - np.abs(RNG.normal(0, 0.0004, n)))) / 0.05) * 0.05
        op = np.concatenate([[px[0]], px[:-1]])
        out.append(pd.DataFrame({
            "ts": ts, "symbol": s, "open": op,
            "high": np.maximum.reduce([hi, op, px]),
            "low": np.minimum.reduce([lo, op, px]),
            "close": px, "volume": RNG.integers(10, 5000, n).astype("float64"),
        }))
    return pd.concat(out, ignore_index=True).sort_values(["symbol", "ts"]).reset_index(drop=True)


def make_quotes(bars: pd.DataFrame) -> pd.DataFrame:
    q = bars[["ts", "symbol", "close"]].copy()
    sp = 0.05 * RNG.integers(1, 3, len(q))
    q["bid1"] = np.round((q["close"] - sp) / 0.05) * 0.05
    q["ask1"] = np.round((q["close"] + sp) / 0.05) * 0.05
    for i in range(2, 6):
        q[f"bid{i}"] = q["bid1"] - 0.05 * (i - 1)
        q[f"ask{i}"] = q["ask1"] + 0.05 * (i - 1)
    for i in range(1, 6):
        q[f"bid{i}_qty"] = RNG.integers(1, 500, len(q))
        q[f"ask{i}_qty"] = RNG.integers(1, 500, len(q))
    return q.drop(columns=["close"]).sort_values("ts").reset_index(drop=True)


def make_trades(quotes: pd.DataFrame) -> pd.DataFrame:
    t = quotes.sample(frac=0.4, random_state=7)[["ts", "symbol", "bid1", "ask1"]].copy()
    t["price"] = np.where(RNG.random(len(t)) > 0.5, t["ask1"], t["bid1"])
    t["qty"] = RNG.integers(1, 50, len(t))
    return t[["ts", "symbol", "price", "qty"]].sort_values("ts").reset_index(drop=True)


def make_ticks(n=20000) -> pd.DataFrame:
    base = pd.Timestamp("2026-08-06 09:00", tz=TZ).tz_convert("UTC")
    exch = base + pd.to_timedelta(np.sort(RNG.integers(0, 6 * 3600 * 1000, n)), unit="ms")
    lat = np.abs(RNG.normal(35, 20, n))
    return pd.DataFrame({
        "symbol": RNG.choice(SYMS, n), "seq": np.arange(1, n + 1),
        "exch_ts": exch, "recv_ts": exch + pd.to_timedelta(lat, unit="ms"),
        "price": 350 + RNG.normal(0, 1, n),
    })


def _bs(S, K, T, r, q, sig, call=True):
    d1 = (np.log(S / K) + (r - q + 0.5 * sig ** 2) * T) / (sig * np.sqrt(T))
    d2 = d1 - sig * np.sqrt(T)
    if call:
        return S * np.exp(-q * T) * norm.cdf(d1) - K * np.exp(-r * T) * norm.cdf(d2)
    return K * np.exp(-r * T) * norm.cdf(-d2) - S * np.exp(-q * T) * norm.cdf(-d1)


def make_options() -> pd.DataFrame:
    ts = pd.Timestamp("2026-08-06 15:45", tz=TZ).tz_convert("UTC")
    S, r, q = 350.0, 0.032, 0.012
    rows = []
    for exp, T in [(pd.Timestamp("2026-09-10", tz="UTC"), 35 / 365),
                   (pd.Timestamp("2026-12-10", tz="UTC"), 126 / 365)]:
        for K in np.arange(320.0, 381.0, 2.5):
            m = np.log(K / S)
            sig = 0.18 + 0.9 * m ** 2 - 0.25 * m          # 스큐 있는 스마일
            for cp in ("C", "P"):
                rows.append({"ts": ts, "expiry": exp, "cp": cp, "strike": float(K),
                             "price": float(_bs(S, K, T, r, q, sig, cp == "C")),
                             "iv": float(sig), "spot": S, "r": r, "q": q,
                             "tau_years": T})
    return pd.DataFrame(rows)


def make_macro() -> pd.DataFrame:
    rows = []
    specs = {"CPI_KR": (30, 2.4), "BOK_BASE": (45, 2.75),
             "US_NFP": (30, 165.0), "KOSPI_PER": (7, 12.3)}
    today = pd.Timestamp("2026-08-09", tz="UTC")
    for s, (period_days, level) in specs.items():
        for i in range(36, 0, -1):
            pe = today - pd.Timedelta(days=period_days * i)
            rel = pe + pd.Timedelta(days=12)
            rows.append({"series": s, "period_end": pe, "release_ts": rel,
                         "vintage": rel.normalize(),
                         "value": float(level * (1 + RNG.normal(0, 0.02)))})
    return pd.DataFrame(rows)


def compute_features(bars: pd.DataFrame) -> pd.DataFrame:
    """룩어헤드 없는 피처 계산 함수 (절단 테스트의 대상).

    중요: 피처 함수는 반드시 결정적(deterministic)이어야 한다.
    난수를 쓰면 시드를 고정하고, 시드는 입력 데이터가 아니라 코드에 묶는다.
    """
    out = []
    for s, g in bars.sort_values("ts").groupby("symbol", observed=True):
        g = g.copy()
        det = np.random.default_rng(zlib.crc32(str(s).encode()))  # 프로세스 간 안정 시드
        c = g["close"].astype("float64")
        d = c.diff()
        up = d.clip(lower=0).rolling(14).mean()
        dn = (-d).clip(lower=0).rolling(14).mean()
        g["rsi_14"] = 100 - 100 / (1 + up / dn.replace(0, np.nan))
        g["ret_5"] = np.log(c).diff(5)
        g["vol_20"] = np.log(c).diff().rolling(20).std()
        g["vwap_dev"] = c / (c * g["volume"]).rolling(20).sum().div(
            g["volume"].rolling(20).sum()) - 1
        g["iv_atm"] = 0.18 + 0.5 * g["vol_20"].fillna(0)
        g["basis_ann"] = det.normal(0.01, 0.004, len(g))
        g["fwd_ret"] = np.log(c).shift(-5) - np.log(c)     # 타깃(마지막 5봉은 NaN)
        g["macro_release_ts"] = g["ts"] - pd.Timedelta(days=3)
        out.append(g)
    return pd.concat(out, ignore_index=True)


def compute_features_leaky(bars: pd.DataFrame) -> pd.DataFrame:
    """미래참조가 섞인 피처 함수 (절단 테스트가 이걸 잡아내야 한다)."""
    f = compute_features(bars)
    out = []
    for _, g in f.groupby("symbol", observed=True):
        g = g.copy()
        # ① 전체 구간 통계로 정규화 → 미래 정보가 과거로 새어든다 (가장 흔한 실수)
        g["ret_5_z"] = (g["ret_5"] - g["ret_5"].mean()) / g["ret_5"].std()
        # ② 명시적 미래 시프트
        g["future_peek"] = g["close"].shift(-3)
        out.append(g)
    return pd.concat(out, ignore_index=True)


def build(corrupt: bool = False) -> dict:
    bars = make_bars()
    quotes = make_quotes(bars)
    trades = make_trades(quotes)
    ticks = make_ticks()
    opt = make_options()
    macro = make_macro()

    if corrupt:
        # ① 분봉: 고가<저가 물리 위반 + 결측 봉 + 잘못된 호가단위
        bars.loc[100, "high"] = bars.loc[100, "low"] - 1.0
        bars.loc[300, "close"] = 350.037                    # tick 0.05 미준수
        bars = bars.drop(index=range(500, 540)).reset_index(drop=True)
        # ② 스테일 가격 35봉 + 팻핑거 점프
        bars.loc[700:735, "close"] = bars.loc[700, "close"]
        bars.loc[700:735, "volume"] = 0.0
        bars.loc[800, "close"] = bars.loc[800, "close"] * 1.25
        # ③ 호가: crossed book
        quotes.loc[50:60, "bid1"] = quotes.loc[50:60, "ask1"] + 0.10
        # ④ 피드: 시퀀스 결번 + 수신지연 스파이크 + 중복
        ticks = ticks.drop(index=range(5000, 5100)).reset_index(drop=True)
        ticks.loc[9000:9200, "recv_ts"] = ticks.loc[9000:9200, "exch_ts"] + pd.Timedelta("1500ms")
        ticks = pd.concat([ticks, ticks.iloc[:30]], ignore_index=True)
        # ⑤ 옵션: 단조성 위반 + 패리티 깨짐
        i = opt[(opt.cp == "C") & (opt.strike == 350.0)].index[0]
        opt.loc[i, "price"] *= 1.9
        opt.loc[opt.cp == "P", "iv"] = opt.loc[opt.cp == "P", "iv"] * 1.0
        opt.loc[opt.index[3], "iv"] = 4.5                   # IV 범위 이탈
        # ⑥ 매크로: 발표시각 역전 + 시리즈 정지 + 단위 변경
        macro.loc[0, "release_ts"] = macro.loc[0, "period_end"] - pd.Timedelta(days=5)
        macro = macro[~((macro.series == "CPI_KR") &
                        (macro.period_end > pd.Timestamp("2026-01-01", tz="UTC")))]
        macro.loc[macro.index[-1], "value"] *= 1000.0

    feat = compute_features(bars)
    feat_online = feat.copy()
    feat_recomputed = compute_features(bars)
    feat_baseline = compute_features(make_bars())
    macro_prev = macro.copy()
    macro_prev.loc[macro_prev.index[:3], "value"] *= 1.03    # 정상적인 개정 3건

    if corrupt:
        # ⑦ 피처: 룩어헤드 피처 주입 + train/serve skew + 결측 폭증
        # 전형적인 타깃 누수: 타깃을 가공한 값이 피처로 섞여 들어감
        feat["mom_signal"] = feat["fwd_ret"] * 0.9 + RNG.normal(0, 0.0002, len(feat))
        feat_recomputed["mom_signal"] = feat["mom_signal"]
        feat_online["mom_signal"] = feat["mom_signal"]
        feat_online.loc[:200, "rsi_14"] = feat_online.loc[:200, "rsi_14"] * 1.05
        feat.loc[:len(feat) // 8, "vwap_dev"] = np.nan
        feat.loc[5, "ret_5"] = np.inf
        feat_baseline["mom_signal"] = np.nan
        # as-of 조인 사고: 아직 발표되지 않은 매크로 값을 갖다 붙임
        feat.loc[feat.index[:300], "macro_release_ts"] = \
            feat.loc[feat.index[:300], "ts"] + pd.Timedelta(days=1)
        feat["iv_atm"] = feat["iv_atm"] * 20                  # range 계약 위반(>3.0)

    fut_eod = pd.DataFrame({
        "ts": pd.to_datetime(["2026-08-07", "2026-08-07"], utc=True),
        "symbol": SYMS,
        "expiry": pd.to_datetime(["2026-09-10", "2026-12-10"], utc=True),
        "open_interest": [120000.0, 45000.0],
    })
    if corrupt:
        fut_eod.loc[0, "expiry"] = pd.Timestamp("2026-07-10", tz="UTC")   # 만기 경과

    cont_ts = pd.date_range("2026-05-01", periods=90, freq="B", tz="UTC")
    cont_px = 350 * np.exp(np.cumsum(RNG.normal(0, 0.008, len(cont_ts))))
    fut_cont = pd.DataFrame({"ts": cont_ts, "close": cont_px})
    roll_dates = [pd.Timestamp("2026-06-11", tz="UTC"), pd.Timestamp("2026-07-09", tz="UTC")]
    if corrupt:
        m = fut_cont.ts.dt.normalize() == roll_dates[0]
        fut_cont.loc[m, "close"] *= 1.06                      # 롤 조정 미적용 갭

    basis = pd.DataFrame({"fut_close": cont_px * (1 + RNG.normal(0.002, 0.0006, len(cont_px))),
                          "spot_close": cont_px, "tau_years": 0.1})

    bars_eod = bars.groupby(["symbol"], observed=True).tail(1)[
        ["ts", "symbol", "close", "volume"]].reset_index(drop=True)
    bars_eod_vendor2 = bars_eod.copy()
    if corrupt:
        bars_eod_vendor2.loc[0, "close"] += 0.35              # 벤더 간 종가 불일치

    return {
        "bars": bars, "quotes": quotes, "trades": trades, "ticks": ticks,
        "seq": ticks["seq"], "last_msg_ts": ticks["recv_ts"].max(),
        "msg_rate_now": 220.0 if not corrupt else 12.0,
        "msg_rate_baseline": RNG.normal(220, 8, 200),
        "n_reconnect": 0 if not corrupt else 4,
        "opt": opt, "macro": macro, "macro_prev": macro_prev,
        "feat": feat, "feat_online": feat_online, "feat_recomputed": feat_recomputed,
        "feat_baseline": feat_baseline,
        "compute_fn": compute_features_leaky if corrupt else compute_features,
        "fut_eod": fut_eod, "fut_cont": fut_cont, "roll_dates": roll_dates,
        "basis": basis, "bars_eod": bars_eod, "bars_eod_vendor2": bars_eod_vendor2,
        "baseline_ic": {c: float(feat_baseline[[c, "fwd_ret"]].corr(method="spearman").iloc[0, 1])
                        for c in ("rsi_14", "ret_5", "vol_20", "vwap_dev")},
    }


# ------------------------------------------------------------------ 실행

def main(mode: str = "dirty"):
    data = build(corrupt=(mode == "dirty"))
    runner = DQRunner("config/dq_suite.yaml")
    # 기대 행 수는 런타임에 결정 (유니버스 × 세션 분봉)
    # 기대 행 수는 '세션 캘린더 × 유니버스'에서 나오는 값이지, 수집된 행 수가 아니다
    runner.cfg["defaults"]["FEAT.ROWCOUNT"] = {"expected": 1065 * TRADING_DAYS * len(SYMS)}
    # 합성 데이터 기준 '현재 시각' 고정
    #  - 실시간 체크는 데이터 끝 시각 직후를 현재로 본다 (장중 상황 재현)
    #  - 매크로 스테일니스는 달력상 오늘을 본다
    live_now = data["ticks"]["recv_ts"].max() + pd.Timedelta(seconds=2)
    feat_now = pd.to_datetime(data["feat_online"]["ts"], utc=True).max() + pd.Timedelta(seconds=30)
    runner.cfg["defaults"].setdefault("FEED.HEARTBEAT", {})["now"] = live_now
    runner.cfg["defaults"].setdefault("FEAT.FRESHNESS", {})["now"] = feat_now
    runner.cfg["defaults"].setdefault("MACRO.STALENESS", {})["now"] = \
        pd.Timestamp("2026-08-09", tz="UTC")

    all_results = []
    for cad in (Cadence.REALTIME, Cadence.INTRADAY, Cadence.EOD, Cadence.WEEKLY):
        rep = runner.run(cad, data, run_id=f"{mode}-{cad}")
        rep.print_summary()
        all_results.extend(rep.results)

    merged = runner.run(Cadence.EOD, data, run_id=f"{mode}-all")
    merged.results = all_results
    merged.cadence = "all"
    render_html(merged, f"out/dq_report_{mode}.html",
                title=f"시장데이터 무결성 점검 리포트 ({mode})")
    merged.save_json(f"out/dq_report_{mode}.json")
    print(f"\n→ out/dq_report_{mode}.html / .json 저장 완료 "
          f"(게이트 {'OPEN' if merged.gate_open else 'CLOSED'})")
    return merged


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "dirty")
